#!/usr/bin/env python3
"""Integração HTTP contra servidor local; somente fixture gerada por tests/run.php.
RV_TEST_FIXTURE=/caminho/fixture.json python3 tests/http_test.py http://127.0.0.1:8089
Não navega visualmente nem mede o layout. Usa apenas bibliotecas padrão.
"""
import datetime, html, http.cookiejar, json, os, pathlib, re, sys, urllib.error, urllib.parse, urllib.request
from html.parser import HTMLParser
from zoneinfo import ZoneInfo
BASE=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8089'
fixture=json.loads(pathlib.Path(os.environ['RV_TEST_FIXTURE']).read_text())
if not BASE.startswith(('http://127.0.0.1:','http://localhost:')):raise SystemExit('Use apenas o servidor local de testes.')
passed=0
class Tags(HTMLParser):
 def __init__(self,source):self.inputs=[];self.links=[];self.meta={};super().__init__();self.feed(source)
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if tag=='input':self.inputs.append(d)
  if tag=='a' and 'href' in d:self.links.append(d['href'])
  if tag=='meta':self.meta[d.get('name')]=d.get('content')
 def value(self,name):return next((x.get('value','') for x in self.inputs if x.get('name')==name),'')
class Browser:
 def __init__(self):self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
 def request(self,route,params=None,data=None,json_data=None,csrf=None,raw=None,content_type=None):
  url=BASE+'/index.php?'+urllib.parse.urlencode({'r':route,**(params or {})})
  headers={'Accept':'application/json' if route.startswith('api/') else 'text/html'}
  if csrf:headers['X-CSRF-Token']=csrf
  if json_data is not None:raw=json.dumps(json_data).encode();headers['Content-Type']='application/json'
  elif data is not None:raw=urllib.parse.urlencode(data,doseq=True).encode();headers['Content-Type']='application/x-www-form-urlencoded'
  if content_type:headers['Content-Type']=content_type
  try:r=self.opener.open(urllib.request.Request(url,data=raw,headers=headers),timeout=20)
  except urllib.error.HTTPError as e:r=e
  body=r.read();return r.code,body,r.geturl(),r.headers
 def page(self,route,params=None):
  s,b,u,h=self.request(route,params);return s,b.decode('utf-8'),u,h

def check(v,label):
 global passed
 if not v:raise AssertionError(label)
 passed+=1;print('PASSOU HTTP: '+label,flush=True)
def csrf(source):return Tags(source).meta.get('csrf-token') or Tags(source).value('_csrf')
def payload(source,**values):return {'_csrf':csrf(source),**values}
def text(r):return r[1].decode('utf-8')
client=Browser();other=Browser();admin=Browser();trip=fixture['trip_id']
s,body,url,headers=other.page('admin');check(s==200 and 'admin%2Flogin' in url,'rotas administrativas redirecionam visitante ao login')
s,home,_,_=client.page('');check(s==200 and '<html lang="pt-BR">' in home,'página inicial renderiza dados persistidos em português')
s,trips,_,_=client.page('viagens',{'destino':'Destino fictício'});check(s==200 and 'Destino fictício' in trips,'viagem aberta aparece no catálogo com filtro')
s,detail,_,_=client.page('viagem',{'id':trip});check(s==200 and '180,00' in detail,'detalhes mostram preço e roteiro do banco')
s,seatpage,_,_=client.page('poltronas',{'id':trip});token=csrf(seatpage);check(s==200 and 'data-seat-app' in seatpage and token,'mapa e formulário recebem sessão e token CSRF')
s,b,_,_=client.request('api/mapa',{'viagem_id':trip});m=json.loads(b);ids=[x['id'] for x in m['seats']];check(s==200 and len(ids)==7 and all('reserva_id' not in x and 'hold_hash' not in x for x in m['seats']),'API pública omite identificação de reservas e segredos')
s,*_=client.request('api/hold',json_data={'viagem_id':trip,'seats':ids[:2]});check(s==419,'API rejeita escrita sem CSRF')
s,*_=client.request('api/hold',json_data={'viagem_id':trip,'seats':ids[:2]},csrf=token);check(s==200,'seleção de duas poltronas retida no servidor')
s,*_=client.request('api/hold',raw=b'{broken json',csrf=token,content_type='application/json');check(s==422,'JSON malformado recebe erro de validação claro')
s,b,_,_=client.request('reservar',data={'_csrf':token,'viagem_id':trip,'seats[]':ids[:2],'responsavel':'Cliente QA','telefone':'11988887777','aceite':'1',f'passageiros[{ids[0]}]':'<script>alert(1)</script>',f'passageiros[{ids[1]}]':'=1+1','preco':'0.01','total':'0.01'});page=b.decode();check(s==200 and '360,00' in page,'formulário reserva múltiplos lugares e ignora preço fraudulento do navegador')
code=re.search(r'RV-[A-F0-9]{20}',page).group();link=Tags(page).value('');private=next(x['value'] for x in Tags(page).inputs if 'data-private-link' in x);secret=urllib.parse.parse_qs(urllib.parse.urlsplit(private).fragment)['token'][0]
check('<script>alert(1)</script>' not in page and '&lt;script&gt;alert(1)&lt;/script&gt;' in page,'saída HTML escapa nomes contendo marcação XSS')
s,*_=other.request('reserva',{'codigo':code});check(s==403,'código sozinho não autoriza acesso à reserva')
s,*_=other.request('consulta',data=payload(other.page('consulta')[1],codigo=code,token='0'*64));check(s==403,'chave privada incorreta não revela a reserva')
s,b,_,_=other.request('consulta',data=payload(other.page('consulta')[1],codigo=code,token=secret));check(s==200 and code in text((s,b)),'consulta sem conta aceita código e chave privada válidos')
s,*_=client.request('comprovante',{'codigo':code});check(s==403,'comprovante indisponível antes da confirmação')
s,login,_,_=admin.page('admin/login');s,*_=admin.request('admin/login',data={'email':fixture['admin_email'],'senha':fixture['admin_password']});check(s==419,'login também exige CSRF')
s,b,_,_=admin.request('admin/login',data=payload(login,email=fixture['admin_email'],senha=fixture['admin_password']));dashboard=b.decode();check(s==200 and 'Sua operação, em movimento.' in dashboard,'autenticação administrativa e dashboard reais')
for route in ['admin/viagens','admin/viagem','admin/onibus','admin/onibus/editar','admin/reservas','admin/passageiros','admin/financeiro','admin/relatorios','admin/configuracoes','admin/nova-reserva']:
 s,body,_,_=admin.page(route);check(s==200 and 'Não foi possível concluir' not in body,'tela integrada '+route)
s,body,_,_=admin.page('admin/mapa',{'viagem_id':trip});check(s==200 and 'data-admin="1"' in body,'mapa administrativo disponível com acesso autenticado')
s,b,_,_=other.request('api/admin/poltrona',{'id':ids[0]});check(s==401,'API administrativa protege dados de passageiros')
s,reslist,_,_=admin.page('admin/reservas',{'q':code});rlink=next(x for x in Tags(reslist).links if urllib.parse.parse_qs(urllib.parse.urlsplit(x).query).get('r')==['admin/reserva']);rid=int(urllib.parse.parse_qs(urllib.parse.urlsplit(rlink).query)['id'][0])
now=lambda:datetime.datetime.now(ZoneInfo('America/Sao_Paulo')).strftime('%Y-%m-%dT%H:%M')
def pay(value,kind='recebimento'):
 p=admin.page('admin/reserva',{'id':rid})[1]
 return admin.request('admin/pagamento',data=payload(p,id=rid,valor=value,tipo=kind,metodo='Pix',pago_em=now(),observacoes='Conferência fictícia HTTP',idempotencia=Tags(p).value('idempotencia')))
s,b,_,_=pay('100');check(s==200 and 'Pagamento parcial' in b.decode(),'registro financeiro parcial via painel')
s,b,_,_=pay('260');check(s==200 and 'Confirmada' in b.decode(),'pagamento integral via painel confirma reserva')
s,b,_,_=client.request('comprovante',{'codigo':code});check(s==200 and b.startswith(b'%PDF-1.4'),'cliente confirmado baixa PDF real')
pathlib.Path(os.environ['RV_TEST_FIXTURE']).parent.joinpath('http-ticket.pdf').write_bytes(b)
s,b,_,_=admin.request('admin/relatorios',{'tipo':'passageiros','viagem_id':trip,'formato':'csv'});csv=b.decode('utf-8-sig');check(s==200 and 'Poltrona' in csv and "'=1+1" in csv,'CSV com acentos e neutralização de fórmula do Excel')
s,b,_,_=admin.request('admin/relatorios',{'tipo':'passageiros','viagem_id':trip,'formato':'pdf'});check(s==200 and b.startswith(b'%PDF-1.4'),'relatório PDF gerado a partir de passageiros reais')
pathlib.Path(os.environ['RV_TEST_FIXTURE']).parent.joinpath('http-report.pdf').write_bytes(b)
s,p,_,_=admin.page('admin/reserva',{'id':rid});s,*_=admin.request('admin/poltrona/bloquear',data=payload(p,viagem_id=trip,poltrona_id=ids[0],acao='bloquear',motivo='Teste'));check(s==409,'painel impede bloquear poltrona ocupada')
registration=Tags(p).value('passageiro_registro');s,b,_,_=admin.request('admin/reserva/transferir',data=payload(p,id=rid,passageiro_registro=registration,poltrona_destino=ids[2]));check(s==200 and 'Passageiro transferido' in b.decode(),'transferência de passageiro executada pelo painel')
s,p,_,_=admin.page('admin/passageiros',{'viagem_id':trip});registration=Tags(p).value('registro');s,b,_,_=admin.request('admin/embarque',data=payload(p,registro=registration));check(s==200 and '✓ Embarcou' in b.decode(),'marcação real de presença no embarque')
s,p,_,_=admin.page('admin/mapa',{'viagem_id':trip});s,b,_,_=admin.request('api/admin/hold',json_data={'viagem_id':trip,'seats':[ids[3]]},csrf=csrf(p));check(s==200,'reserva manual utiliza retenção no mesmo inventário')
s,b,_,_=admin.request('admin/reserva/criar',data=payload(p,viagem_id=trip,**{'seats[]':[ids[3]],f'passageiros[{ids[3]}]':'Passageiro manual fictício','responsavel':'Responsável manual','telefone':'11988887777','desconto':'20,00','desconto_motivo':'Cortesia de teste'}));check(s==200 and 'ORIGEM MANUAL' in b.decode() and '160,00' in b.decode(),'venda manual com desconto justificado e preço persistido')
# Upload que se anuncia como imagem, mas contém texto, deve ser rejeitado antes de qualquer salvamento.
p=admin.page('admin/viagem',{'id':trip})[1];boundary='----RotaVivaTestBoundary';raw=(f'--{boundary}\r\nContent-Disposition: form-data; name="_csrf"\r\n\r\n{csrf(p)}\r\n--{boundary}\r\nContent-Disposition: form-data; name="capa"; filename="fake.jpg"\r\nContent-Type: image/jpeg\r\n\r\nIsto nao e uma imagem\r\n--{boundary}--\r\n').encode();s,*_=admin.request('admin/viagem/salvar',raw=raw,content_type='multipart/form-data; boundary='+boundary);check(s==422,'validação de upload rejeita falso JPG')
s,p,_,_=admin.page('admin/reserva',{'id':rid});s,*_=admin.request('admin/reserva/chave',data=payload(p,id=rid));check(s==200,'administrador renova chave privada sem guardar segredo em texto no banco')
s,*_=client.request('reserva',{'codigo':code});check(s==403,'rotação de chave invalida sessão de consulta anterior')
s,p,_,_=admin.page('admin/reserva',{'id':rid});s,*_=admin.request('admin/reserva/cancelar',data=payload(p,id=rid,motivo='Cancelamento fictício HTTP'));check(s==200,'cancelamento via painel mantém histórico financeiro')
s,b,_,_=pay('360','estorno');check(s==200 and 'Estorno' in b.decode(),'estorno manual registrado em reserva cancelada')
alt=Browser();p=alt.page('admin/login')[1];alt.request('admin/login',data=payload(p,email=fixture['admin_email'],senha=fixture['admin_password']))
p=admin.page('admin/configuracoes')[1];new_password='SenhaFicticia-'+os.urandom(8).hex();s,b,_,_=admin.request('admin/senha',data=payload(p,senha_atual=fixture['admin_password'],nova_senha=new_password,confirmacao=new_password));check(s==200 and 'Entrar no painel' in b.decode(),'alteração de senha encerra a sessão atual')
s,*_=alt.request('api/admin/poltrona',{'id':ids[0]});check(s==401,'alteração de senha invalida outras sessões administrativas')
p=admin.page('admin/login')[1];s,b,_,_=admin.request('admin/login',data=payload(p,email=fixture['admin_email'],senha=new_password));check(s==200 and 'Sua operação, em movimento.' in b.decode(),'nova senha permite autenticação')
s,p,_,_=admin.page('admin');s,b,_,_=admin.request('admin/logout',data=payload(p));check(s==200 and 'Entrar no painel' in b.decode(),'logout encerra a sessão administrativa')
s,*_=admin.request('api/admin/poltrona',{'id':ids[0]});check(s==401,'sessão encerrada não acessa API protegida')
s,b,_,_=other.request('viagem',{'id':'1 OR 1=1'});check(s in (200,404),'parâmetro de ID é convertido e consultas são preparadas')
for asset in ['app.css','app.js','seats.js','layout.js','journey.svg','bus.svg','destination.svg']:
 with other.opener.open(BASE+'/assets/'+asset,timeout=10) as r:check(r.status==200 and len(r.read())>100,'recurso local disponível '+asset)
check('frame-ancestors' in headers.get('Content-Security-Policy','') and headers.get('X-Content-Type-Options')=='nosniff','cabeçalhos de segurança presentes')
abuse=Browser();p=abuse.page('admin/login')[1]
for i in range(9):status,*_=abuse.request('admin/login',data=payload(p,email='inexistente-'+str(fixture['admin_id'])+'@example.invalid',senha='Tentativa incorreta'))
check(status==429,'limitação de tentativas de login bloqueia excesso')
print(f'\n{passed} verificações HTTP passaram. Nenhuma inspeção visual de navegador foi realizada.')
