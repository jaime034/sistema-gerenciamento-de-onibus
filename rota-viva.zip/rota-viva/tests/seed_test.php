<?php
require __DIR__ . '/../app/bootstrap.php';
use App\Core\Database as DB;
if (PHP_SAPI !== 'cli' || !str_ends_with(config('db.name'), '_test')) {
    exit(2);
}
if (DB::one('SELECT id FROM onibus WHERE demonstrativo=1 LIMIT 1')) {
    exit("Remova demonstrações anteriores antes deste teste.\n");
}
$before = (int) DB::one('SELECT COUNT(*) AS n FROM viagens WHERE demonstrativo=0')['n'];
DB::connection()->exec(file_get_contents(BASE_PATH . '/database/seeds/demo.sql'));
$counts = DB::one(
    'SELECT (SELECT COUNT(*) FROM onibus WHERE demonstrativo=1) AS onibus,(SELECT COUNT(*) FROM viagens WHERE demonstrativo=1) AS viagens,(SELECT COUNT(*) FROM reservas WHERE demonstrativo=1) AS reservas,(SELECT COUNT(*) FROM passageiros WHERE demonstrativo=1) AS passageiros',
);
if (array_map('intval', array_values($counts)) !== [1, 2, 1, 2]) {
    throw new RuntimeException('Seed não corresponde ao conjunto esperado.');
}
echo "PASSOU SEED: SQL cria ônibus, duas viagens, reserva e passageiros identificados como fictícios.\n";
$r = DB::one(
    'SELECT v.id,(SELECT COUNT(*) FROM viagens_poltronas s WHERE s.viagem_id=v.id) AS n FROM viagens v WHERE demonstrativo=1 LIMIT 1',
);
if ((int) $r['n'] !== 26) {
    throw new RuntimeException('Inventário demonstrativo incorreto.');
}
echo "PASSOU SEED: layout e inventário de 26 poltronas, com fileira incompleta.\n";
DB::connection()->exec(file_get_contents(BASE_PATH . '/database/seeds/remove_demo.sql'));
if (
    DB::one('SELECT id FROM viagens WHERE demonstrativo=1') ||
    DB::one('SELECT id FROM passageiros WHERE demonstrativo=1')
) {
    throw new RuntimeException('Restaram dados de demonstração.');
}
if ((int) DB::one('SELECT COUNT(*) AS n FROM viagens WHERE demonstrativo=0')['n'] !== $before) {
    throw new RuntimeException('Dados não demonstrativos foram alterados.');
}
echo "PASSOU SEED: remoção respeita FKs e preserva viagens não demonstrativas.\n";
