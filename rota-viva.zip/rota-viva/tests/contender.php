<?php
require __DIR__ . '/../app/bootstrap.php';
use App\Core\Database as DB;
use App\Services\BookingService;
if (PHP_SAPI !== 'cli' || !str_ends_with(config('db.name'), '_test')) {
    exit(2);
}
$d = json_decode(stream_get_contents(STDIN), true, 32, JSON_THROW_ON_ERROR);
file_put_contents($d['gate'] . '.' . $d['worker'], 'ready');
$limit = microtime(true) + 10;
while (!is_file($d['gate'])) {
    if (microtime(true) > $limit) {
        exit(3);
    }
    usleep(1000);
}
try {
    $b = new BookingService();
    $b->hold($d['trip'], $d['seats'], $d['owner']);
    $r = $b->create(
        $d['trip'],
        [
            'seats' => $d['seats'],
            'responsavel' => 'Disputa fictícia ' . $d['worker'],
            'telefone' => '11999990000',
            'aceite' => 1,
            'passageiros' => array_fill_keys($d['seats'], 'Passageiro fictício ' . $d['worker']),
        ],
        $d['owner'],
    );
    echo json_encode(['ok' => true, 'reservation' => $r['id']]);
} catch (\App\Core\HttpException $e) {
    echo json_encode(['ok' => false, 'status' => $e->status]);
}
