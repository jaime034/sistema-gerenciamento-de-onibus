/* Testes de interação DOM, sem navegador ou inspeção de layout.
   Dependência opcional de desenvolvimento: npm install --prefix /tmp/rv-ui linkedom
   NODE_PATH=/tmp/rv-ui/node_modules node tests/ui-dom.test.cjs
   Nenhuma dependência Node é necessária em produção. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const { parseHTML } = require('linkedom');
let count = 0;
const check = (value, label) => { assert.ok(value, label); count++; console.log('PASSOU DOM: ' + label); };
const settle = () => new Promise(resolve => setImmediate(resolve));
function context(html) {
    const { window } = parseHTML(html);
    const document = window.document;
    let active = null;
    Object.defineProperty(document, 'activeElement', { get: () => active });
    window.HTMLElement.prototype.focus = function () { active = this; };
    const intervals = [];
    const sandbox = { document, window, URL, URLSearchParams, console, Date, Math, Set, Map,
        Event: window.Event, navigator: {}, location: { hash: '', pathname: '/', search: '' },
        history: { replaceState() {}, back() {} }, confirm: () => true,
        setInterval: fn => { intervals.push(fn); return intervals.length; },
        setTimeout, clearTimeout, localStorage: { getItem: () => null, setItem() {} } };
    window.rvToast = () => {};
    const ctx = vm.createContext(sandbox);
    const click = el => el.dispatchEvent(new window.Event('click', { bubbles: true }));
    return { window, document, ctx, sandbox, click, intervals };
}
(async () => {
    const html = `<!doctype html><html><head><meta name="csrf-token" content="csrf-test"></head><body>
      <section data-seat-app data-trip="91" data-api="https://example.invalid/map" data-hold="https://example.invalid/hold" data-admin="0" data-max="2">
        <span data-map-connection></span><div data-seat-grid></div><div data-map-error hidden></div>
        <span data-selected-label></span><span data-total></span><p data-hold-timer></p>
        <form data-reservation-form><div data-passengers></div><button data-book-submit disabled></button></form>
      </section></body></html>`;
    const env = context(html), d = env.document;
    const seats = [
        { id: 901, numero: 'A1', fileira: 1, coluna: 1, janela: 1, estado: 'livre', mine: false },
        { id: 902, numero: '12', fileira: 1, coluna: 2, janela: 0, estado: 'livre', mine: false },
        { id: 903, numero: 'B7', fileira: 1, coluna: 4, janela: 0, estado: 'pendente', mine: false },
        { id: 904, numero: '99', fileira: 1, coluna: 5, janela: 1, estado: 'confirmada', mine: false },
        { id: 905, numero: 'Z1', fileira: 2, coluna: 1, janela: 1, estado: 'livre', mine: false },
        { id: 906, numero: 'X2', fileira: 2, coluna: 2, janela: 0, estado: 'livre', mine: false },
    ];
    const calls = [];
    env.sandbox.fetch = async (url, options = {}) => {
        calls.push({ url, options });
        if (options.method === 'POST') {
            const ids = JSON.parse(options.body).seats;
            const conflict = seats.some(s => ids.includes(s.id) && !['livre', 'hold'].includes(s.estado));
            if (conflict) return { ok: false, json: async () => ({ error: 'Lugar ocupado durante a seleção.' }) };
            for (const s of seats) if (s.mine || ids.includes(s.id)) {
                s.mine = ids.includes(s.id); s.estado = s.mine ? 'hold' : 'livre';
                s.expira_em = s.mine ? new Date(Date.now() + 600000).toISOString().slice(0, 19).replace('T', ' ') : null;
            }
        }
        return { ok: true, json: async () => ({ seats: structuredClone(seats), rows: 2, price: '180.00', can_book: true, status: 'aberta', server_time: new Date().toISOString() }) };
    };
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../public/assets/seats.js'), 'utf8'), env.ctx);
    await settle();
    const button = id => d.querySelector(`[data-seat-id="${id}"]`);
    check(d.querySelectorAll('.seat').length === 6, 'quantidade e posições vêm da API, sem constante de lugares');
    check(d.querySelectorAll('.seat-space').length === 2, 'fileira incompleta conserva espaços inexistentes');
    check(button(901).textContent.includes('A1') && button(901).getAttribute('aria-label').includes('janela'), 'numeração personalizada e janela têm descrição acessível');
    check(button(903).disabled && button(904).disabled, 'cliente não seleciona lugares pendentes ou confirmados');
    env.click(button(901)); await settle();
    check(button(901).getAttribute('aria-pressed') === 'true', 'clique seleciona somente após confirmação do servidor');
    check(calls.some(c => c.options.method === 'POST' && JSON.parse(c.options.body).seats.includes(901)), 'seleção efetivamente envia os IDs ao servidor');
    check(d.querySelector('[data-total]').textContent.includes('180,00'), 'total acompanha preço real recebido da API');
    check(!d.querySelector('[data-book-submit]').disabled, 'conclusão habilitada quando a retenção é válida');
    const input = d.querySelector('[data-passenger-id="901"]'); input.value = 'Passageiro digitado';
    env.click(button(902)); await settle();
    check(d.querySelectorAll('[data-passenger-id]').length === 2 && d.querySelector('[data-total]').textContent.includes('360,00'), 'seleção múltipla gera passageiros e soma valores');
    check(d.querySelector('[data-passenger-id="901"]').value === 'Passageiro digitado', 'nome digitado é preservado ao alterar a seleção');
    const before = calls.length; env.click(button(905)); await settle();
    check(calls.length === before && d.querySelector('[data-map-error]').textContent.includes('até 2'), 'limite de seleção impede excesso antes do envio');
    env.click(button(902)); await settle();
    check(button(902).getAttribute('aria-pressed') === 'false' && d.querySelectorAll('[data-passenger-id]').length === 1, 'novo clique desmarca e libera o lugar');
    button(901).focus(); const key = new env.window.Event('keydown', { bubbles: true }); key.key = 'ArrowRight'; button(901).dispatchEvent(key);
    check(d.activeElement === button(902), 'seta move o foco entre poltronas disponíveis');
    seats.find(s => s.id === 905).estado = 'bloqueada'; env.click(button(905)); await settle();
    check(button(905).disabled && !button(905).classList.contains('state-selected'), 'conflito retornado pelo servidor remove escolha indisponível');
    check(d.querySelector('[data-passenger-id="901"]').value === 'Passageiro digitado', 'atualização de disponibilidade preserva dados já preenchidos');
    env.click(button(901)); await settle();
    check(d.querySelector('[data-book-submit]').disabled && d.querySelector('[data-selected-label]').textContent.includes('Nenhuma'), 'sem poltrona retida o formulário não pode ser concluído');

    const ed = context(`<!doctype html><html><body><form data-layout-editor><input data-row-count name="fileiras" value="2"><input data-generate-count value="5"><button type="button" data-generate></button><button type="button" data-rows></button><strong data-layout-count></strong><div data-layout-grid></div></form></body></html>`);
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../public/assets/layout.js'), 'utf8'), ed.ctx);
    ed.click(ed.document.querySelector('[data-generate]'));
    check(ed.document.querySelectorAll('.layout-cell').length === 8, 'editor gera duas fileiras para cinco lugares');
    check([...ed.document.querySelectorAll('input[name$="[numero]"]')].filter(x => x.value).length === 5, 'editor deixa vazias as posições que não existem');
    const n = ed.document.querySelector('input[name="layout[1][1][numero]"]'); n.value = 'J-7';
    ed.document.querySelector('[data-row-count]').value = '3'; ed.click(ed.document.querySelector('[data-rows]'));
    check(ed.document.querySelector('input[name="layout[1][1][numero]"]').value === 'J-7', 'alterar fileiras preserva números personalizados');
    check(ed.document.querySelector('[data-layout-count]').textContent.includes('5'), 'contagem reflete apenas poltronas numeradas');
    console.log(`\n${count} verificações DOM passaram. Layout responsivo e desenho visual não são medidos por esta suíte.`);
})().catch(e => { console.error(e); process.exit(1); });
