#!/usr/bin/env python3
"""Teste local do primeiro cadastro. Requer outro banco VAZIO existente em RV_SETUP_DB.
Faz uma troca temporária no config.php local e restaura o conteúdo ao terminar.
Use apenas com servidor local de testes, sem outros acessos simultâneos.
"""
import json, pathlib, urllib.parse, sys, os, secrets
# Executado com o mesmo banco local já ativo; configura um banco separado e volta ao final.
project=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(project/'tests'))
# Não importa a suíte HTTP (ela executa ao importar); faz requisições mínimas aqui.
import http.cookiejar,urllib.request,urllib.error,re
jar=http.cookiejar.CookieJar();opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPCookieProcessor(jar))
def call(route,data=None):
 u=(sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8089')+'/index.php?'+urllib.parse.urlencode({'r':route})
 req=urllib.request.Request(u,data=urllib.parse.urlencode(data).encode() if data else None)
 try:r=opener.open(req,timeout=15)
 except urllib.error.HTTPError as e:r=e
 return r.status,r.read().decode()
def csrf(s):
 import html
 return html.unescape(re.search(r'name="_csrf"\s+value="([^"]+)"',s).group(1))
base=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8089'
if not base.startswith(('http://127.0.0.1:','http://localhost:')):raise SystemExit('Use somente um servidor local de testes.')
test_db=os.environ.get('RV_SETUP_DB','')
if not re.fullmatch(r'[a-zA-Z0-9_]{1,59}_test',test_db):raise SystemExit('RV_SETUP_DB deve identificar um banco vazio terminado em _test.')
cfg=project/'config/config.php';saved=cfg.read_text()
if not re.search(r"['\"]environment['\"]\s*=>\s*['\"]local['\"]",saved):raise SystemExit('O ambiente precisa ser local.')
name_pattern=r"(['\"]name['\"]\s*=>\s*)['\"]([^'\"]+)['\"]"
current=re.search(name_pattern,saved)
if not current or not current.group(2).endswith('_test'):raise SystemExit('A configuração atual também precisa usar um banco _test.')
try:
 cfg.write_text(re.sub(name_pattern,lambda m:m.group(1)+"'"+test_db+"'",saved,count=1))
 token=re.search(r"['\"]setup_token['\"]\s*=>\s*['\"]([^'\"]+)",saved).group(1)
 s,p=call('instalar');assert s==200
 password='SenhaQA-'+secrets.token_hex(12)
 data={'_csrf':csrf(p),'setup_token':token,'nome':'Instalação fictícia','email':'setup@example.invalid','senha':password,'confirmacao':password}
 s,p=call('instalar',data);assert s==200 and 'Entrar no painel' in p
 print('PASSOU SETUP: assistente web instala SQL em banco vazio e cria primeiro administrador.',flush=True)
 s,p=call('instalar');data['_csrf']=csrf(p);s,p=call('instalar',data);assert s==403
 print('PASSOU SETUP: instalação já concluída impede cadastro adicional.',flush=True)
finally:cfg.write_text(saved)
