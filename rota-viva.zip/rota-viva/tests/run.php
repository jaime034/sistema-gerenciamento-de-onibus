<?php
// Banco EXCLUSIVO para testes. Não executa em nomes que não terminem com _test.
require __DIR__ . '/../app/bootstrap.php';
use App\Core\{Database as DB, HttpException, Money, Security};
use App\Services\{
    BookingService,
    FleetService,
    TripService,
    PaymentService,
    PdfService,
    ReportService,
};
if (PHP_SAPI !== 'cli' || !str_ends_with(config('db.name'), '_test')) {
    exit("Configure um banco isolado com nome terminado em _test.\n");
}
$passed = 0;
function check(bool $condition, string $label): void
{
    global $passed;
    if (!$condition) {
        throw new RuntimeException('FALHOU: ' . $label);
    }
    echo 'PASSOU: ' . $label . PHP_EOL;
    $passed++;
}
function reject(callable $fn, int $status, string $label): void
{
    try {
        $fn();
    } catch (HttpException $e) {
        check($e->status === $status, $label);
        return;
    }
    throw new RuntimeException('FALHOU: operação aceita — ' . $label);
}
if (
    !DB::one(
        "SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='usuarios'",
    )['n']
) {
    DB::connection()->exec(file_get_contents(BASE_PATH . '/database/install.sql'));
}
check(
    (int) DB::one(
        'SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema=DATABASE()',
    )['n'] === 14,
    'instalação SQL: 14 tabelas com migração registrada',
);
check(
    Money::cents('1.234,56') === 123456 && Money::decimal(123456) === '1234.56',
    'valores monetários sem cálculo binário',
);
reject(fn() => Money::cents('-5'), 422, 'valores negativos rejeitados');
reject(
    fn() => utcinput('2026-02-30T10:00'),
    422,
    'data impossível não é normalizada silenciosamente',
);
reject(fn() => utcinput('tomorrow'), 422, 'data relativa enviada pelo navegador é rejeitada');
check(
    utcinput('2026-10-16T10:00') === '2026-10-16 13:00:00',
    'conversão explícita de data brasileira para UTC',
);
$stamp = bin2hex(random_bytes(5));
$email = 'qa-' . $stamp . '@example.invalid';
$password = bin2hex(random_bytes(12));
DB::run('INSERT INTO usuarios(nome,email,senha_hash) VALUES(?,?,?)', [
    'Proprietário fictício QA',
    $email,
    password_hash($password, PASSWORD_DEFAULT),
]);
$admin = (int) DB::connection()->lastInsertId();
$_SESSION = ['admin' => ['id' => $admin, 'version' => 1, 'last' => time()]];
check(
    password_verify(
        $password,
        DB::one('SELECT senha_hash FROM usuarios WHERE id=?', [$admin])['senha_hash'],
    ),
    'senha administrativa armazenada como hash',
);
$layoutData = [];
$nums = ['11', '12', 'A1', 'A2', '21', '22', '31'];
$i = 0;
foreach ([1, 2, 3] as $r) {
    foreach ([1, 2, 4, 5] as $c) {
        if ($i < count($nums)) {
            $layoutData[$r][$c] =
                ['numero' => $nums[$i++], 'ativa' => 1] +
                (in_array($c, [1, 5]) ? ['janela' => 1] : []);
        }
    }
}
$fleet = new FleetService();
$bus = $fleet->save([
    'identificacao' => 'Ônibus QA ' . $stamp,
    'modelo' => 'Fictício',
    'fileiras' => 3,
    'layout' => $layoutData,
]);
$layout = (int) DB::one('SELECT MAX(id) AS id FROM layouts_onibus WHERE onibus_id=?', [$bus])['id'];
check(
    (int) DB::one('SELECT COUNT(*) AS n FROM poltronas WHERE layout_id=?', [$layout])['n'] === 7,
    'ônibus e layout de 7 lugares com fileiras incompletas e números personalizados',
);
$fleet->save([
    'id' => $bus,
    'identificacao' => 'Ônibus QA ' . $stamp,
    'fileiras' => 3,
    'layout' => $layoutData,
]);
check(
    (int) DB::one('SELECT COUNT(*) AS n FROM layouts_onibus WHERE onibus_id=?', [$bus])['n'] === 2,
    'alterar layout cria versão sem apagar anterior',
);
$tripService = new TripService();
function trip(array $override = []): int
{
    global $layout, $tripService, $stamp;
    return $tripService->save(
        $override + [
            'nome' => 'Viagem QA ' . $stamp,
            'origem' => 'São Paulo',
            'destino' => 'Destino fictício',
            'partida' => date('Y-m-d\TH:i', time() + 14 * 86400),
            'retorno' => '',
            'embarque' => 'Ponto fictício 1',
            'preco' => '180,00',
            'layout_id' => $layout,
            'status' => 'aberta',
        ],
    );
}
$b = new BookingService();
$pay = new PaymentService();
$trip = trip();
$seats = DB::all('SELECT * FROM viagens_poltronas WHERE viagem_id=? ORDER BY id', [$trip]);
$ids = array_map('intval', array_column($seats, 'id'));
check(count($b->map($trip, 'owner1')['seats']) === 7, 'mapa gerado pelo inventário da viagem');
check(
    !isset($b->map($trip, 'owner1')['seats'][0]['reserva_id']),
    'mapa público sem IDs de reservas ou passageiros',
);
$b->hold($trip, [$ids[0], $ids[1]], 'owner1');
check(
    $b->map($trip, 'owner1')['seats'][0]['mine'] === true,
    'seleção temporária reconhece proprietário',
);
reject(
    fn() => $b->hold($trip, [$ids[0], $ids[2]], 'owner2'),
    409,
    'conflito no grupo rejeita toda a seleção',
);
check(
    DB::one('SELECT estado FROM viagens_poltronas WHERE id=?', [$ids[2]])['estado'] === 'livre',
    'falha de grupo não ocupa outra poltrona',
);
function book(int $trip, array $ids, string $owner = 'owner1', ?int $adminId = null): array
{
    global $b;
    return $b->create(
        $trip,
        [
            'seats' => $ids,
            'responsavel' => 'Responsável fictício',
            'telefone' => '11999990000',
            'aceite' => 1,
            'passageiros' => array_fill_keys($ids, 'Passageiro fictício <teste>'),
        ],
        $owner,
        $adminId,
    );
}
$res = book($trip, [$ids[0], $ids[1]]);
$rid = $res['id'];
check(
    count(App\Repositories\Reservations::passengers($rid)) === 2,
    'reserva atômica com múltiplos passageiros',
);
check(
    DB::one('SELECT total FROM reservas WHERE id=?', [$rid])['total'] === '360.00',
    'preço calculado a partir da viagem no servidor',
);
check(
    !str_contains(
        DB::one('SELECT token_hash FROM reservas WHERE id=?', [$rid])['token_hash'],
        $res['token'],
    ),
    'chave privada armazenada somente como HMAC',
);
reject(
    fn() => $b->hold($trip, [$ids[0]], 'owner2'),
    409,
    'poltrona pendente não pode ser selecionada',
);
function payment(int $id, string $value, string $type = 'recebimento', ?string $key = null): void
{
    global $admin, $pay;
    $pay->record(
        $id,
        [
            'valor' => $value,
            'tipo' => $type,
            'metodo' => 'Pix',
            'pago_em' => date('Y-m-d\TH:i'),
            'observacoes' => 'Lançamento fictício QA',
            'idempotencia' => $key ?? bin2hex(random_bytes(32)),
        ],
        $admin,
    );
}
$idem = bin2hex(random_bytes(32));
payment($rid, '100', 'recebimento', $idem);
payment($rid, '100', 'recebimento', $idem);
check(PaymentService::balance($rid) === 10000, 'pagamento parcial e idempotência de reenvio');
reject(
    fn() => payment($rid, '99', 'recebimento', $idem),
    409,
    'reutilização conflitante de chave financeira é rejeitada',
);
DB::run('UPDATE reservas SET prazo_pagamento=UTC_TIMESTAMP()-INTERVAL 1 DAY WHERE id=?', [$rid]);
$b->expireAll();
check(
    DB::one('SELECT status FROM reservas WHERE id=?', [$rid])['status'] === 'parcial',
    'pagamento parcial não expira automaticamente',
);
payment($rid, '260');
check(
    DB::one('SELECT status FROM reservas WHERE id=?', [$rid])['status'] === 'confirmada',
    'pagamento integral confirma reserva e inventário',
);
reject(fn() => payment($rid, '1'), 422, 'recebimento acima do total rejeitado');
$pdf = PdfService::document('Comprovante de passagem', [
    'Reserva ' . $res['code'],
    'Passageiro fictício',
    'São Paulo → Destino fictício',
    'Poltrona 11',
]);
$pdfFile = sys_get_temp_dir() . '/rota-viva-test.pdf';
file_put_contents($pdfFile, $pdf);
check(
    str_starts_with($pdf, '%PDF-1.4') && str_contains($pdf, 'startxref'),
    'PDF real com estrutura e referências',
);
$b->transfer($rid, (int) App\Repositories\Reservations::passengers($rid)[0]['id'], $ids[2]);
check(
    DB::one('SELECT estado FROM viagens_poltronas WHERE id=?', [$ids[0]])['estado'] === 'livre' &&
        (int) DB::one('SELECT reserva_id FROM viagens_poltronas WHERE id=?', [$ids[2]])[
            'reserva_id'
        ] === $rid,
    'transferência atômica libera lugar anterior',
);
reject(
    fn() => $b->block($trip, $ids[2], true, 'Teste'),
    409,
    'bloqueio administrativo não sobrepõe ocupação',
);
$b->block($trip, $ids[3], true, 'Manutenção fictícia');
check(
    DB::one('SELECT estado FROM viagens_poltronas WHERE id=?', [$ids[3]])['estado'] === 'bloqueada',
    'bloqueio administrativo funciona',
);
$b->block($trip, $ids[3], false, '');
check(
    DB::one('SELECT estado FROM viagens_poltronas WHERE id=?', [$ids[3]])['estado'] === 'livre',
    'desbloqueio funciona',
);
$b->hold($trip, [$ids[3]], 'short');
DB::run('UPDATE viagens_poltronas SET expira_em=UTC_TIMESTAMP()-INTERVAL 1 SECOND WHERE id=?', [
    $ids[3],
]);
$b->map($trip, 'short');
check(
    DB::one('SELECT estado FROM viagens_poltronas WHERE id=?', [$ids[3]])['estado'] === 'livre',
    'expiração oportunista da seleção sem cron',
);
$b->hold($trip, [$ids[3]], 'pending');
$exp = book($trip, [$ids[3]], 'pending');
DB::run('UPDATE reservas SET prazo_pagamento=UTC_TIMESTAMP()-INTERVAL 1 SECOND WHERE id=?', [
    $exp['id'],
]);
$b->expireAll();
check(
    DB::one('SELECT status FROM reservas WHERE id=?', [$exp['id']])['status'] === 'expirada' &&
        DB::one('SELECT estado FROM viagens_poltronas WHERE id=?', [$ids[3]])['estado'] === 'livre',
    'reserva sem recebimentos expira e libera assento',
);
$b->hold($trip, [$ids[4]], 'manual', true);
$manual = book($trip, [$ids[4]], 'manual', $admin);
check(
    DB::one('SELECT origem FROM reservas WHERE id=?', [$manual['id']])['origem'] === 'manual',
    'reserva manual obedece ao mesmo inventário',
);
$b->cancel($rid, 'Cancelamento fictício');
check(
    PaymentService::balance($rid) === 36000 &&
        DB::one('SELECT estado FROM viagens_poltronas WHERE id=?', [$ids[2]])['estado'] === 'livre',
    'cancelamento libera assentos e preserva recebimentos',
);
payment($rid, '360', 'estorno');
check(
    PaymentService::balance($rid) === 0 &&
        DB::one('SELECT status FROM reservas WHERE id=?', [$rid])['status'] === 'cancelada',
    'estorno conserva histórico e estado de cancelamento',
);
reject(
    fn() => trip(['id' => $trip, 'destino' => 'Destino alterado']),
    409,
    'viagem com reservas preserva roteiro histórico',
);
$duplicate = $tripService->duplicate($trip);
check(
    DB::one('SELECT status FROM viagens WHERE id=?', [$duplicate])['status'] === 'rascunho',
    'duplicação cria rascunho com novo inventário',
);
$violated = false;
try {
    DB::run("UPDATE viagens_poltronas SET estado='confirmada',reserva_id=NULL WHERE id=?", [
        $ids[0],
    ]);
} catch (PDOException) {
    $violated = true;
}
check($violated, 'CHECK do banco impede estado inconsistente');
$violated = false;
try {
    DB::run(
        'INSERT INTO viagens_poltronas(viagem_id,poltrona_id,numero,fileira,coluna,janela) SELECT viagem_id,poltrona_id,numero,fileira,coluna,janela FROM viagens_poltronas WHERE id=?',
        [$ids[0]],
    );
} catch (PDOException) {
    $violated = true;
}
check($violated, 'unicidade do inventário impede assento duplicado');
$raceTrip = trip(['nome' => 'Concorrência QA ' . $stamp]);
$raceIds = array_map(
    'intval',
    array_column(
        DB::all('SELECT id FROM viagens_poltronas WHERE viagem_id=? ORDER BY id LIMIT 2', [
            $raceTrip,
        ]),
        'id',
    ),
);
$gate = sys_get_temp_dir() . '/rota-viva-race-' . $stamp;
$children = [];
for ($i = 1; $i <= 2; $i++) {
    $cmd = [PHP_BINARY];
    if (php_ini_loaded_file()) {
        array_push($cmd, '-c', php_ini_loaded_file());
    }
    $cmd[] = __DIR__ . '/contender.php';
    $proc = proc_open($cmd, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
    fwrite(
        $pipes[0],
        json_encode([
            'trip' => $raceTrip,
            'seats' => $raceIds,
            'owner' => 'worker' . $i,
            'worker' => $i,
            'gate' => $gate,
        ]),
    );
    fclose($pipes[0]);
    $children[] = [$proc, $pipes];
}
$limit = microtime(true) + 10;
while (!is_file($gate . '.1') || !is_file($gate . '.2')) {
    if (microtime(true) > $limit) {
        throw new RuntimeException('Barreira da concorrência expirou.');
    }
    usleep(1000);
}
file_put_contents($gate, 'go');
$outcomes = [];
foreach ($children as [$proc, $pipes]) {
    $out = stream_get_contents($pipes[1]);
    $err = stream_get_contents($pipes[2]);
    fclose($pipes[1]);
    fclose($pipes[2]);
    $code = proc_close($proc);
    if ($code !== 0) {
        throw new RuntimeException($err);
    }
    $outcomes[] = json_decode($out, true, 32, JSON_THROW_ON_ERROR);
}
foreach ([$gate, $gate . '.1', $gate . '.2'] as $f) {
    unlink($f);
}
check(
    count(array_filter($outcomes, fn($o) => $o['ok'])) === 1 &&
        count(array_filter($outcomes, fn($o) => !$o['ok'] && $o['status'] === 409)) === 1,
    'concorrência real: dois processos disputam duas poltronas, apenas um reserva o grupo',
);
check(
    (int) DB::one(
        'SELECT COUNT(DISTINCT reserva_id) AS n FROM viagens_poltronas WHERE viagem_id=? AND reserva_id IS NOT NULL',
        [$raceTrip],
    )['n'] === 1,
    'concorrência mantém exatamente uma ocupação ativa para cada assento',
);
$report = ReportService::make(['tipo' => 'passageiros', 'viagem_id' => $trip]);
check(count($report['rows']) === 1, 'relatório de passageiros exclui canceladas e expiradas');
$httpTrip = trip(['nome' => 'Fluxo HTTP QA ' . $stamp]);
if ($path = getenv('RV_TEST_FIXTURE')) {
    file_put_contents(
        $path,
        json_encode([
            'trip_id' => $httpTrip,
            'admin_email' => $email,
            'admin_password' => $password,
            'admin_id' => $admin,
            'pdf' => $pdfFile,
        ]),
    );
}
echo "\n$passed verificações passaram. Banco e dados usados exclusivamente para testes.\n";
