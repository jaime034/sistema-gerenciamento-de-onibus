<?php
// Copie para config/config.php. Este arquivo fica FORA da raiz pública.
return [
    'app_url' => 'http://192.168.1.84/rota-viva/public', // URL absoluta, sem barra final; inclua /subpasta se houver.
    'environment' => 'local', // local somente para desenvolvimento sem HTTPS.
    'trusted_proxies' => [], // IPs exatos do proxy da hospedagem, somente se necessário.
    'timezone' => 'America/Sao_Paulo',
    'app_key' => '662511229c86626c04384a663311fec1714c82ef80feb4d4cdb34e76b4234a64', // 64 caracteres hex aleatórios. O instalador gera para você.
    'setup_token' => '', // Segredo temporário de 32+ caracteres para /instalar.
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'rota_viva',
        'user' => 'root',
        'password' => '',
    ],
];
