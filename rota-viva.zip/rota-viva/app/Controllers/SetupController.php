<?php
namespace App\Controllers;
use App\Core\{Database as DB, HttpException, Security, Validator};
final class SetupController
{
    public function show(): void
    {
        $ready =
            is_file(BASE_PATH . '/config/config.php') &&
            strlen(config('app_key', '')) >= 32 &&
            strlen(config('setup_token', '')) >= 32;
        require BASE_PATH . '/app/Views/public/setup.php';
    }
    public function install(): never
    {
        if (
            !is_file(BASE_PATH . '/config/config.php') ||
            strlen(config('setup_token', '')) < 32 ||
            strlen(config('app_key', '')) < 32
        ) {
            throw new HttpException(403, 'Configure config/config.php antes de instalar.');
        }
        if (
            config('environment') === 'production' &&
            (!str_starts_with(config('app_url'), 'https://') || !Security::isHttps())
        ) {
            throw new HttpException(
                403,
                'A instalação em produção requer HTTPS. Configure-o no domínio primeiro.',
            );
        }
        if (!hash_equals(config('setup_token'), (string) ($_POST['setup_token'] ?? ''))) {
            usleep(300000);
            throw new HttpException(403, 'Chave de instalação inválida.');
        }
        $name = Validator::text($_POST, 'nome', 120);
        $email = Validator::email(mb_strtolower(Validator::text($_POST, 'email', 190)));
        $password = (string) ($_POST['senha'] ?? '');
        if (
            !$email ||
            strlen($password) < 12 ||
            strlen($password) > 72 ||
            $password !== ($_POST['confirmacao'] ?? '')
        ) {
            throw new HttpException(422, 'Use uma senha de 12 a 72 caracteres e confirme-a.');
        }
        // GET_LOCK serializa tentativas de instalação. DDL MySQL faz commit implícito.
        $db = DB::connection();
        $lock = DB::one("SELECT GET_LOCK('rota_viva_setup',5) AS ok");
        if (!$lock['ok']) {
            throw new HttpException(409, 'Há outra instalação em andamento.');
        }
        try {
            $exists = DB::one(
                "SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='usuarios'",
            );
            if (!$exists['n']) {
                $sql = file_get_contents(BASE_PATH . '/database/install.sql');
                $db->exec($sql);
            }
            if (DB::one('SELECT id FROM usuarios LIMIT 1')) {
                throw new HttpException(
                    403,
                    'A instalação foi encerrada. Já existe um administrador.',
                );
            }
            DB::run('INSERT INTO usuarios(nome,email,senha_hash) VALUES(?,?,?)', [
                $name,
                $email,
                password_hash($password, PASSWORD_DEFAULT),
            ]);
        } finally {
            DB::run("SELECT RELEASE_LOCK('rota_viva_setup')");
        }
        flash('Instalação concluída. Remova setup_token da configuração e entre no painel.');
        redirect('admin/login');
    }
}
