<?php
namespace App\Controllers;
use App\Core\{Database as DB, HttpException, Security, Validator, View};
use App\Services\Audit;
final class AuthController
{
    public function login(): void
    {
        if (Security::user()) {
            redirect('admin');
        }
        View::render('admin/login', ['title' => 'Acesso do proprietário'], 'auth');
    }
    public function authenticate(): never
    {
        Security::rate('login-ip', 30, 900);
        $email = mb_strtolower(trim((string) ($_POST['email'] ?? '')));
        Security::rate('login-email', 8, 900, $email, false);
        $password = (string) ($_POST['senha'] ?? '');
        $u = DB::one('SELECT * FROM usuarios WHERE email=? AND ativo=1', [$email]);
        $dummy = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi';
        if (!$u || !password_verify($password, $u['senha_hash'])) {
            if (!$u) {
                password_verify($password, $dummy);
            }
            throw new HttpException(401, 'E-mail ou senha incorretos.');
        }
        session_regenerate_id(true);
        $_SESSION['admin'] = [
            'id' => (int) $u['id'],
            'version' => (int) $u['session_version'],
            'last' => time(),
        ];
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
        if (password_needs_rehash($u['senha_hash'], PASSWORD_DEFAULT)) {
            DB::run('UPDATE usuarios SET senha_hash=? WHERE id=?', [
                password_hash($password, PASSWORD_DEFAULT),
                $u['id'],
            ]);
        }
        Audit::log('login_realizado', [], null, null, (int) $u['id']);
        redirect('admin');
    }
    public function logout(): never
    {
        $u = Security::requireAdmin();
        Audit::log('logout_realizado', [], null, null, (int) $u['id']);
        $_SESSION = [];
        session_regenerate_id(true);
        flash('Você saiu do painel.');
        redirect('admin/login');
    }
    public function password(): never
    {
        $u = Security::requireAdmin();
        $row = DB::one('SELECT senha_hash FROM usuarios WHERE id=?', [$u['id']]);
        if (!password_verify((string) ($_POST['senha_atual'] ?? ''), $row['senha_hash'])) {
            throw new HttpException(422, 'A senha atual está incorreta.');
        }
        $new = (string) ($_POST['nova_senha'] ?? '');
        if (strlen($new) < 12 || strlen($new) > 72 || $new !== ($_POST['confirmacao'] ?? '')) {
            throw new HttpException(
                422,
                'Use uma nova senha de 12 a 72 caracteres e confirme corretamente.',
            );
        }
        DB::transaction(function () use ($new, $u) {
            DB::run(
                'UPDATE usuarios SET senha_hash=?,session_version=session_version+1 WHERE id=?',
                [password_hash($new, PASSWORD_DEFAULT), $u['id']],
            );
            Audit::log('senha_alterada', [], null, null, (int) $u['id']);
        });
        unset($_SESSION['admin']);
        session_regenerate_id(true);
        flash('Senha alterada. Entre novamente.');
        redirect('admin/login');
    }
}
