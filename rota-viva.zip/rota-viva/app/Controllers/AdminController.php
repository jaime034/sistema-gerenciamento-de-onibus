<?php
namespace App\Controllers;
use App\Core\{Database as DB, HttpException, Security, Validator, View, Money};
use App\Repositories\{Trips, Reservations, Settings};
use App\Services\{
    Audit,
    BookingService,
    FleetService,
    TripService,
    PaymentService,
    UploadService,
    PdfService,
    ReportService,
};
final class AdminController
{
    private function render(string $v, array $d = []): void
    {
        View::render('admin/' . $v, $d, 'admin');
    }
    public function dashboard(): void
    {
        (new BookingService())->expireAll();
        [$start, $end] = ReportService::range($_GET);
        $stats = DB::one(
            "SELECT (SELECT COUNT(*) FROM viagens WHERE status='aberta' AND partida>UTC_TIMESTAMP()) AS abertas,(SELECT COUNT(*) FROM reservas WHERE status IN('pendente','parcial')) AS pendentes,(SELECT COUNT(*) FROM reservas_passageiros rp JOIN reservas r ON r.id=rp.reserva_id WHERE r.status='confirmada') AS passageiros,(SELECT COALESCE(SUM(CASE WHEN tipo='recebimento' THEN valor ELSE -valor END),0) FROM pagamentos WHERE pago_em BETWEEN ? AND ?) AS recebido",
            [$start, $end],
        );
        $stats['a_receber'] = DB::one(
            "SELECT COALESCE(SUM(GREATEST(0,r.total-COALESCE((SELECT SUM(CASE WHEN tipo='recebimento' THEN valor ELSE -valor END) FROM pagamentos p WHERE p.reserva_id=r.id),0))),0) AS n FROM reservas r WHERE r.status IN('pendente','parcial')",
        )['n'];
        $trips = DB::all(
            "SELECT v.*,(SELECT COUNT(*) FROM viagens_poltronas s WHERE s.viagem_id=v.id) AS capacidade,(SELECT COUNT(*) FROM viagens_poltronas s WHERE s.viagem_id=v.id AND s.estado IN('pendente','confirmada')) AS ocupadas,(SELECT COUNT(*) FROM viagens_poltronas s WHERE s.viagem_id=v.id AND s.estado='livre') AS livres FROM viagens v WHERE v.partida>=UTC_TIMESTAMP() AND v.status NOT IN('cancelada','concluida') ORDER BY partida LIMIT 6",
        );
        $pending = Reservations::listing(['status' => 'pendente']);
        $events = DB::all(
            'SELECT evento,created_at,reserva_id FROM auditoria ORDER BY id DESC LIMIT 8',
        );
        $revenue = DB::all(
            "SELECT DATE(pago_em) AS dia,SUM(CASE WHEN tipo='recebimento' THEN valor ELSE -valor END) AS valor FROM pagamentos WHERE pago_em BETWEEN ? AND ? GROUP BY DATE(pago_em) ORDER BY dia",
            [$start, $end],
        );
        $this->render(
            'dashboard',
            compact('stats', 'trips', 'pending', 'events', 'revenue') + ['title' => 'Visão geral'],
        );
    }
    public function trips(): void
    {
        (new BookingService())->expireAll();
        $trips = Trips::listing($_GET, true);
        $this->render('trips', compact('trips') + ['title' => 'Suas viagens']);
    }
    public function tripForm(): void
    {
        $trip = isset($_GET['id']) ? Trips::find((int) $_GET['id']) : null;
        if (isset($_GET['id']) && !$trip) {
            throw new HttpException(404, 'Viagem não encontrada.');
        }
        $layouts = DB::all(
            'SELECT l.*,o.identificacao,(SELECT COUNT(*) FROM poltronas p WHERE p.layout_id=l.id AND ativa=1) AS lugares FROM layouts_onibus l JOIN onibus o ON o.id=l.onibus_id WHERE o.ativo=1 ORDER BY l.id DESC',
        );
        $has = $trip && DB::one('SELECT id FROM reservas WHERE viagem_id=? LIMIT 1', [$trip['id']]);
        $this->render(
            'trip-form',
            compact('trip', 'layouts', 'has') + [
                'title' => $trip ? 'Editar viagem' : 'Nova viagem',
            ],
        );
    }
    public function tripSave(): never
    {
        $data = $_POST;
        if ($image = UploadService::image('capa')) {
            $data['capa_salva'] = $image;
        }
        $id = (new TripService())->save($data);
        flash('Viagem salva com sucesso.');
        redirect('admin/viagens');
    }
    public function duplicate(): never
    {
        $id = (new TripService())->duplicate((int) ($_POST['id'] ?? 0));
        flash('Cópia criada como rascunho. Revise as datas antes de publicar.');
        redirect('admin/viagem', ['id' => $id]);
    }
    public function fleet(): void
    {
        $buses = DB::all(
            'SELECT o.*,(SELECT MAX(l.id) FROM layouts_onibus l WHERE l.onibus_id=o.id) AS layout_atual FROM onibus o ORDER BY o.id',
        );
        $this->render('fleet', compact('buses') + ['title' => 'Ônibus e poltronas']);
    }
    public function fleetForm(): void
    {
        $bus = isset($_GET['id'])
            ? DB::one('SELECT * FROM onibus WHERE id=?', [(int) $_GET['id']])
            : null;
        if (isset($_GET['id']) && !$bus) {
            throw new HttpException(404, 'Ônibus não encontrado.');
        }
        $layout = $bus
            ? DB::one(
                'SELECT * FROM layouts_onibus WHERE onibus_id=? ORDER BY versao DESC LIMIT 1',
                [$bus['id']],
            )
            : null;
        $seats = $layout
            ? DB::all('SELECT * FROM poltronas WHERE layout_id=? ORDER BY fileira,coluna', [
                $layout['id'],
            ])
            : [];
        $this->render(
            'fleet-form',
            compact('bus', 'layout', 'seats') + [
                'title' => $bus ? 'Editar configuração' : 'Cadastrar ônibus',
            ],
        );
    }
    public function fleetSave(): never
    {
        $id = (new FleetService())->save($_POST);
        flash('Configuração salva em uma nova versão. Viagens existentes preservam seu mapa.');
        redirect('admin/onibus');
    }
    public function reservations(): void
    {
        (new BookingService())->expireAll();
        $reservations = Reservations::listing($_GET);
        $trips = Trips::listing([], true);
        $this->render('reservations', compact('reservations', 'trips') + ['title' => 'Reservas']);
    }
    private function reservation(): array
    {
        $r = Reservations::find((int) ($_GET['id'] ?? ($_POST['id'] ?? 0)));
        if (!$r) {
            throw new HttpException(404, 'Reserva não encontrada.');
        }
        return $r;
    }
    public function reservationDetail(): void
    {
        (new BookingService())->expireAll();
        $r = $this->reservation();
        $passengers = Reservations::passengers((int) $r['id']);
        $payments = DB::all(
            'SELECT p.*,u.nome AS usuario FROM pagamentos p JOIN usuarios u ON u.id=p.registrado_por WHERE reserva_id=? ORDER BY p.id DESC',
            [$r['id']],
        );
        $history = DB::all(
            'SELECT a.*,u.nome AS usuario FROM auditoria a LEFT JOIN usuarios u ON u.id=a.usuario_id WHERE reserva_id=? ORDER BY a.id DESC',
            [$r['id']],
        );
        $free = DB::all(
            "SELECT id,numero FROM viagens_poltronas WHERE viagem_id=? AND estado='livre' ORDER BY fileira,coluna",
            [$r['viagem_id']],
        );
        $private = $_SESSION['admin_private'][$r['id']] ?? null;
        $this->render(
            'reservation-detail',
            compact('r', 'passengers', 'payments', 'history', 'free', 'private') + [
                'title' => 'Reserva ' . $r['codigo'],
            ],
        );
    }
    public function manual(): void
    {
        $trip = Trips::find((int) ($_GET['viagem_id'] ?? 0));
        if (!$trip) {
            $trips = Trips::listing(['status' => 'aberta'], true);
            $this->render('select-trip', compact('trips') + ['title' => 'Nova reserva manual']);
            return;
        }
        $admin = true;
        $map = (new BookingService())->map(
            (int) $trip['id'],
            Security::holdOwner((int) $trip['id']),
            true,
        );
        $this->render(
            'manual',
            compact('trip', 'admin', 'map') + ['title' => 'Mapa e venda manual'],
        );
    }
    public function map(): never
    {
        $id = (int) ($_GET['viagem_id'] ?? 0);
        View::json((new BookingService())->map($id, Security::holdOwner($id), true));
    }
    public function hold(): never
    {
        Security::rate('admin-hold', 200, 600);
        $d = \App\Core\Request::json();
        $id = (int) ($d['viagem_id'] ?? 0);
        View::json(
            (new BookingService())->hold(
                $id,
                empty($d['seats']) ? [] : Validator::ids($d['seats']),
                Security::holdOwner($id),
                true,
            ),
        );
    }
    public function manualSave(): never
    {
        $id = (int) ($_POST['viagem_id'] ?? 0);
        $u = Security::requireAdmin();
        $r = (new BookingService())->create($id, $_POST, Security::holdOwner($id), (int) $u['id']);
        $_SESSION['admin_private'][$r['id']] = $r['token'];
        flash('Reserva manual criada. Registre o recebimento para confirmar o pagamento.');
        redirect('admin/reserva', ['id' => $r['id']]);
    }
    public function cancel(): never
    {
        $r = $this->reservation();
        (new BookingService())->cancel((int) $r['id'], Validator::text($_POST, 'motivo', 500));
        flash(
            'Reserva cancelada. Valores recebidos permanecem no histórico; registre o estorno quando realizado.',
        );
        redirect('admin/reserva', ['id' => $r['id']]);
    }
    public function payment(): never
    {
        $r = $this->reservation();
        $u = Security::requireAdmin();
        (new PaymentService())->record((int) $r['id'], $_POST, (int) $u['id']);
        flash('Lançamento financeiro registrado e situação atualizada.');
        redirect('admin/reserva', ['id' => $r['id']]);
    }
    public function transfer(): never
    {
        $r = $this->reservation();
        (new BookingService())->transfer(
            (int) $r['id'],
            (int) ($_POST['passageiro_registro'] ?? 0),
            (int) ($_POST['poltrona_destino'] ?? 0),
        );
        flash('Passageiro transferido com segurança.');
        redirect('admin/reserva', ['id' => $r['id']]);
    }
    public function block(): never
    {
        $trip = (int) ($_POST['viagem_id'] ?? 0);
        (new BookingService())->block(
            $trip,
            (int) ($_POST['poltrona_id'] ?? 0),
            ($_POST['acao'] ?? '') === 'bloquear',
            Validator::text($_POST, 'motivo', 250, false),
        );
        flash('Situação da poltrona atualizada.');
        redirect('admin/mapa', ['viagem_id' => $trip]);
    }
    public function seat(): never
    {
        $s = DB::one('SELECT * FROM viagens_poltronas WHERE id=?', [(int) ($_GET['id'] ?? 0)]);
        if (!$s) {
            throw new HttpException(404, 'Poltrona não encontrada.');
        }
        $r = $s['reserva_id'] ? Reservations::find((int) $s['reserva_id']) : null;
        $p = $r
            ? DB::one(
                'SELECT p.nome FROM reservas_passageiros rp JOIN passageiros p ON p.id=rp.passageiro_id WHERE rp.reserva_id=? AND rp.viagem_poltrona_id=?',
                [$r['id'], $s['id']],
            )
            : null;
        $history = DB::all(
            "SELECT evento,created_at,detalhes FROM auditoria WHERE viagem_id=? AND (JSON_UNQUOTE(JSON_EXTRACT(detalhes,'$.poltrona'))=? OR JSON_UNQUOTE(JSON_EXTRACT(detalhes,'$.de'))=? OR JSON_UNQUOTE(JSON_EXTRACT(detalhes,'$.para'))=? OR reserva_id IN(SELECT reserva_id FROM reservas_passageiros WHERE viagem_poltrona_id=?)) ORDER BY id DESC LIMIT 15",
            [$s['viagem_id'], $s['numero'], $s['numero'], $s['numero'], $s['id']],
        );
        View::json([
            'seat' => [
                'id' => $s['id'],
                'numero' => $s['numero'],
                'estado' => $s['estado'],
                'motivo' => $s['bloqueio_motivo'],
            ],
            'reservation' => $r
                ? [
                    'id' => $r['id'],
                    'code' => $r['codigo'],
                    'status' => $r['status'],
                    'passenger' => $p['nome'] ?? '',
                    'received' => $r['recebido'],
                    'total' => $r['total'],
                    'url' => url('admin/reserva', ['id' => $r['id']]),
                ]
                : null,
            'history' => array_map(
                fn($h) => [
                    'event' => str_replace('_', ' ', $h['evento']),
                    'date' => datebr($h['created_at']),
                ],
                $history,
            ),
        ]);
    }
    public function editReservation(): never
    {
        $r = $this->reservation();
        $name = Validator::text($_POST, 'responsavel');
        $phone = Validator::phone((string) ($_POST['telefone'] ?? ''));
        $email = Validator::email(Validator::text($_POST, 'email', 190, false));
        $note = Validator::text($_POST, 'observacoes', 4000, false);
        DB::transaction(function () use ($r, $name, $phone, $email, $note) {
            (new BookingService())->lockTrip((int) $r['viagem_id']);
            DB::run(
                'UPDATE reservas SET responsavel=?,telefone=?,email=?,observacoes=? WHERE id=?',
                [$name, $phone, $email, $note, $r['id']],
            );
            Audit::log('contato_reserva_atualizado', [], (int) $r['viagem_id'], (int) $r['id']);
        });
        flash('Dados da reserva atualizados.');
        redirect('admin/reserva', ['id' => $r['id']]);
    }
    public function rotate(): never
    {
        $r = $this->reservation();
        $token = bin2hex(random_bytes(32));
        DB::transaction(function () use ($r, $token) {
            (new BookingService())->lockTrip((int) $r['viagem_id']);
            DB::run('UPDATE reservas SET token_hash=? WHERE id=?', [
                Security::secretHash($token),
                $r['id'],
            ]);
            Audit::log('chave_consulta_renovada', [], (int) $r['viagem_id'], (int) $r['id']);
        });
        $_SESSION['admin_private'][$r['id']] = $token;
        flash('Nova chave gerada. Compartilhe-a somente com o responsável.');
        redirect('admin/reserva', ['id' => $r['id']]);
    }
    public function ticket(): never
    {
        $r = $this->reservation();
        if ($r['status'] !== 'confirmada') {
            throw new HttpException(409, 'A reserva ainda não está confirmada.');
        }
        PdfService::ticket($r, Reservations::passengers((int) $r['id']));
    }
    public function passengers(): void
    {
        $w = ['1=1'];
        $params = [];
        if (!empty($_GET['q'])) {
            $q = '%' . mb_substr($_GET['q'], 0, 150) . '%';
            $w[] = '(p.nome LIKE ? OR p.telefone LIKE ? OR r.codigo LIKE ?)';
            array_push($params, $q, $q, $q);
        }
        if (!empty($_GET['viagem_id'])) {
            $w[] = 'v.id=?';
            $params[] = (int) $_GET['viagem_id'];
        }
        $rows = DB::all(
            'SELECT p.*,rp.id AS registro,rp.numero_snapshot,rp.embarcou_em,r.codigo,r.id AS reserva_id,r.status,v.destino,v.partida FROM passageiros p JOIN reservas_passageiros rp ON rp.passageiro_id=p.id JOIN reservas r ON r.id=rp.reserva_id JOIN viagens v ON v.id=r.viagem_id WHERE ' .
                implode(' AND ', $w) .
                ' ORDER BY v.partida DESC,p.nome LIMIT 200',
            $params,
        );
        $trips = Trips::listing([], true);
        $this->render(
            'passengers',
            compact('rows', 'trips') + ['title' => 'Passageiros e embarque'],
        );
    }
    public function passengerSave(): never
    {
        $id = (int) ($_POST['passageiro_id'] ?? 0);
        $name = Validator::text($_POST, 'nome');
        $note = Validator::text($_POST, 'observacoes', 4000, false);
        $phone = trim((string) ($_POST['telefone'] ?? ''));
        $phone = $phone !== '' ? Validator::phone($phone) : null;
        DB::transaction(function () use ($id, $name, $note, $phone) {
            if (!DB::one('SELECT id FROM passageiros WHERE id=? FOR UPDATE', [$id])) {
                throw new HttpException(404, 'Passageiro não encontrado.');
            }
            DB::run('UPDATE passageiros SET nome=?,telefone=?,observacoes=? WHERE id=?', [
                $name,
                $phone,
                $note,
                $id,
            ]);
            Audit::log('passageiro_atualizado', ['passageiro_id' => $id]);
        });
        flash('Passageiro atualizado.');
        redirect('admin/passageiros');
    }
    public function checkin(): never
    {
        $id = (int) ($_POST['registro'] ?? 0);
        $row = DB::one('SELECT * FROM reservas_passageiros WHERE id=?', [$id]);
        if (!$row) {
            throw new HttpException(404, 'Passageiro não encontrado.');
        }
        DB::transaction(function () use ($id, $row) {
            (new BookingService())->lockTrip((int) $row['viagem_id']);
            $r = DB::one('SELECT status FROM reservas WHERE id=? FOR UPDATE', [$row['reserva_id']]);
            if ($r['status'] !== 'confirmada') {
                throw new HttpException(409, 'Confirme a reserva antes de marcar o embarque.');
            }
            DB::run(
                'UPDATE reservas_passageiros SET embarcou_em=IF(embarcou_em IS NULL,UTC_TIMESTAMP(),NULL) WHERE id=?',
                [$id],
            );
            Audit::log(
                'embarque_alterado',
                ['registro' => $id],
                (int) $row['viagem_id'],
                (int) $row['reserva_id'],
            );
        });
        flash('Lista de embarque atualizada.');
        redirect('admin/passageiros', ['viagem_id' => $row['viagem_id']]);
    }
    public function finance(): void
    {
        [$start, $end] = ReportService::range($_GET);
        $payments = ReportService::make(array_merge($_GET, ['tipo' => 'movimentos']));
        $pending = Reservations::listing(['viagem_id' => $_GET['viagem_id'] ?? 0]);
        $trips = Trips::listing([], true);
        $totals = DB::one(
            "SELECT COALESCE(SUM(CASE WHEN r.status IN('pendente','parcial') THEN GREATEST(0,r.total-COALESCE((SELECT SUM(CASE WHEN p.tipo='recebimento' THEN p.valor ELSE -p.valor END) FROM pagamentos p WHERE p.reserva_id=r.id),0)) ELSE 0 END),0) AS a_receber,COALESCE(SUM(CASE WHEN r.status='cancelada' THEN COALESCE((SELECT SUM(CASE WHEN p.tipo='recebimento' THEN p.valor ELSE -p.valor END) FROM pagamentos p WHERE p.reserva_id=r.id),0) ELSE 0 END),0) AS a_revisar FROM reservas r WHERE (?=0 OR r.viagem_id=?)",
            [(int) ($_GET['viagem_id'] ?? 0), (int) ($_GET['viagem_id'] ?? 0)],
        );
        $this->render(
            'finance',
            compact('payments', 'pending', 'trips', 'totals') + ['title' => 'Financeiro'],
        );
    }
    public function reports(): void
    {
        $report = ReportService::make($_GET);
        $format = $_GET['formato'] ?? '';
        if ($format === 'csv') {
            Audit::log('relatorio_exportado', [
                'tipo' => $_GET['tipo'] ?? 'financeiro',
                'formato' => 'csv',
            ]);
            ReportService::csv($report);
        }
        if ($format === 'pdf') {
            $lines = [
                setting('nome_servico'),
                $report['title'],
                'Período: ' .
                ($_GET['inicio'] ?? date('Y-m-01')) .
                ' a ' .
                ($_GET['fim'] ?? date('Y-m-t')),
                '',
            ];
            foreach ($report['rows'] as $row) {
                foreach ($report['columns'] as $key => $label) {
                    $lines[] = $label . ': ' . ReportService::format($key, $row[$key]);
                }
                $lines[] = '---------------------------------------------------------------';
            }
            if (!$report['rows']) {
                $lines[] = 'Nenhum registro para os filtros selecionados.';
            }
            Audit::log('relatorio_exportado', [
                'tipo' => $_GET['tipo'] ?? 'financeiro',
                'formato' => 'pdf',
            ]);
            PdfService::output('relatorio-' . date('Ymd'), $report['title'], $lines);
        }
        $trips = Trips::listing([], true);
        $this->render('reports', compact('report', 'trips') + ['title' => 'Relatórios']);
    }
    public function settings(): void
    {
        $settings = Settings::all();
        $this->render('settings', compact('settings') + ['title' => 'Configurações']);
    }
    public function saveSettings(): never
    {
        $keys = [
            'nome_servico' => 120,
            'slogan' => 200,
            'telefone' => 30,
            'whatsapp' => 20,
            'proprietario' => 200,
            'email_contato' => 190,
            'pix_chave' => 190,
            'pix_beneficiario' => 150,
            'pix_instrucoes' => 3000,
            'regras_cancelamento' => 8000,
            'instrucoes_embarque' => 3000,
            'privacidade' => 8000,
            'metodos_pagamento' => 400,
        ];
        $values = [];
        foreach ($keys as $key => $max) {
            $values[$key] = Validator::text(
                $_POST,
                $key,
                $max,
                in_array(
                    $key,
                    ['nome_servico', 'regras_cancelamento', 'privacidade', 'metodos_pagamento'],
                    true,
                ),
            );
        }
        $methods = array_map('trim', explode(',', $values['metodos_pagamento']));
        if (
            count($methods) > 10 ||
            in_array('', $methods, true) ||
            count(array_unique($methods)) !== count($methods)
        ) {
            throw new HttpException(422, 'Informe até 10 métodos distintos, sem itens vazios.');
        }
        foreach ($methods as $method) {
            if (mb_strlen($method) > 60) {
                throw new HttpException(422, 'Cada método pode ter até 60 caracteres.');
            }
        }
        $values['metodos_pagamento'] = implode(',', $methods);
        if ($values['whatsapp'] !== '' && !preg_match('/^\d{10,15}$/D', $values['whatsapp'])) {
            throw new HttpException(422, 'WhatsApp: use apenas números, com país e DDD.');
        }
        if ($values['email_contato'] !== '') {
            Validator::email($values['email_contato']);
        }
        foreach (
            [
                'hold_minutos' => [1, 30],
                'pagamento_horas' => [1, 168],
                'max_poltronas_reserva' => [1, 40],
            ]
            as $k => $range
        ) {
            $v = (int) ($_POST[$k] ?? 0);
            if ($v < $range[0] || $v > $range[1]) {
                throw new HttpException(422, 'Prazo ou limite fora do intervalo permitido.');
            }
            $values[$k] = (string) $v;
        }
        if ($image = UploadService::image('logo')) {
            $values['logo'] = $image;
        }
        DB::transaction(function () use ($values) {
            Settings::save($values);
            Audit::log('configuracoes_atualizadas', ['campos' => array_keys($values)]);
        });
        flash('Configurações atualizadas.');
        redirect('admin/configuracoes');
    }
}
