<?php
namespace App\Controllers;
use App\Core\{Database as DB, HttpException, Security, View, Validator};
use App\Repositories\{Trips, Reservations};
use App\Services\{BookingService, PdfService};
final class PublicController
{
    public function home(): void
    {
        (new BookingService())->expireAll();
        $trips = array_slice(Trips::listing(), 0, 3);
        View::render('public/home', compact('trips') + ['title' => 'Viaje com tranquilidade']);
    }
    public function trips(): void
    {
        (new BookingService())->expireAll();
        $trips = Trips::listing($_GET);
        View::render('public/trips', compact('trips') + ['title' => 'Encontre sua próxima viagem']);
    }
    private function trip(): array
    {
        $t = Trips::find((int) ($_GET['id'] ?? ($_POST['viagem_id'] ?? 0)));
        if (!$t || !in_array($t['status'], ['aberta', 'encerrada'], true)) {
            throw new HttpException(404, 'Viagem não encontrada.');
        }
        return $t;
    }
    public function detail(): void
    {
        $trip = $this->trip();
        $map = (new BookingService())->map(
            (int) $trip['id'],
            Security::holdOwner((int) $trip['id']),
        );
        $free = count(array_filter($map['seats'], fn($s) => $s['estado'] === 'livre'));
        View::render('public/detail', compact('trip', 'free') + ['title' => $trip['nome']]);
    }
    public function seats(): void
    {
        $trip = $this->trip();
        $admin = false;
        $map = (new BookingService())->map(
            (int) $trip['id'],
            Security::holdOwner((int) $trip['id']),
        );
        View::render(
            'public/seats',
            compact('trip', 'map', 'admin') + ['title' => 'Escolha suas poltronas'],
        );
    }
    public function map(): never
    {
        $id = (int) ($_GET['viagem_id'] ?? 0);
        View::json((new BookingService())->map($id, Security::holdOwner($id)));
    }
    public function hold(): never
    {
        Security::rate('hold', 120, 600);
        $d = \App\Core\Request::json();
        $id = (int) ($d['viagem_id'] ?? 0);
        $ids = empty($d['seats']) ? [] : Validator::ids($d['seats']);
        View::json((new BookingService())->hold($id, $ids, Security::holdOwner($id)));
    }
    public function reserve(): never
    {
        Security::rate('reservar', 12, 3600);
        $id = (int) ($_POST['viagem_id'] ?? 0);
        $r = (new BookingService())->create($id, $_POST, Security::holdOwner($id));
        $_SESSION['reservas'][$r['code']] = Security::secretHash($r['token']);
        $_SESSION['private_keys'][$r['code']] = $r['token'];
        redirect('reserva', ['codigo' => $r['code']]);
    }
    public function lookup(): void
    {
        View::render('public/lookup', ['title' => 'Consulte sua reserva']);
    }
    public function access(): never
    {
        Security::rate('consulta', 20, 900);
        $code = trim((string) ($_POST['codigo'] ?? ''));
        $token = trim((string) ($_POST['token'] ?? ''));
        $r = DB::one('SELECT id,token_hash FROM reservas WHERE codigo=?', [$code]);
        if (
            !$r ||
            strlen($token) !== 64 ||
            !hash_equals($r['token_hash'], Security::secretHash($token))
        ) {
            throw new HttpException(
                403,
                'Código ou chave de acesso inválidos. Confira os dados recebidos na confirmação.',
            );
        }
        $_SESSION['reservas'][$code] = $r['token_hash'];
        redirect('reserva', ['codigo' => $code]);
    }
    public function reservation(): void
    {
        $code = (string) ($_GET['codigo'] ?? '');
        $auth = Security::authorizeReservation($code);
        DB::transaction(function () use ($auth) {
            $b = new BookingService();
            $b->lockTrip((int) $auth['viagem_id']);
            $b->expireLocked((int) $auth['viagem_id']);
        });
        $r = Reservations::find((int) $auth['id']);
        $passengers = Reservations::passengers((int) $r['id']);
        $private = $_SESSION['private_keys'][$code] ?? null;
        View::render(
            'public/reservation',
            compact('r', 'passengers', 'private') + ['title' => 'Sua reserva'],
        );
    }
    public function ticket(): never
    {
        $auth = Security::authorizeReservation((string) ($_GET['codigo'] ?? ''));
        $r = Reservations::find((int) $auth['id']);
        if ($r['status'] !== 'confirmada') {
            throw new HttpException(
                403,
                'O comprovante estará disponível após a confirmação integral do pagamento.',
            );
        }
        PdfService::ticket($r, Reservations::passengers((int) $r['id']));
    }
    public function privacy(): void
    {
        View::render('public/privacy', ['title' => 'Privacidade e regras']);
    }
}
