<?php
declare(strict_types=1);
const BASE_PATH = __DIR__ . '/..';
spl_autoload_register(static function (string $class): void {
    if (str_starts_with($class, 'App\\')) {
        $file = BASE_PATH . '/app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (is_file($file)) {
            require $file;
        }
    }
});
require __DIR__ . '/Core/helpers.php';
$configFile = BASE_PATH . '/config/config.php';
$GLOBALS['config'] = is_file($configFile)
    ? require $configFile
    : require BASE_PATH . '/config/config.example.php';
date_default_timezone_set(config('timezone', 'America/Sao_Paulo'));
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', BASE_PATH . '/storage/logs/php.log');
set_exception_handler([App\Core\ErrorHandler::class, 'handle']);
if (PHP_SAPI !== 'cli') {
    App\Core\Security::start();
}
