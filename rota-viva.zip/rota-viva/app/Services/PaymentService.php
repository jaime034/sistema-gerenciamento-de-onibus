<?php
namespace App\Services;
use App\Core\{Database as DB, HttpException, Money, Validator};
final class PaymentService
{
    public static function balance(int $id): int
    {
        $r = DB::one(
            "SELECT COALESCE(SUM(CASE WHEN tipo='recebimento' THEN valor ELSE -valor END),0) AS recebido FROM pagamentos WHERE reserva_id=?",
            [$id],
        );
        return (int) round((float) $r['recebido'] * 100);
    }
    public function record(int $id, array $d, int $user): void
    {
        $ref = DB::one('SELECT viagem_id FROM reservas WHERE id=?', [$id]);
        if (!$ref) {
            throw new HttpException(404, 'Reserva não encontrada.');
        }
        $cents = Money::cents($d['valor'] ?? '');
        if ($cents <= 0) {
            throw new HttpException(422, 'Informe um valor maior que zero.');
        }
        $method = Validator::text($d, 'metodo', 60);
        $methods = array_map('trim', explode(',', setting('metodos_pagamento')));
        if (!in_array($method, $methods, true)) {
            throw new HttpException(422, 'Forma de pagamento inválida.');
        }
        $type = ($d['tipo'] ?? 'recebimento') === 'estorno' ? 'estorno' : 'recebimento';
        $note = Validator::text($d, 'observacoes', 500, false);
        if ($type === 'estorno' && $note === '') {
            throw new HttpException(422, 'Informe a justificativa do estorno.');
        }
        $key = (string) ($d['idempotencia'] ?? '');
        if (!preg_match('/^[a-f0-9]{64}$/D', $key)) {
            throw new HttpException(422, 'Atualize a página antes de registrar o pagamento.');
        }
        $date = utcinput(Validator::text($d, 'pago_em', 32));
        if ($date > gmdate('Y-m-d H:i:s', time() + 60)) {
            throw new HttpException(422, 'A data do pagamento não pode estar no futuro.');
        }
        DB::transaction(function () use (
            $id,
            $d,
            $user,
            $ref,
            $cents,
            $method,
            $type,
            $note,
            $key,
            $date,
        ) {
            $b = new BookingService();
            $b->lockTrip((int) $ref['viagem_id']);
            $b->expireLocked((int) $ref['viagem_id']);
            $r = DB::one('SELECT * FROM reservas WHERE id=? FOR UPDATE', [$id]);
            $existing = DB::one('SELECT * FROM pagamentos WHERE idempotencia=?', [$key]);
            if ($existing) {
                if (
                    (int) $existing['reserva_id'] !== $id ||
                    $existing['tipo'] !== $type ||
                    Money::cents($existing['valor']) !== $cents ||
                    $existing['metodo'] !== $method
                ) {
                    throw new HttpException(
                        409,
                        'Este formulário já registrou outro lançamento. Atualize a página antes de registrar uma nova operação.',
                    );
                }
                return;
            }
            $balance = self::balance($id);
            $total = Money::cents($r['total']);
            if (
                $type === 'recebimento' &&
                !in_array($r['status'], ['pendente', 'parcial', 'confirmada'], true)
            ) {
                throw new HttpException(
                    409,
                    'A reserva foi cancelada ou expirou. Faça uma nova reserva antes de registrar um recebimento.',
                );
            }
            if (
                ($type === 'estorno' && $cents > $balance) ||
                ($type === 'recebimento' && $balance + $cents > $total)
            ) {
                throw new HttpException(
                    422,
                    'O valor supera o saldo permitido para esta operação.',
                );
            }
            DB::run(
                'INSERT INTO pagamentos(reserva_id,tipo,valor,metodo,pago_em,observacoes,registrado_por,idempotencia) VALUES(?,?,?,?,?,?,?,?)',
                [$id, $type, Money::decimal($cents), $method, $date, $note, $user, $key],
            );
            $new = $balance + ($type === 'recebimento' ? $cents : -$cents);
            if (!in_array($r['status'], ['cancelada', 'expirada'], true)) {
                // Um recebimento parcial conserva as poltronas para análise; um estorno não recria prazo vencido.
                $status = $new >= $total ? 'confirmada' : ($new > 0 ? 'parcial' : 'pendente');
                $deadline = $r['prazo_pagamento'];
                if ($status === 'pendente') {
                    $deadline = gmdate(
                        'Y-m-d H:i:s',
                        time() + (int) setting('pagamento_horas') * 3600,
                    );
                }
                DB::run('UPDATE reservas SET status=?,prazo_pagamento=? WHERE id=?', [
                    $status,
                    $deadline,
                    $id,
                ]);
                DB::run('UPDATE viagens_poltronas SET estado=? WHERE reserva_id=?', [
                    $status === 'confirmada' ? 'confirmada' : 'pendente',
                    $id,
                ]);
            }
            Audit::log(
                'pagamento_' . $type,
                [
                    'valor' => Money::decimal($cents),
                    'metodo' => $method,
                    'saldo_recebido' => Money::decimal($new),
                    'justificativa' => $note,
                ],
                (int) $r['viagem_id'],
                $id,
                $user,
            );
        });
    }
}
