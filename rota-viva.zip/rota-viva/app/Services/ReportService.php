<?php
namespace App\Services;
use App\Core\{Database as DB, HttpException};
final class ReportService
{
    public static function range(array $f): array
    {
        $start = $f['inicio'] ?? date('Y-m-01');
        $end = $f['fim'] ?? date('Y-m-t');
        if (
            !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $start) ||
            !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $end) ||
            $start > $end
        ) {
            throw new HttpException(422, 'Informe um período válido.');
        }
        return [utcinput($start . ' 00:00:00'), utcinput($end . ' 23:59:59')];
    }
    public static function make(array $f): array
    {
        $type = $f['tipo'] ?? 'financeiro';
        $trip = (int) ($f['viagem_id'] ?? 0);
        [$start, $end] = self::range($f);
        if (in_array($type, ['passageiros', 'vendidas'], true)) {
            $w =
                $type === 'vendidas'
                    ? "r.status='confirmada'"
                    : "r.status IN('pendente','parcial','confirmada')";
            $params = [];
            if ($trip) {
                $w .= ' AND r.viagem_id=?';
                $params[] = $trip;
            } else {
                $w .= ' AND v.partida BETWEEN ? AND ?';
                array_push($params, $start, $end);
            }
            $rows = DB::all(
                "SELECT v.destino,v.partida,p.nome,rp.numero_snapshot AS poltrona,r.codigo,r.status,rp.embarcou_em FROM reservas_passageiros rp JOIN reservas r ON r.id=rp.reserva_id JOIN passageiros p ON p.id=rp.passageiro_id JOIN viagens v ON v.id=r.viagem_id WHERE $w ORDER BY v.partida,rp.numero_snapshot",
                $params,
            );
            return [
                'title' => $type === 'vendidas' ? 'Passagens confirmadas' : 'Lista de passageiros',
                'columns' => [
                    'destino' => 'Destino',
                    'partida' => 'Partida',
                    'nome' => 'Passageiro',
                    'poltrona' => 'Poltrona',
                    'codigo' => 'Reserva',
                    'status' => 'Situação',
                    'embarcou_em' => 'Embarcou em',
                ],
                'rows' => $rows,
            ];
        }
        if (in_array($type, ['pendentes', 'cancelamentos'], true)) {
            $w =
                $type === 'pendentes'
                    ? "r.status IN('pendente','parcial')"
                    : "r.status IN('cancelada','expirada')";
            $params = [];
            if ($trip) {
                $w .= ' AND r.viagem_id=?';
                $params[] = $trip;
            }
            $w .= ' AND r.created_at BETWEEN ? AND ?';
            array_push($params, $start, $end);
            $rows = DB::all(
                "SELECT r.codigo,r.responsavel,v.destino,r.status,r.total,r.prazo_pagamento,r.created_at FROM reservas r JOIN viagens v ON v.id=r.viagem_id WHERE $w ORDER BY r.created_at DESC",
                $params,
            );
            return [
                'title' =>
                    $type === 'pendentes'
                        ? 'Reservas pendentes'
                        : 'Histórico de cancelamentos e expirações',
                'columns' => [
                    'codigo' => 'Reserva',
                    'responsavel' => 'Responsável',
                    'destino' => 'Destino',
                    'status' => 'Situação',
                    'total' => 'Total',
                    'prazo_pagamento' => 'Prazo',
                    'created_at' => 'Criada em',
                ],
                'rows' => $rows,
            ];
        }
        if ($type === 'ocupacao') {
            $w = '1=1';
            $params = [];
            if ($trip) {
                $w = 'v.id=?';
                $params[] = $trip;
            } else {
                $w = 'v.partida BETWEEN ? AND ?';
                array_push($params, $start, $end);
            }
            $rows = DB::all(
                "SELECT v.destino,s.fileira,s.numero AS poltrona,s.estado FROM viagens_poltronas s JOIN viagens v ON v.id=s.viagem_id WHERE $w ORDER BY v.partida,s.fileira,s.coluna",
                $params,
            );
            return [
                'title' => 'Mapa de ocupação',
                'columns' => [
                    'destino' => 'Destino',
                    'fileira' => 'Fileira',
                    'poltrona' => 'Poltrona',
                    'estado' => 'Estado',
                ],
                'rows' => $rows,
            ];
        }
        // Financeiro por competência: datas dos lançamentos, inclusive estornos de reservas canceladas.
        if ($type === 'movimentos') {
            $params = [$start, $end];
            $w = 'p.pago_em BETWEEN ? AND ?';
            if ($trip) {
                $w .= ' AND r.viagem_id=?';
                $params[] = $trip;
            }
            $rows = DB::all(
                "SELECT p.pago_em,r.codigo,v.destino,p.tipo,p.metodo,p.valor,p.observacoes FROM pagamentos p JOIN reservas r ON r.id=p.reserva_id JOIN viagens v ON v.id=r.viagem_id WHERE $w ORDER BY p.pago_em DESC",
                $params,
            );
            return [
                'title' => 'Recebimentos e estornos no período',
                'columns' => [
                    'pago_em' => 'Data',
                    'codigo' => 'Reserva',
                    'destino' => 'Destino',
                    'tipo' => 'Tipo',
                    'metodo' => 'Método',
                    'valor' => 'Valor',
                    'observacoes' => 'Observações',
                ],
                'rows' => $rows,
            ];
        }
        $params = [];
        $w = '1=1';
        if ($trip) {
            $w = 'v.id=?';
            $params[] = $trip;
        } else {
            $w = 'v.partida BETWEEN ? AND ?';
            array_push($params, $start, $end);
        }
        $rows = DB::all(
            "SELECT v.nome,v.destino,v.partida,COALESCE((SELECT SUM(r.total) FROM reservas r WHERE r.viagem_id=v.id AND r.status IN('pendente','parcial','confirmada')),0) AS devido,COALESCE((SELECT SUM(CASE WHEN p.tipo='recebimento' THEN p.valor ELSE -p.valor END) FROM pagamentos p JOIN reservas r ON r.id=p.reserva_id WHERE r.viagem_id=v.id),0) AS recebido,COALESCE((SELECT SUM(GREATEST(0,r.total-COALESCE((SELECT SUM(CASE WHEN p.tipo='recebimento' THEN p.valor ELSE -p.valor END) FROM pagamentos p WHERE p.reserva_id=r.id),0))) FROM reservas r WHERE r.viagem_id=v.id AND r.status IN('pendente','parcial','confirmada')),0) AS a_receber,COALESCE((SELECT SUM(COALESCE((SELECT SUM(CASE WHEN p.tipo='recebimento' THEN p.valor ELSE -p.valor END) FROM pagamentos p WHERE p.reserva_id=r.id),0)) FROM reservas r WHERE r.viagem_id=v.id AND r.status='cancelada'),0) AS canceladas_a_revisar FROM viagens v WHERE $w ORDER BY v.partida",
            $params,
        );
        return [
            'title' => 'Financeiro por viagem (data da partida)',
            'columns' => [
                'nome' => 'Viagem',
                'destino' => 'Destino',
                'partida' => 'Partida',
                'devido' => 'Valor ativo',
                'recebido' => 'Recebido líquido',
                'a_receber' => 'A receber',
                'canceladas_a_revisar' => 'Saldo em canceladas',
            ],
            'rows' => $rows,
        ];
    }
    public static function format(string $key, mixed $v): string
    {
        if ($v === null) {
            return '—';
        }
        if (
            in_array(
                $key,
                ['partida', 'pago_em', 'created_at', 'prazo_pagamento', 'embarcou_em'],
                true,
            )
        ) {
            return datebr((string) $v);
        }
        if (
            in_array(
                $key,
                ['total', 'valor', 'devido', 'recebido', 'a_receber', 'canceladas_a_revisar'],
                true,
            )
        ) {
            return money($v);
        }
        if (in_array($key, ['estado', 'status', 'tipo'], true)) {
            return statuslabel((string) $v);
        }
        return (string) $v;
    }
    public static function csv(array $report): never
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="relatorio-' . date('Ymd') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, array_values($report['columns']), ';', '"', '');
        foreach ($report['rows'] as $r) {
            $row = [];
            foreach ($report['columns'] as $k => $v) {
                $s = self::format($k, $r[$k]);
                if (preg_match('/^[\s]*[=+@\-\t\r]/u', $s)) {
                    $s = "'" . $s;
                }
                $row[] = $s;
            }
            fputcsv($out, $row, ';', '"', '');
        }
        fclose($out);
        exit();
    }
}
