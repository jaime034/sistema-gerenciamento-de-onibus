<?php
namespace App\Services;
use App\Core\Database as DB;
final class Audit
{
    public static function log(
        string $event,
        array $details = [],
        ?int $trip = null,
        ?int $reservation = null,
        ?int $user = null,
    ): void {
        DB::run(
            'INSERT INTO auditoria(usuario_id,viagem_id,reserva_id,evento,detalhes) VALUES(?,?,?,?,?)',
            [
                $user ?? ($_SESSION['admin']['id'] ?? null),
                $trip,
                $reservation,
                $event,
                json_encode($details, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
            ],
        );
    }
}
