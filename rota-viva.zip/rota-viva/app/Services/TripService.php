<?php
namespace App\Services;
use App\Core\{Database as DB, HttpException, Validator, Money};
final class TripService
{
    public function save(array $d): int
    {
        $id = (int) ($d['id'] ?? 0);
        $name = Validator::text($d, 'nome', 160);
        $origin = Validator::text($d, 'origem');
        $destination = Validator::text($d, 'destino');
        $boarding = Validator::text($d, 'embarque', 4000);
        $description = Validator::text($d, 'descricao', 12000, false);
        $instructions = Validator::text($d, 'orientacoes', 8000, false);
        $departure = utcinput(Validator::text($d, 'partida', 32));
        $return = trim((string) ($d['retorno'] ?? '')) !== '' ? utcinput($d['retorno']) : null;
        if ($return && $return < $departure) {
            throw new HttpException(422, 'O retorno deve ser posterior à partida.');
        }
        $price = Money::decimal(Money::cents($d['preco'] ?? ''));
        $layout = (int) ($d['layout_id'] ?? 0);
        $status = (string) ($d['status'] ?? 'rascunho');
        if (
            !in_array(
                $status,
                ['rascunho', 'aberta', 'encerrada', 'em_andamento', 'concluida', 'cancelada'],
                true,
            )
        ) {
            throw new HttpException(422, 'Situação inválida.');
        }
        return DB::transaction(function () use (
            $d,
            $id,
            $name,
            $origin,
            $destination,
            $boarding,
            $description,
            $instructions,
            $departure,
            $return,
            $price,
            $layout,
            $status,
        ) {
            if (
                !DB::one(
                    'SELECT l.id FROM layouts_onibus l JOIN onibus o ON o.id=l.onibus_id WHERE l.id=? AND o.ativo=1',
                    [$layout],
                )
            ) {
                throw new HttpException(422, 'Selecione uma configuração de ônibus válida.');
            }
            $b = new BookingService();
            $t = $id ? $b->lockTrip($id) : null;
            $has = $id && DB::one('SELECT id FROM reservas WHERE viagem_id=? LIMIT 1', [$id]);
            if (
                $has &&
                ($t['layout_id'] != $layout ||
                    $t['origem'] !== $origin ||
                    $t['destino'] !== $destination ||
                    $t['partida'] !== $departure ||
                    $t['retorno'] !== $return ||
                    $t['embarque'] !== $boarding ||
                    $t['nome'] !== $name)
            ) {
                throw new HttpException(
                    409,
                    'Esta viagem já possui histórico de reservas. Preserve nome, trajeto, horários, embarque e layout; duplique a viagem para alterá-los.',
                );
            }
            if ($t && $t['status'] === 'cancelada' && $status !== 'cancelada') {
                throw new HttpException(
                    409,
                    'Uma viagem cancelada não pode ser reaberta. Duplique-a.',
                );
            }
            if ($status === 'aberta' && $departure <= gmdate('Y-m-d H:i:s')) {
                throw new HttpException(
                    422,
                    'Para abrir reservas, a partida deve estar no futuro.',
                );
            }
            $capa = $d['capa_salva'] ?? ($t['capa'] ?? null);
            if ($id) {
                DB::run(
                    'UPDATE viagens SET layout_id=?,nome=?,origem=?,destino=?,partida=?,retorno=?,embarque=?,preco=?,descricao=?,orientacoes=?,status=?,capa=? WHERE id=?',
                    [
                        $layout,
                        $name,
                        $origin,
                        $destination,
                        $departure,
                        $return,
                        $boarding,
                        $price,
                        $description,
                        $instructions,
                        $status,
                        $capa,
                        $id,
                    ],
                );
            } else {
                DB::run(
                    'INSERT INTO viagens(layout_id,nome,origem,destino,partida,retorno,embarque,preco,descricao,orientacoes,status,capa) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                    [
                        $layout,
                        $name,
                        $origin,
                        $destination,
                        $departure,
                        $return,
                        $boarding,
                        $price,
                        $description,
                        $instructions,
                        $status,
                        $capa,
                    ],
                );
                $id = (int) DB::connection()->lastInsertId();
            }
            if (!$t || $t['layout_id'] != $layout) {
                DB::run('DELETE FROM viagens_poltronas WHERE viagem_id=?', [$id]);
                $this->inventory($id, $layout);
            }
            if ($status === 'cancelada' && (!$t || $t['status'] !== 'cancelada')) {
                foreach (
                    DB::all(
                        "SELECT id FROM reservas WHERE viagem_id=? AND status IN('pendente','parcial','confirmada')",
                        [$id],
                    )
                    as $r
                ) {
                    $b->cancelLocked((int) $r['id'], 'Viagem cancelada pelo administrador.');
                }
                DB::run(
                    "UPDATE viagens_poltronas SET estado='livre',hold_hash=NULL,expira_em=NULL WHERE viagem_id=? AND estado='hold'",
                    [$id],
                );
            }
            Audit::log(
                $t ? 'viagem_atualizada' : 'viagem_criada',
                ['status' => $status, 'preco' => $price],
                $id,
            );
            return $id;
        });
    }
    public function inventory(int $id, int $layout): void
    {
        DB::run(
            "INSERT INTO viagens_poltronas(viagem_id,poltrona_id,numero,fileira,coluna,janela,estado,bloqueio_motivo) SELECT ?,id,numero,fileira,coluna,janela,IF(ativa=1,'livre','bloqueada'),IF(ativa=1,NULL,'Poltrona desativada no layout') FROM poltronas WHERE layout_id=?",
            [$id, $layout],
        );
    }
    public function duplicate(int $id): int
    {
        return DB::transaction(function () use ($id) {
            $t = (new BookingService())->lockTrip($id);
            $partida = gmdate(
                'Y-m-d H:i:s',
                max(time() + 7 * 86400, strtotime($t['partida'] . ' UTC') + 7 * 86400),
            );
            $retorno = $t['retorno']
                ? gmdate(
                    'Y-m-d H:i:s',
                    strtotime($partida . ' UTC') +
                        strtotime($t['retorno'] . ' UTC') -
                        strtotime($t['partida'] . ' UTC'),
                )
                : null;
            DB::run(
                "INSERT INTO viagens(layout_id,nome,origem,destino,partida,retorno,embarque,preco,descricao,orientacoes,capa,status,demonstrativo) SELECT layout_id,CONCAT(LEFT(nome,150),' — cópia'),origem,destino,?,?,embarque,preco,descricao,orientacoes,capa,'rascunho',demonstrativo FROM viagens WHERE id=?",
                [$partida, $retorno, $id],
            );
            $new = (int) DB::connection()->lastInsertId();
            $this->inventory($new, (int) $t['layout_id']);
            Audit::log('viagem_duplicada', ['origem' => $id], $new);
            return $new;
        });
    }
}
