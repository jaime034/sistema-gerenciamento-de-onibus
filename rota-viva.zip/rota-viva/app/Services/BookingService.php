<?php
namespace App\Services;
use App\Core\{Database as DB, HttpException, Money, Security, Validator};
final class BookingService
{
    // Toda mutação segue a mesma ordem: viagem → reservas → inventário → financeiro.
    // A trava da viagem simplifica a atomicidade de grupos e serializa disputas do mesmo ônibus/viagem.
    public function lockTrip(int $id): array
    {
        $t = DB::one('SELECT * FROM viagens WHERE id=? FOR UPDATE', [$id]);
        if (!$t) {
            throw new HttpException(404, 'Viagem não encontrada.');
        }
        return $t;
    }
    public function expireLocked(int $trip): void
    {
        DB::run(
            "UPDATE viagens_poltronas SET estado='livre',hold_hash=NULL,expira_em=NULL WHERE viagem_id=? AND estado='hold' AND expira_em<=UTC_TIMESTAMP()",
            [$trip],
        );
        $rows = DB::all(
            "SELECT r.id FROM reservas r WHERE r.viagem_id=? AND r.status='pendente' AND r.prazo_pagamento<=UTC_TIMESTAMP() AND NOT EXISTS(SELECT 1 FROM pagamentos p WHERE p.reserva_id=r.id) FOR UPDATE",
            [$trip],
        );
        foreach ($rows as $r) {
            DB::run("UPDATE reservas SET status='expirada' WHERE id=?", [$r['id']]);
            $this->release((int) $r['id']);
            Audit::log('reserva_expirada', [], $trip, (int) $r['id']);
        }
    }
    private function release(int $reservation): void
    {
        DB::run(
            "UPDATE viagens_poltronas SET estado='livre',reserva_id=NULL,hold_hash=NULL,expira_em=NULL WHERE reserva_id=?",
            [$reservation],
        );
    }
    public function expireAll(): int
    {
        $ids = DB::all(
            "SELECT DISTINCT viagem_id FROM viagens_poltronas WHERE (estado='hold' AND expira_em<=UTC_TIMESTAMP()) UNION SELECT viagem_id FROM reservas WHERE status='pendente' AND prazo_pagamento<=UTC_TIMESTAMP()",
        );
        foreach ($ids as $r) {
            DB::transaction(function () use ($r) {
                $this->lockTrip((int) $r['viagem_id']);
                $this->expireLocked((int) $r['viagem_id']);
            });
        }
        return count($ids);
    }
    private function open(array $trip): void
    {
        if ($trip['status'] !== 'aberta' || $trip['partida'] <= gmdate('Y-m-d H:i:s')) {
            throw new HttpException(409, 'Esta viagem não está recebendo novas reservas.');
        }
    }
    public function map(int $trip, string $owner, bool $admin = false): array
    {
        return DB::transaction(function () use ($trip, $owner, $admin) {
            $t = $this->lockTrip($trip);
            if (!$admin && !in_array($t['status'], ['aberta', 'encerrada'], true)) {
                throw new HttpException(404, 'Viagem indisponível.');
            }
            $this->expireLocked($trip);
            $h = Security::secretHash($owner);
            $seats = DB::all(
                'SELECT id,numero,fileira,coluna,janela,estado,hold_hash,expira_em,reserva_id FROM viagens_poltronas WHERE viagem_id=? ORDER BY fileira,coluna',
                [$trip],
            );
            foreach ($seats as &$s) {
                $s['mine'] = $s['estado'] === 'hold' && hash_equals($h, (string) $s['hold_hash']);
                $s['expira_em'] = $s['mine'] ? $s['expira_em'] : null;
                unset($s['hold_hash']);
                if (!$admin) {
                    unset($s['reserva_id']);
                }
            }
            unset($s);
            $layout = DB::one('SELECT fileiras FROM layouts_onibus WHERE id=?', [$t['layout_id']]);
            return [
                'seats' => $seats,
                'rows' => (int) $layout['fileiras'],
                'price' => $t['preco'],
                'status' => $t['status'],
                'can_book' => $t['status'] === 'aberta' && $t['partida'] > gmdate('Y-m-d H:i:s'),
                'server_time' => gmdate('c'),
            ];
        });
    }
    public function hold(int $trip, array $ids, string $owner, bool $admin = false): array
    {
        return DB::transaction(function () use ($trip, $ids, $owner, $admin) {
            $t = $this->lockTrip($trip);
            $this->open($t);
            $this->expireLocked($trip);
            $hash = Security::secretHash($owner);
            $max = $admin ? 160 : (int) setting('max_poltronas_reserva', '8');
            if (count($ids) > $max) {
                throw new HttpException(
                    422,
                    'Selecione no máximo ' . $max . ' lugares por reserva.',
                );
            }
            if (!$ids) {
                DB::run(
                    "UPDATE viagens_poltronas SET estado='livre',hold_hash=NULL,expira_em=NULL WHERE viagem_id=? AND estado='hold' AND hold_hash=?",
                    [$trip, $hash],
                );
                return ['expires_at' => null];
            }
            $ids = Validator::ids($ids);
            $q = implode(',', array_fill(0, count($ids), '?'));
            $rows = DB::all(
                "SELECT * FROM viagens_poltronas WHERE viagem_id=? AND id IN($q) ORDER BY id FOR UPDATE",
                [$trip, ...$ids],
            );
            if (count($rows) !== count($ids)) {
                throw new HttpException(422, 'Alguma poltrona não pertence a esta viagem.');
            }
            foreach ($rows as $s) {
                if (
                    $s['estado'] !== 'livre' &&
                    !($s['estado'] === 'hold' && hash_equals($hash, (string) $s['hold_hash']))
                ) {
                    throw new HttpException(
                        409,
                        'A poltrona ' .
                            $s['numero'] .
                            ' acabou de ficar indisponível. Escolha outro lugar.',
                    );
                }
            }
            $own = DB::one(
                "SELECT MIN(expira_em) AS fim FROM viagens_poltronas WHERE viagem_id=? AND estado='hold' AND hold_hash=?",
                [$trip, $hash],
            );
            $expiry = min(
                $t['partida'],
                $own['fim'] ??
                    gmdate('Y-m-d H:i:s', time() + (int) setting('hold_minutos', '10') * 60),
            );
            DB::run(
                "UPDATE viagens_poltronas SET estado='livre',hold_hash=NULL,expira_em=NULL WHERE viagem_id=? AND estado='hold' AND hold_hash=? AND id NOT IN($q)",
                [$trip, $hash, ...$ids],
            );
            DB::run(
                "UPDATE viagens_poltronas SET estado='hold',hold_hash=?,expira_em=? WHERE viagem_id=? AND id IN($q)",
                [$hash, $expiry, $trip, ...$ids],
            );
            return ['expires_at' => $expiry, 'seat_ids' => $ids];
        });
    }
    public function create(int $trip, array $data, string $owner, ?int $admin = null): array
    {
        $ids = Validator::ids($data['seats'] ?? null);
        $name = Validator::text($data, 'responsavel');
        $phone = Validator::phone((string) ($data['telefone'] ?? ''));
        $email = Validator::email(trim((string) ($data['email'] ?? '')));
        if (!$admin && empty($data['aceite'])) {
            throw new HttpException(422, 'Leia e confirme as regras e o aviso de privacidade.');
        }
        $names = [];
        foreach ($ids as $id) {
            $n = trim((string) ($data['passageiros'][$id] ?? ''));
            if (mb_strlen($n) < 3 || mb_strlen($n) > 150) {
                throw new HttpException(422, 'Informe o nome completo de cada passageiro.');
            }
            $names[$id] = $n;
        }
        return DB::transaction(function () use (
            $trip,
            $data,
            $owner,
            $admin,
            $ids,
            $name,
            $phone,
            $email,
            $names,
        ) {
            $t = $this->lockTrip($trip);
            $this->open($t);
            $this->expireLocked($trip);
            if (count($ids) > ($admin ? 160 : (int) setting('max_poltronas_reserva', '8'))) {
                throw new HttpException(422, 'Quantidade de lugares acima do permitido.');
            }
            $q = implode(',', array_fill(0, count($ids), '?'));
            $seats = DB::all(
                "SELECT * FROM viagens_poltronas WHERE viagem_id=? AND id IN($q) ORDER BY id FOR UPDATE",
                [$trip, ...$ids],
            );
            $hash = Security::secretHash($owner);
            if (count($seats) !== count($ids)) {
                throw new HttpException(422, 'Poltrona inválida.');
            }
            foreach ($seats as $s) {
                if ($s['estado'] !== 'hold' || !hash_equals($hash, (string) $s['hold_hash'])) {
                    throw new HttpException(
                        409,
                        'O prazo de seleção terminou ou um lugar ficou indisponível. Selecione os lugares novamente.',
                    );
                }
            }
            $subtotal = Money::cents($t['preco']) * count($seats);
            if ($subtotal > 9999999999) {
                throw new HttpException(
                    422,
                    'O valor do grupo ultrapassa o limite monetário de uma reserva.',
                );
            }
            $discount = $admin ? Money::cents($data['desconto'] ?? '0') : 0;
            $reason = $admin ? Validator::text($data, 'desconto_motivo', 250, false) : '';
            if ($discount > $subtotal || ($discount > 0 && $reason === '')) {
                throw new HttpException(
                    422,
                    'O desconto precisa de justificativa e não pode superar o total.',
                );
            }
            $total = $subtotal - $discount;
            $token = bin2hex(random_bytes(32));
            $code = 'RV-' . strtoupper(bin2hex(random_bytes(10)));
            $deadline = min(
                $t['partida'],
                gmdate('Y-m-d H:i:s', time() + (int) setting('pagamento_horas', '24') * 3600),
            );
            $status = $total === 0 ? 'confirmada' : 'pendente';
            DB::run(
                'INSERT INTO reservas(viagem_id,codigo,token_hash,responsavel,telefone,email,status,subtotal,desconto,total,desconto_motivo,observacoes,origem,prazo_pagamento,regras_snapshot,privacidade_snapshot,consent_at,created_by,demonstrativo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP(),?,?)',
                [
                    $trip,
                    $code,
                    Security::secretHash($token),
                    $name,
                    $phone,
                    $email,
                    $status,
                    Money::decimal($subtotal),
                    Money::decimal($discount),
                    Money::decimal($total),
                    $reason,
                    $admin ? Validator::text($data, 'observacoes', 4000, false) : '',
                    $admin ? 'manual' : 'publica',
                    $deadline,
                    setting('regras_cancelamento'),
                    setting('privacidade'),
                    $admin,
                    $t['demonstrativo'],
                ],
            );
            $rid = (int) DB::connection()->lastInsertId();
            foreach ($seats as $s) {
                DB::run('INSERT INTO passageiros(nome,telefone,demonstrativo) VALUES(?,?,?)', [
                    $names[$s['id']],
                    $phone,
                    $t['demonstrativo'],
                ]);
                $pid = (int) DB::connection()->lastInsertId();
                DB::run(
                    'INSERT INTO reservas_passageiros(viagem_id,reserva_id,passageiro_id,viagem_poltrona_id,numero_snapshot,preco_unitario) VALUES(?,?,?,?,?,?)',
                    [$trip, $rid, $pid, $s['id'], $s['numero'], $t['preco']],
                );
            }
            DB::run(
                "UPDATE viagens_poltronas SET estado=?,reserva_id=?,hold_hash=NULL,expira_em=NULL WHERE viagem_id=? AND id IN($q)",
                [$status === 'confirmada' ? 'confirmada' : 'pendente', $rid, $trip, ...$ids],
            );
            Audit::log(
                'reserva_criada',
                [
                    'poltronas' => array_column($seats, 'numero'),
                    'total' => Money::decimal($total),
                    'origem' => $admin ? 'manual' : 'publica',
                ],
                $trip,
                $rid,
                $admin,
            );
            return ['id' => $rid, 'code' => $code, 'token' => $token];
        });
    }
    public function cancel(int $reservation, string $reason): void
    {
        if (trim($reason) === '') {
            throw new HttpException(422, 'Informe o motivo do cancelamento.');
        }
        $ref = DB::one('SELECT viagem_id FROM reservas WHERE id=?', [$reservation]);
        if (!$ref) {
            throw new HttpException(404, 'Reserva não encontrada.');
        }
        DB::transaction(function () use ($reservation, $reason, $ref) {
            $this->lockTrip((int) $ref['viagem_id']);
            $this->cancelLocked($reservation, $reason);
        });
    }
    public function cancelLocked(int $reservation, string $reason): void
    {
        $r = DB::one('SELECT * FROM reservas WHERE id=? FOR UPDATE', [$reservation]);
        if (in_array($r['status'], ['cancelada', 'expirada'], true)) {
            return;
        }
        DB::run("UPDATE reservas SET status='cancelada' WHERE id=?", [$reservation]);
        $this->release($reservation);
        Audit::log(
            'reserva_cancelada',
            ['motivo' => mb_substr($reason, 0, 500)],
            (int) $r['viagem_id'],
            $reservation,
        );
    }
    public function block(int $trip, int $seat, bool $block, string $reason): void
    {
        DB::transaction(function () use ($trip, $seat, $block, $reason) {
            $this->lockTrip($trip);
            $this->expireLocked($trip);
            $s = DB::one('SELECT * FROM viagens_poltronas WHERE viagem_id=? AND id=? FOR UPDATE', [
                $trip,
                $seat,
            ]);
            if (!$s) {
                throw new HttpException(404, 'Poltrona não encontrada.');
            }
            if ($block && $s['estado'] !== 'livre') {
                throw new HttpException(409, 'Somente uma poltrona disponível pode ser bloqueada.');
            }
            if (!$block && $s['estado'] !== 'bloqueada') {
                throw new HttpException(409, 'Esta poltrona não está bloqueada.');
            }
            if ($block && trim($reason) === '') {
                throw new HttpException(422, 'Informe o motivo do bloqueio.');
            }
            DB::run('UPDATE viagens_poltronas SET estado=?,bloqueio_motivo=? WHERE id=?', [
                $block ? 'bloqueada' : 'livre',
                $block ? mb_substr($reason, 0, 250) : null,
                $seat,
            ]);
            Audit::log(
                $block ? 'poltrona_bloqueada' : 'poltrona_desbloqueada',
                ['poltrona' => $s['numero'], 'motivo' => $reason],
                $trip,
            );
        });
    }
    public function transfer(int $reservation, int $passengerRow, int $target): void
    {
        $ref = DB::one('SELECT viagem_id FROM reservas WHERE id=?', [$reservation]);
        if (!$ref) {
            throw new HttpException(404, 'Reserva não encontrada.');
        }
        DB::transaction(function () use ($reservation, $passengerRow, $target, $ref) {
            $trip = (int) $ref['viagem_id'];
            $this->lockTrip($trip);
            $this->expireLocked($trip);
            $r = DB::one('SELECT * FROM reservas WHERE id=? FOR UPDATE', [$reservation]);
            if (!in_array($r['status'], ['pendente', 'parcial', 'confirmada'], true)) {
                throw new HttpException(409, 'A reserva não está ativa.');
            }
            $p = DB::one('SELECT * FROM reservas_passageiros WHERE id=? AND reserva_id=?', [
                $passengerRow,
                $reservation,
            ]);
            $s = DB::one('SELECT * FROM viagens_poltronas WHERE id=? AND viagem_id=? FOR UPDATE', [
                $target,
                $trip,
            ]);
            if (!$p || !$s || $s['estado'] !== 'livre') {
                throw new HttpException(409, 'Escolha uma poltrona disponível da mesma viagem.');
            }
            if (
                DB::one(
                    'SELECT id FROM reservas_passageiros WHERE reserva_id=? AND viagem_poltrona_id=?',
                    [$reservation, $target],
                )
            ) {
                throw new HttpException(409, 'A poltrona já está vinculada a esta reserva.');
            }
            DB::run(
                "UPDATE viagens_poltronas SET estado='livre',reserva_id=NULL WHERE id=? AND reserva_id=?",
                [$p['viagem_poltrona_id'], $reservation],
            );
            DB::run('UPDATE viagens_poltronas SET estado=?,reserva_id=? WHERE id=?', [
                $r['status'] === 'confirmada' ? 'confirmada' : 'pendente',
                $reservation,
                $target,
            ]);
            DB::run(
                'UPDATE reservas_passageiros SET viagem_poltrona_id=?,numero_snapshot=? WHERE id=?',
                [$target, $s['numero'], $passengerRow],
            );
            Audit::log(
                'poltrona_transferida',
                [
                    'de' => $p['numero_snapshot'],
                    'para' => $s['numero'],
                    'passageiro_registro' => $passengerRow,
                ],
                $trip,
                $reservation,
            );
        });
    }
}
