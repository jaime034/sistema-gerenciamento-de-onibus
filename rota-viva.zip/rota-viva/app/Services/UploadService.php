<?php
namespace App\Services;
use App\Core\HttpException;
final class UploadService
{
    public static function image(string $field): ?string
    {
        if (empty($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        $f = $_FILES[$field];
        if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > 3 * 1024 * 1024) {
            throw new HttpException(422, 'Envie uma imagem JPG, PNG ou WebP de até 3 MB.');
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
        $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
        $dim = @getimagesize($f['tmp_name']);
        if (!$ext || !$dim || $dim[0] > 6000 || $dim[1] > 6000) {
            throw new HttpException(422, 'Imagem inválida ou maior que 6000 pixels.');
        }
        $name = bin2hex(random_bytes(20)) . '.' . $ext;
        if (!move_uploaded_file($f['tmp_name'], BASE_PATH . '/storage/uploads/' . $name)) {
            throw new HttpException(500, 'Não foi possível salvar a imagem.');
        }
        return $name;
    }
    public static function serve(string $name): never
    {
        if (!preg_match('/^[a-f0-9]{40}\.(jpg|png|webp)$/D', $name)) {
            throw new HttpException(404, 'Imagem não encontrada.');
        }
        $path = BASE_PATH . '/storage/uploads/' . $name;
        if (!is_file($path)) {
            throw new HttpException(404, 'Imagem não encontrada.');
        }
        header('Content-Type: ' . (new \finfo(FILEINFO_MIME_TYPE))->file($path));
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit();
    }
}
