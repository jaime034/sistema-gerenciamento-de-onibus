<?php
namespace App\Services;
// Gerador PDF 1.4, texto WinAnsi e paginação. Sem HTML remoto, scripts, fontes externas ou dependências.
final class PdfService
{
    public static function document(string $title, array $lines): string
    {
        $all = [];
        foreach ($lines as $line) {
            foreach (explode("\n", wordwrap((string) $line, 90, "\n", true)) as $row) {
                $all[] = $row;
            }
        }
        $pages = array_chunk($all ?: [''], 44);
        $objects = [
            1 => '<< /Type /Catalog /Pages 2 0 R >>',
            2 => '',
            3 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
        ];
        $kids = [];
        foreach ($pages as $i => $rows) {
            $page = 4 + $i * 2;
            $stream = $page + 1;
            $kids[] = "$page 0 R";
            $content =
                "0.04 0.16 0.20 rg\n40 780 515 42 re f\nBT /F1 17 Tf 1 1 1 rg 54 795 Td (" .
                self::escape($title) .
                ") Tj ET\n";
            $content .= "BT /F1 10 Tf 0.12 0.20 0.23 rg 40 752 Td 15 TL\n";
            foreach ($rows as $row) {
                $content .= '(' . self::escape($row) . ") Tj T*\n";
            }
            $content .=
                "ET\nBT /F1 9 Tf 0.4 0.4 0.4 rg 40 44 Td (" .
                self::escape(
                    'Gerado em ' .
                        date('d/m/Y H:i') .
                        ' | Página ' .
                        ($i + 1) .
                        ' de ' .
                        count($pages),
                ) .
                ') Tj ET';
            $objects[
                $page
            ] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents $stream 0 R >>";
            $objects[$stream] =
                '<< /Length ' . strlen($content) . ">>\nstream\n" . $content . "\nendstream";
        }
        $objects[2] =
            '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . count($pages) . ' >>';
        ksort($objects);
        $pdf = "%PDF-1.4\n";
        $offsets = [0];
        foreach ($objects as $id => $obj) {
            $offsets[$id] = strlen($pdf);
            $pdf .= "$id 0 obj\n$obj\nendobj\n";
        }
        $start = strlen($pdf);
        $pdf .= 'xref' . "\n0 " . (count($objects) + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $pdf .=
            'trailer << /Size ' .
            (count($objects) + 1) .
            " /Root 1 0 R >>\nstartxref\n$start\n%%EOF";
        return $pdf;
    }
    private static function escape(string $s): string
    {
        $s = mb_convert_encoding($s, 'Windows-1252', 'UTF-8');
        return str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\\(', '\\)', '', ' '], $s);
    }
    public static function output(string $name, string $title, array $lines): never
    {
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $name . '.pdf"');
        echo self::document($title, $lines);
        exit();
    }
    public static function ticket(array $r, array $passengers): never
    {
        $lines = [
            setting('nome_servico'),
            'RESERVA ' . $r['codigo'],
            'Situação: ' . statuslabel($r['status']),
            $r['cidade_origem'] . ' / ' . $r['destino'],
            'Partida: ' . datebr($r['partida']),
            'Embarque: ' . $r['embarque'],
            '',
        ];
        foreach ($passengers as $p) {
            $lines[] = 'PASSAGEIRO: ' . $p['nome'];
            $lines[] = 'Poltrona: ' . $p['numero_snapshot'];
            $lines[] = '';
        }
        $lines[] = 'Valor da reserva: ' . money($r['total']);
        $lines[] = setting('instrucoes_embarque');
        $lines[] = 'Contato: ' . setting('telefone');
        $lines[] =
            'Comprovante de reserva e embarque. Não é documento fiscal nem licença de viagem.';
        self::output('passagem-' . $r['codigo'], 'Comprovante de passagem', $lines);
    }
}
