<?php
namespace App\Services;
use App\Core\{Database as DB, HttpException, Validator};
final class FleetService
{
    public function save(array $d): int
    {
        $id = (int) ($d['id'] ?? 0);
        $name = Validator::text($d, 'identificacao', 120);
        $model = Validator::text($d, 'modelo', 150, false);
        $features = Validator::text($d, 'caracteristicas', 4000, false);
        $rows = (int) ($d['fileiras'] ?? 0);
        if ($rows < 1 || $rows > 40) {
            throw new HttpException(422, 'Use de 1 a 40 fileiras.');
        }
        $seats = [];
        $numbers = [];
        foreach (range(1, $rows) as $row) {
            foreach ([1, 2, 4, 5] as $col) {
                $cell = $d['layout'][$row][$col] ?? [];
                $num = trim((string) ($cell['numero'] ?? ''));
                if ($num === '') {
                    continue;
                }
                if (!preg_match('/^[\p{L}\p{N}-]{1,12}$/uD', $num)) {
                    throw new HttpException(
                        422,
                        'Numeração inválida na fileira ' .
                            $row .
                            '. Use letras, números ou hífen, até 12 caracteres.',
                    );
                }
                $key = mb_strtolower($num);
                if (isset($numbers[$key])) {
                    throw new HttpException(422, 'A numeração ' . $num . ' está repetida.');
                }
                $numbers[$key] = true;
                $seats[] = [
                    $num,
                    $row,
                    $col,
                    isset($cell['janela']) ? 1 : 0,
                    isset($cell['ativa']) ? 1 : 0,
                ];
            };
        }
        if (!$seats) {
            throw new HttpException(422, 'Configure pelo menos uma poltrona.');
        }
        return DB::transaction(function () use ($id, $name, $model, $features, $rows, $seats) {
            $bus = $id;
            if ($bus) {
                if (!DB::one('SELECT id FROM onibus WHERE id=? FOR UPDATE', [$bus])) {
                    throw new HttpException(404, 'Ônibus não encontrado.');
                }
                DB::run('UPDATE onibus SET identificacao=?,modelo=?,caracteristicas=? WHERE id=?', [
                    $name,
                    $model,
                    $features,
                    $bus,
                ]);
            } else {
                DB::run('INSERT INTO onibus(identificacao,modelo,caracteristicas) VALUES(?,?,?)', [
                    $name,
                    $model,
                    $features,
                ]);
                $bus = (int) DB::connection()->lastInsertId();
            }
            $v = (int) DB::one(
                'SELECT COALESCE(MAX(versao),0)+1 AS n FROM layouts_onibus WHERE onibus_id=?',
                [$bus],
            )['n'];
            DB::run('INSERT INTO layouts_onibus(onibus_id,nome,versao,fileiras) VALUES(?,?,?,?)', [
                $bus,
                'Layout versão ' . $v,
                $v,
                $rows,
            ]);
            $layout = (int) DB::connection()->lastInsertId();
            foreach ($seats as $s) {
                DB::run(
                    'INSERT INTO poltronas(layout_id,numero,fileira,coluna,janela,ativa) VALUES(?,?,?,?,?,?)',
                    [$layout, ...$s],
                );
            }
            Audit::log('onibus_layout_criado', [
                'onibus' => $bus,
                'versao' => $v,
                'poltronas' => count($seats),
            ]);
            return $bus;
        });
    }
}
