<?php
namespace App\Repositories;
use App\Core\Database as DB;
final class Reservations
{
    public static function find(int $id): ?array
    {
        return DB::one(
            "SELECT r.*,v.nome AS viagem,v.origem AS cidade_origem,v.destino,v.partida,v.retorno,v.embarque,v.status AS viagem_status,(SELECT COALESCE(SUM(CASE WHEN tipo='recebimento' THEN valor ELSE -valor END),0) FROM pagamentos p WHERE p.reserva_id=r.id) AS recebido FROM reservas r JOIN viagens v ON v.id=r.viagem_id WHERE r.id=?",
            [$id],
        );
    }
    public static function passengers(int $id): array
    {
        return DB::all(
            'SELECT rp.*,p.nome,p.telefone,p.observacoes FROM reservas_passageiros rp JOIN passageiros p ON p.id=rp.passageiro_id WHERE rp.reserva_id=? ORDER BY rp.id',
            [$id],
        );
    }
    public static function listing(array $filters = []): array
    {
        $w = ['1=1'];
        $p = [];
        if (!empty($filters['viagem_id'])) {
            $w[] = 'r.viagem_id=?';
            $p[] = (int) $filters['viagem_id'];
        }
        if (!empty($filters['status'])) {
            $w[] = 'r.status=?';
            $p[] = $filters['status'];
        }
        if (!empty($filters['q'])) {
            $w[] =
                '(r.codigo LIKE ? OR r.responsavel LIKE ? OR r.telefone LIKE ? OR EXISTS(SELECT 1 FROM reservas_passageiros rp JOIN passageiros pa ON pa.id=rp.passageiro_id WHERE rp.reserva_id=r.id AND pa.nome LIKE ?))';
            $q = '%' . mb_substr($filters['q'], 0, 150) . '%';
            array_push($p, $q, $q, $q, $q);
        }
        return DB::all(
            "SELECT r.*,v.destino,v.partida,(SELECT COALESCE(SUM(CASE WHEN tipo='recebimento' THEN valor ELSE -valor END),0) FROM pagamentos p WHERE p.reserva_id=r.id) AS recebido, (SELECT GROUP_CONCAT(numero_snapshot ORDER BY id SEPARATOR ', ') FROM reservas_passageiros rp WHERE rp.reserva_id=r.id) AS lugares FROM reservas r JOIN viagens v ON v.id=r.viagem_id WHERE " .
                implode(' AND ', $w) .
                ' ORDER BY r.created_at DESC LIMIT 200',
            $p,
        );
    }
}
