<?php
namespace App\Repositories;
use App\Core\Database as DB;
final class Settings
{
    private static ?array $cache = null;
    public static function all(): array
    {
        if (self::$cache === null) {
            self::$cache = array_column(
                DB::all('SELECT chave,valor FROM configuracoes'),
                'valor',
                'chave',
            );
        }
        return self::$cache;
    }
    public static function get(string $key, string $default = ''): string
    {
        return self::all()[$key] ?? $default;
    }
    public static function clear(): void
    {
        self::$cache = null;
    }
    public static function save(array $values): void
    {
        foreach ($values as $k => $v) {
            DB::run(
                'INSERT INTO configuracoes(chave,valor) VALUES(?,?) ON DUPLICATE KEY UPDATE valor=VALUES(valor)',
                [$k, $v],
            );
        }
        self::clear();
    }
}
