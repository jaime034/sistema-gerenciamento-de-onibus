<?php
namespace App\Repositories;
use App\Core\Database as DB;
final class Trips
{
    public static function find(int $id): ?array
    {
        return DB::one(
            'SELECT v.*,l.fileiras,l.versao,o.identificacao AS onibus,o.modelo,o.caracteristicas FROM viagens v JOIN layouts_onibus l ON l.id=v.layout_id JOIN onibus o ON o.id=l.onibus_id WHERE v.id=?',
            [$id],
        );
    }
    public static function listing(array $filters = [], bool $admin = false): array
    {
        $where = $admin
            ? ['1=1']
            : ["v.status IN('aberta','encerrada')", 'v.partida>UTC_TIMESTAMP()'];
        $p = [];
        if (!empty($filters['destino'])) {
            $where[] = 'v.destino LIKE ?';
            $p[] = '%' . mb_substr($filters['destino'], 0, 150) . '%';
        }
        if (!empty($filters['data']) && preg_match('/^\d{4}-\d{2}-\d{2}$/D', $filters['data'])) {
            $start = utcinput($filters['data'] . ' 00:00:00');
            $end = utcinput($filters['data'] . ' 23:59:59');
            $where[] = 'v.partida BETWEEN ? AND ?';
            $p[] = $start;
            $p[] = $end;
        }
        if ($admin && !empty($filters['status'])) {
            $where[] = 'v.status=?';
            $p[] = $filters['status'];
        }
        if (!empty($filters['disponiveis'])) {
            $where[] =
                "EXISTS(SELECT 1 FROM viagens_poltronas s WHERE s.viagem_id=v.id AND s.estado='livre')";
        }
        return DB::all(
            "SELECT v.*, (SELECT COUNT(*) FROM viagens_poltronas s WHERE s.viagem_id=v.id) AS capacidade, (SELECT COUNT(*) FROM viagens_poltronas s WHERE s.viagem_id=v.id AND s.estado='livre') AS livres, (SELECT COUNT(*) FROM viagens_poltronas s WHERE s.viagem_id=v.id AND s.estado IN('pendente','confirmada')) AS ocupadas FROM viagens v WHERE " .
                implode(' AND ', $where) .
                ' ORDER BY v.partida ' .
                ($admin ? 'DESC' : 'ASC') .
                ' LIMIT 200',
            $p,
        );
    }
}
