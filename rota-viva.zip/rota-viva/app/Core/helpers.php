<?php
declare(strict_types=1);
function config(string $key, mixed $default = null): mixed
{
    $a = $GLOBALS['config'];
    foreach (explode('.', $key) as $k) {
        if (!is_array($a) || !array_key_exists($k, $a)) {
            return $default;
        }
        $a = $a[$k];
    }
    return $a;
}
function e(mixed $v): string
{
    return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function url(string $route = '', array $params = []): string
{
    return rtrim((string) config('app_url'), '/') .
        '/index.php?' .
        http_build_query(['r' => trim($route, '/')] + $params);
}
function asset(string $path): string
{
    return rtrim((string) config('app_url'), '/') . '/assets/' . ltrim($path, '/');
}
function money(mixed $value): string
{
    return 'R$ ' . number_format((float) $value, 2, ',', '.');
}
function datebr(?string $value, bool $time = true): string
{
    if (!$value) {
        return 'Não informado';
    }
    return (new DateTimeImmutable($value, new DateTimeZone('UTC')))
        ->setTimezone(new DateTimeZone(config('timezone')))
        ->format($time ? 'd/m/Y · H:i' : 'd/m/Y');
}
function inputdate(?string $value): string
{
    return $value
        ? (new DateTimeImmutable($value, new DateTimeZone('UTC')))
            ->setTimezone(new DateTimeZone(config('timezone')))
            ->format('Y-m-d\TH:i')
        : '';
}
function utcinput(string $value): string
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2})?$/D', $value)) {
        throw new App\Core\HttpException(422, 'Data ou horário inválido.');
    }
    $normalized = str_replace('T', ' ', $value);
    if (strlen($normalized) === 16) {
        $normalized .= ':00';
    }
    $date = DateTimeImmutable::createFromFormat(
        '!Y-m-d H:i:s',
        $normalized,
        new DateTimeZone(config('timezone')),
    );
    $errors = DateTimeImmutable::getLastErrors();
    if (!$date || ($errors && ($errors['warning_count'] || $errors['error_count']))) {
        throw new App\Core\HttpException(422, 'Data ou horário inválido.');
    }
    return $date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
}

function csrf(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(App\Core\Security::csrf()) . '">';
}
function setting(string $key, string $default = ''): string
{
    return App\Repositories\Settings::get($key, $default);
}
function flash(string $message, string $type = 'success'): void
{
    $_SESSION['flash'][] = compact('message', 'type');
}
function redirect(string $route = '', array $params = []): never
{
    header('Location: ' . url($route, $params), true, 303);
    exit();
}
function statuslabel(string $s): string
{
    return [
        'livre' => 'Disponível',
        'hold' => 'Reserva temporária',
        'pendente' => 'Aguardando pagamento',
        'parcial' => 'Pagamento parcial',
        'confirmada' => 'Confirmada',
        'cancelada' => 'Cancelada',
        'expirada' => 'Expirada',
        'bloqueada' => 'Bloqueada',
        'aberta' => 'Reservas abertas',
        'rascunho' => 'Rascunho',
        'encerrada' => 'Reservas encerradas',
        'em_andamento' => 'Em andamento',
        'concluida' => 'Concluída',
        'recebimento' => 'Recebimento',
        'estorno' => 'Estorno',
    ][$s] ?? ucfirst($s);
}
function badge(string $s): string
{
    return '<span class="badge badge-' . e($s) . '">' . e(statuslabel($s)) . '</span>';
}
function selected(mixed $a, mixed $b): string
{
    return (string) $a === (string) $b ? ' selected' : '';
}
function icon(string $name): string
{
    $paths = [
        'bus' =>
            '<rect x="4" y="3" width="16" height="16" rx="4"/><path d="M4 10h16M8 6h8M7 19v2m10-2v2M8 14h.01M16 14h.01"/>',
        'arrow' => '<path d="M5 12h14m-6-6 6 6-6 6"/>',
        'calendar' =>
            '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4m10-4v4M3 11h18"/>',
        'pin' =>
            '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
        'users' =>
            '<circle cx="9" cy="7" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3m1-17a3 3 0 0 1 0 6m2 4a5 5 0 0 1 3 5v2"/>',
        'chart' => '<path d="M4 3v17h17M8 15v-4m5 4V7m5 8v-5"/>',
        'wallet' =>
            '<rect x="3" y="5" width="18" height="15" rx="3"/><path d="M3 8V5a2 2 0 0 1 2-2h12m4 8h-6v5h6"/>',
        'seat' => '<path d="M6 15V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v10M4 11v6h16v-6M6 17v4m12-4v4"/>',
        'shield' =>
            '<path d="m12 2 8 4v6c0 5-8 10-8 10S4 17 4 12V6l8-4Z"/><path d="m8 11 3 3 5-5"/>',
        'settings' =>
            '<path d="m9 3-1 3-3 1v4l-2 1 2 1v4l3 1 1 3h6l1-3 3-1v-4l2-1-2-1V7l-3-1-1-3Z"/><circle cx="12" cy="12" r="3"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'check' => '<path d="m5 12 4 4L19 6"/>',
        'search' => '<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
        'logout' => '<path d="M9 3H4v18h5m4-14 5 5-5 5m-5-5h10"/>',
        'ticket' =>
            '<path d="M3 5h18v5a2 2 0 0 0 0 4v5H3v-5a2 2 0 0 0 0-4V5Z"/><path d="M15 5v3m0 3v2m0 3v3"/>',
        'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
        'sun' =>
            '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1 1m12 12 1 1M5 19l1-1M18 6l1-1"/>',
        'download' => '<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
        'phone' => '<path d="m5 3 4 1 1 5-3 2c2 4 3 5 7 7l2-3 5 1 1 4c-1 5-8 1-12-3S1 4 5 3Z"/>',
        'home' => '<path d="m3 10 9-8 9 8v11H3V10Zm6 11v-8h6v8"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
    ];
    return '<svg class="icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' .
        ($paths[$name] ?? $paths['bus']) .
        '</svg>';
}
