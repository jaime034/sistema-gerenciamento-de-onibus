<?php
namespace App\Core;
final class View
{
    public static function render(string $view, array $data = [], string $layout = 'public'): void
    {
        extract($data, EXTR_SKIP);
        ob_start();
        require BASE_PATH . '/app/Views/' . $view . '.php';
        $content = ob_get_clean();
        require BASE_PATH . '/app/Views/layouts/' . $layout . '.php';
    }
    public static function json(array $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        exit();
    }
}
