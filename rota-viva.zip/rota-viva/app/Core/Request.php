<?php
namespace App\Core;
final class Request
{
    public static function json(): array
    {
        if (!str_starts_with(strtolower($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json')) {
            throw new HttpException(415, 'Envie os dados no formato JSON.');
        }
        $raw = file_get_contents('php://input', false, null, 0, 65537);
        if (strlen($raw) > 65536) {
            throw new HttpException(413, 'A solicitação ultrapassou o limite permitido.');
        }
        try {
            $data = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            throw new HttpException(422, 'Os dados enviados não são um JSON válido.');
        }
        if (!is_array($data)) {
            throw new HttpException(422, 'Envie um objeto JSON válido.');
        }
        return $data;
    }
}
