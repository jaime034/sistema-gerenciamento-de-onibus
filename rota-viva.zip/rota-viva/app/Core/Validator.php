<?php
namespace App\Core;
final class Validator
{
    public static function text(array $d, string $k, int $max = 150, bool $required = true): string
    {
        $v = trim((string) ($d[$k] ?? ''));
        if (($required && $v === '') || mb_strlen($v) > $max) {
            throw new HttpException(
                422,
                'Verifique o campo ' .
                    str_replace('_', ' ', $k) .
                    '. Máximo: ' .
                    $max .
                    ' caracteres.',
            );
        }
        return $v;
    }
    public static function phone(string $v): string
    {
        $v = preg_replace('/\D/', '', $v);
        if (strlen($v) < 10 || strlen($v) > 15) {
            throw new HttpException(422, 'Informe um telefone com DDD válido.');
        }
        return $v;
    }
    public static function email(string $v): ?string
    {
        if ($v === '') {
            return null;
        }
        if (strlen($v) > 190 || !filter_var($v, FILTER_VALIDATE_EMAIL)) {
            throw new HttpException(422, 'Informe um e-mail válido.');
        }
        return $v;
    }
    public static function ids(mixed $v): array
    {
        if (!is_array($v)) {
            throw new HttpException(422, 'Selecione as poltronas.');
        }
        $a = array_values(array_unique(array_map('intval', $v)));
        sort($a);
        if (!$a || min($a) < 1 || count($a) > 160) {
            throw new HttpException(422, 'Seleção de poltronas inválida.');
        }
        return $a;
    }
}
