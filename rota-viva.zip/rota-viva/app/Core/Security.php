<?php
namespace App\Core;
final class Security
{
    public static function isHttps(): bool
    {
        return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
            ($_SERVER['SERVER_PORT'] ?? '') === '443' ||
            (in_array($_SERVER['REMOTE_ADDR'] ?? '', config('trusted_proxies', []), true) &&
                ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    }
    public static function start(): void
    {
        $secure = config('environment') === 'production';
        if (!is_dir(BASE_PATH . '/storage/sessions')) {
            mkdir(BASE_PATH . '/storage/sessions', 0700, true);
        }
        session_save_path(BASE_PATH . '/storage/sessions');
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        session_name('rv_session');
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => parse_url(config('app_url'), PHP_URL_PATH) ?: '/',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
        header(
            "Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
        );
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: no-referrer');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
        header('Cache-Control: no-store, private');
        if ($secure) {
            header('Strict-Transport-Security: max-age=31536000');
        }
    }
    public static function csrf(): string
    {
        return $_SESSION['_csrf'] ??= bin2hex(random_bytes(32));
    }
    public static function validateCsrf(): void
    {
        $provided = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        if (!is_string($provided) || !hash_equals(self::csrf(), $provided)) {
            throw new HttpException(
                419,
                'Sua sessão expirou. Atualize a página e tente novamente.',
            );
        }
    }
    public static function secretHash(string $v): string
    {
        if (strlen(config('app_key', '')) < 32) {
            throw new \RuntimeException('APP_KEY ausente.');
        }
        return hash_hmac('sha256', $v, config('app_key'));
    }
    public static function holdOwner(int $trip): string
    {
        return $_SESSION['holds'][$trip] ??= bin2hex(random_bytes(32));
    }
    public static function rate(
        string $scope,
        int $max,
        int $seconds,
        string $extra = '',
        bool $bindIp = true,
    ): void {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'cli';
        $key = self::secretHash($scope . '|' . ($bindIp ? $ip : 'global') . '|' . $extra);
        $now = gmdate('Y-m-d H:i:s');
        $limit = gmdate('Y-m-d H:i:s', time() - $seconds);
        $count = Database::transaction(function () use ($key, $now, $limit) {
            Database::run(
                'INSERT IGNORE INTO limites_requisicoes(chave,tentativas,janela_inicio) VALUES(?,0,?)',
                [$key, $now],
            );
            $row = Database::one('SELECT * FROM limites_requisicoes WHERE chave=? FOR UPDATE', [
                $key,
            ]);
            $n = $row['janela_inicio'] < $limit ? 1 : (int) $row['tentativas'] + 1;
            Database::run(
                'UPDATE limites_requisicoes SET tentativas=?,janela_inicio=? WHERE chave=?',
                [$n, $row['janela_inicio'] < $limit ? $now : $row['janela_inicio'], $key],
            );
            return $n;
        });
        if ($count > $max) {
            header('Retry-After: ' . $seconds);
            throw new HttpException(
                429,
                'Muitas tentativas. Aguarde alguns minutos e tente novamente.',
            );
        }
    }
    public static function user(): ?array
    {
        if (empty($_SESSION['admin'])) {
            return null;
        }
        $u = Database::one(
            'SELECT id,nome,email,session_version FROM usuarios WHERE id=? AND ativo=1',
            [$_SESSION['admin']['id']],
        );
        if (
            !$u ||
            $u['session_version'] !== $_SESSION['admin']['version'] ||
            time() - ($_SESSION['admin']['last'] ?? 0) > 3600
        ) {
            unset($_SESSION['admin']);
            return null;
        }
        $_SESSION['admin']['last'] = time();
        return $u;
    }
    public static function requireAdmin(): array
    {
        $u = self::user();
        if (!$u) {
            if (self::isJson()) {
                throw new HttpException(401, 'Entre no painel para continuar.');
            }
            redirect('admin/login');
        }
        return $u;
    }
    public static function isJson(): bool
    {
        return str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') ||
            str_starts_with(trim($_GET['r'] ?? '', '/'), 'api/');
    }
    public static function authorizeReservation(string $code): array
    {
        $r = Database::one('SELECT * FROM reservas WHERE codigo=?', [$code]);
        if (
            !$r ||
            !is_string($_SESSION['reservas'][$code] ?? null) ||
            !hash_equals($r['token_hash'], $_SESSION['reservas'][$code])
        ) {
            throw new HttpException(403, 'Consulte a reserva com seu código e chave de acesso.');
        }
        return $r;
    }
}
