<?php
namespace App\Core;
use PDO;
final class Database
{
    private static ?PDO $pdo = null;
    public static function connection(): PDO
    {
        if (self::$pdo) {
            return self::$pdo;
        }
        $c = config('db');
        self::$pdo = new PDO(
            "mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset=utf8mb4",
            $c['user'],
            $c['password'],
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ],
        );
        self::$pdo->exec("SET time_zone = '+00:00'");
        return self::$pdo;
    }
    public static function run(string $sql, array $params = []): \PDOStatement
    {
        $s = self::connection()->prepare($sql);
        $s->execute($params);
        return $s;
    }
    public static function one(string $sql, array $params = []): ?array
    {
        return self::run($sql, $params)->fetch() ?: null;
    }
    public static function all(string $sql, array $params = []): array
    {
        return self::run($sql, $params)->fetchAll();
    }
    public static function transaction(callable $fn): mixed
    {
        $p = self::connection();
        for ($n = 0; ; $n++) {
            try {
                $p->beginTransaction();
                $r = $fn();
                $p->commit();
                return $r;
            } catch (\Throwable $e) {
                if ($p->inTransaction()) {
                    $p->rollBack();
                }
                if (
                    $e instanceof \PDOException &&
                    in_array((int) ($e->errorInfo[1] ?? 0), [1213, 1205], true) &&
                    $n < 2
                ) {
                    usleep(random_int(10000, 50000));
                    continue;
                }
                throw $e;
            }
        }
    }
}
