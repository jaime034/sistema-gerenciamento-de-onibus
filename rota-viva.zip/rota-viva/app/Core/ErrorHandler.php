<?php
namespace App\Core;
final class ErrorHandler
{
    public static function handle(\Throwable $e): void
    {
        $status = $e instanceof HttpException ? $e->status : 500;
        $message =
            $status === 500
                ? 'Não foi possível concluir agora. Tente novamente ou contate o responsável.'
                : $e->getMessage();
        if ($status === 500) {
            error_log($e->__toString());
        }
        if (PHP_SAPI === 'cli') {
            fwrite(STDERR, $e->__toString() . PHP_EOL);
            exit(1);
        }
        if (Security::isJson()) {
            View::json(['error' => $message], $status);
        }
        http_response_code($status);
        $title = 'Vamos tentar de novo';
        $content =
            '<section class="empty card"><span class="eyebrow">Erro ' .
            e($status) .
            '</span><h1>Algo precisa da sua atenção.</h1><p>' .
            e($message) .
            '</p><a class="button" href="' .
            e(url()) .
            '">Voltar ao início</a><button class="button secondary" type="button" data-back>Voltar à página anterior</button></section>';
        try {
            require BASE_PATH . '/app/Views/layouts/public.php';
        } catch (\Throwable) {
            echo '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Rota Viva</title><h1>Configuração necessária</h1><p>' .
                e($message) .
                '</p><p>Consulte o README.md para instalar a aplicação.</p></html>';
        }
    }
}
