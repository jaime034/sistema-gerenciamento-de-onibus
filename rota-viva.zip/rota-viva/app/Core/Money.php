<?php
namespace App\Core;
final class Money
{
    public static function cents(mixed $v): int
    {
        $s = trim((string) $v);
        if (str_contains($s, ',')) {
            $s = str_replace(['.', ','], ['', '.'], $s);
        }
        if (!preg_match('/^\d{1,8}(\.\d{1,2})?$/D', $s)) {
            throw new HttpException(
                422,
                'Informe um valor monetário válido, com até duas casas decimais.',
            );
        }
        [$a, $b] = array_pad(explode('.', $s), 2, '');
        return (int) $a * 100 + (int) str_pad($b, 2, '0');
    }
    public static function decimal(int $c): string
    {
        return sprintf('%d.%02d', intdiv($c, 100), $c % 100);
    }
}
