<section class="lookup-layout">
<div>
<span class="eyebrow">TUDO PRONTO PARA O PRÓXIMO DESTINO?</span>
<h1>Sua viagem,<br>sempre à mão.</h1>
<p class="muted">Consulte o pagamento, confira as poltronas e baixe o comprovante quando sua reserva estiver confirmada.</p>
<div class="privacy-note"><?= icon(
    'shield',
) ?><p>Para proteger seus dados, precisamos do código e da chave privada fornecidos ao concluir a reserva.</p>
</div>
</div>
<form class="card stack" action="<?= e(
    url('consulta'),
) ?>" method="post" data-lookup><?= csrf() ?><span class="brand-mark"><?= icon(
    'ticket',
) ?></span>
<h2>Consultar reserva</h2>
<label>Código da reserva<input name="codigo" required maxlength="32" placeholder="RV-…" autocomplete="off">
</label>
<label>Chave privada de acesso<textarea name="token" rows="3" required minlength="64" maxlength="64" autocomplete="off" spellcheck="false" placeholder="Cole sua chave de 64 caracteres">
</textarea>
</label>
<button class="button full" type="submit">Acessar minha reserva <?= icon(
    'arrow',
) ?></button>
<p class="small muted">Se perdeu sua chave, contate o responsável. Ele poderá gerar uma nova após verificar sua identidade.</p>
</form>
</section>
