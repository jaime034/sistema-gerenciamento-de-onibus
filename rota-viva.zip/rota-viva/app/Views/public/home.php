<section class="hero">
<div class="hero-copy">
<span class="eyebrow pill-light"><?= icon(
    'pin',
) ?> NOVOS DESTINOS, BOAS HISTÓRIAS</span>
<h1>A próxima boa<br>lembrança começa<br>
<em>na estrada.</em>
</h1>
<p>Escolha seu destino, encontre sua poltrona e prepare-se para aproveitar cada momento da viagem.</p>
<div class="button-row">
<a class="button lime" href="<?= e(
     url('viagens'),
 ) ?>">Explorar viagens <?= icon('arrow') ?></a>
<a class="hero-link" href="<?= e(
    url('consulta'),
) ?>">Já tenho uma reserva ↗</a>
</div>
<div class="hero-trust">
<span><?= icon(
    'seat',
) ?> Seu lugar escolhido</span>
<span><?= icon(
     'shield',
 ) ?> Reserva com segurança</span>
</div>
</div>
<div class="hero-scene">
<img src="<?= e(
     asset('journey.svg'),
 ) ?>" alt="Ilustração de um ônibus em uma estrada entre montanhas, com o sol no horizonte">
<div class="journey-note">
<span class="note-icon"><?= icon(
    'bus',
) ?></span>
<span>O caminho também<br>
<strong>faz parte da experiência.</strong>
</span>
</div>
</div>
</section>
<section class="quick-links">
<a href="<?= e(url('viagens')) ?>"><?= icon(
    'calendar',
) ?><span>
<strong>Encontre uma viagem</strong>
<small>Veja os próximos destinos</small>
</span><?= icon(
    'arrow',
) ?></a>
<a href="<?= e(url('consulta')) ?>"><?= icon(
    'ticket',
) ?><span>
<strong>Acompanhe sua reserva</strong>
<small>Pagamento, poltronas e comprovante</small>
</span><?= icon(
    'arrow',
) ?></a>
</section>
<section class="section">
<div class="section-heading">
<div>
<span class="eyebrow">ESCOLHA SEU PRÓXIMO ROTEIRO</span>
<h2>Tem um destino esperando por você.</h2>
</div>
<a class="text-link" href="<?= e(
    url('viagens'),
) ?>">Todas as viagens <?= icon('arrow') ?></a>
</div><?php if (
    $trips
): ?><div class="trip-grid"><?php foreach ($trips as $t) {
    require BASE_PATH . '/app/Views/components/trip-card.php';
} ?></div><?php else: ?><div class="empty card">
<span class="empty-icon"><?= icon(
    'calendar',
) ?></span>
<h3>Novos caminhos estão sendo preparados.</h3>
<p>Em breve, você encontrará nossas próximas viagens aqui.</p><?php if (
    setting('whatsapp')
): ?><a class="button" href="<?= e(
    'https://wa.me/' .
        setting('whatsapp') .
        '?text=' .
        rawurlencode('Olá! Gostaria de saber sobre as próximas viagens.'),
) ?>">Consultar próximas saídas</a><?php endif; ?></div><?php endif; ?></section>
<section class="experience">
<div class="experience-art">
<img src="<?= e(
    asset('bus.svg'),
) ?>" alt="Ilustração de ônibus rodoviário">
</div>
<div>
<span class="eyebrow">DO EMBARQUE ÀS BOAS MEMÓRIAS</span>
<h2>Seu passeio começa<br>com uma boa escolha.</h2>
<p class="muted">Veja o roteiro, escolha seu lugar no mapa do ônibus e acompanhe sua reserva sem precisar criar uma conta.</p>
<ul class="feature-list">
<li><?= icon(
    'seat',
) ?><span>
<strong>Você escolhe onde sentar</strong>Mapa com os números reais das poltronas.</span>
</li>
<li><?= icon(
    'wallet',
) ?><span>
<strong>Pagamento com orientação clara</strong>Pix conferido pelo responsável pelo serviço.</span>
</li>
<li><?= icon(
    'phone',
) ?><span>
<strong>Contato direto</strong>Informações da viagem a poucos toques.</span>
</li>
</ul>
</div>
</section>
<section class="how section">
<div>
<span class="eyebrow">SIMPLES, DO SEU JEITO</span>
<h2>Da escolha ao embarque.</h2>
</div>
<div class="steps">
<article>
<span>01</span>
<h3>Encontre seu destino</h3>
<p>Consulte datas, saída, roteiro e condições.</p>
</article>
<article>
<span>02</span>
<h3>Escolha sua poltrona</h3>
<p>Reserve os lugares e informe os passageiros.</p>
</article>
<article>
<span>03</span>
<h3>Confirme e aproveite</h3>
<p>Após a conferência do pagamento, emita seu comprovante.</p>
</article>
</div>
</section>
