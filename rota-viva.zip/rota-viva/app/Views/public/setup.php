<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Instalar Rota Viva</title>
<link rel="stylesheet" href="<?= e(
    asset('app.css'),
) ?>">
</head>
<body class="setup-body">
<main class="card setup-card">
<span class="brand-mark"><?= icon(
    'bus',
) ?></span>
<span class="eyebrow">PRIMEIRO ACESSO</span>
<h1>Prepare sua Rota Viva.</h1><?php if (
    !$ready
): ?><p>Copie <code>config/config.example.php</code> para <code>config/config.php</code> fora da pasta pública e configure a conexão MySQL, o endereço do site e os segredos <code>app_key</code> e <code>setup_token</code>.</p>
<p>Use uma chave aleatória de 64 caracteres em cada campo. O README.md descreve o processo completo, inclusive a opção sem SSH.</p>
<a class="button" href="<?= e(
    url('instalar'),
) ?>">Verificar configuração</a><?php else: ?><p class="muted">Este assistente instala as tabelas se necessário e cria o primeiro administrador. Use somente banco vazio ou com o SQL original já importado.</p>
<form method="post" action="<?= e(
    url('instalar'),
) ?>" class="stack"><?= csrf() ?><label>Chave de instalação<input name="setup_token" type="password" autocomplete="off" required minlength="32">
</label>
<label>Nome do proprietário<input name="nome" required maxlength="120" autocomplete="name">
</label>
<label>E-mail de acesso<input name="email" type="email" required maxlength="190" autocomplete="username">
</label>
<label>Senha (12 a 72 caracteres)<input name="senha" type="password" required minlength="12" maxlength="72" autocomplete="new-password">
</label>
<label>Confirme a senha<input name="confirmacao" type="password" required minlength="12" maxlength="72" autocomplete="new-password">
</label>
<button class="button" type="submit">Instalar e criar administrador</button>
</form><?php endif; ?></main>
</body>
</html>
