<section class="page-heading">
<span class="eyebrow">INFORMAÇÃO E CONFIANÇA</span>
<h1>Antes de reservar.</h1>
<p class="muted">Conheça as condições do serviço e como seus dados são utilizados.</p>
</section>
<div class="legal-grid">
<article class="prose card">
<h2>Regras de reserva e cancelamento</h2>
<p><?= nl2br(
    e(setting('regras_cancelamento')),
) ?></p>
<h3>Escolha temporária</h3>
<p>Ao selecionar seus lugares, eles ficam protegidos por até <?= (int) setting(
    'hold_minutos',
) ?> minutos, respeitando o horário da partida. Conclua os dados dentro desse prazo.</p>
<h3>Pagamento e confirmação</h3>
<p>A reserva aguarda pagamento por até <?= (int) setting(
     'pagamento_horas',
 ) ?> horas, limitada ao horário de partida. Sem registro financeiro até o prazo, ela pode expirar e liberar os lugares. Pagamentos parciais exigem análise do responsável. O Pix é confirmado manualmente após conferência.</p>
<h3>Embarque</h3>
<p><?= nl2br(
     e(setting('instrucoes_embarque')),
 ) ?></p>
</article>
<article class="prose card">
<h2>Aviso de privacidade</h2>
<p><?= nl2br(
    e(setting('privacidade')),
) ?></p>
<h3>Proteja seu acesso</h3>
<p>O link ou a chave privada permitem acessar sua reserva. Compartilhe-os somente com pessoas autorizadas. Não publicamos nomes ou contatos de passageiros no mapa público.</p>
<h3>Responsável pelo serviço</h3>
<p><?= e(
    setting('proprietario') ?: setting('nome_servico'),
) ?><br><?= e(setting('telefone')) ?><br><?= e(setting('email_contato')) ?></p>
</article>
</div>
