<a class="back-link" href="<?= e(
    url('viagens'),
) ?>">← Todas as viagens</a>
<section class="detail-banner"><?php if (
    $trip['capa']
): ?><img src="<?= e(
    url('imagem', ['arquivo' => $trip['capa']]),
) ?>" alt="Destino da viagem"><?php else: ?><img src="<?= e(
    asset('destination.svg'),
) ?>" alt="Ilustração de montanhas e paisagem"><?php endif; ?><div>
<span class="eyebrow">SUA PRÓXIMA EXPERIÊNCIA</span>
<h1><?= e(
    $trip['nome'],
) ?></h1>
<p><?= e($trip['origem']) ?> <?= icon('arrow') ?> <?= e($trip['destino']) ?></p><?php if (
    $trip['demonstrativo']
): ?><span class="badge">Viagem fictícia para demonstração</span><?php endif; ?></div>
</section>
<div class="detail-grid">
<div>
<div class="trip-facts card">
<div><?= icon(
    'calendar',
) ?><span>Partida<strong><?= e(datebr($trip['partida'])) ?></strong>
</span>
</div>
<div><?= icon(
    'pin',
) ?><span>Embarque<strong><?= nl2br(e($trip['embarque'])) ?></strong>
</span>
</div>
<div><?= icon(
    'clock',
) ?><span>Previsão de retorno<strong><?= e(
    datebr($trip['retorno']),
) ?></strong>
</span>
</div>
<div><?= icon('bus') ?><span>Seu ônibus<strong><?= e(
    $trip['onibus'],
) ?></strong>
</span>
</div>
</div>
<article class="prose card">
<h2>O que espera por você</h2>
<p><?= nl2br(
    e($trip['descricao'] ?: 'Confira os detalhes do roteiro com o responsável pela viagem.'),
) ?></p>
<h3>Antes de embarcar</h3>
<p><?= nl2br(
    e($trip['orientacoes'] ?: setting('instrucoes_embarque')),
) ?></p><?php if ($trip['caracteristicas']): ?><h3>Sobre o ônibus</h3>
<p><?= nl2br(
    e($trip['caracteristicas']),
) ?></p><?php endif; ?><h3>Reserva e cancelamento</h3>
<p><?= nl2br(
    e(setting('regras_cancelamento')),
) ?></p>
</article>
</div>
<aside class="booking-card card">
<span class="eyebrow">VIVA ESSE DESTINO</span>
<small class="muted">Valor por passageiro</small>
<strong class="big-price"><?= money(
    $trip['preco'],
) ?></strong><?= badge($trip['status']) ?><p class="icon-line"><?=
icon('seat') . $free
?> lugares disponíveis</p><?php if (
     $trip['status'] === 'aberta' &&
     $trip['partida'] > gmdate('Y-m-d H:i:s') &&
     $free > 0
 ): ?><a class="button full" href="<?= e(
    url('poltronas', ['id' => $trip['id']]),
) ?>">Escolher minha poltrona <?= icon(
    'arrow',
) ?></a><?php else: ?><p class="alert">As reservas estão encerradas ou todos os lugares estão ocupados.</p><?php endif; ?><p class="small muted"><?= icon(
    'shield',
) ?> Sua escolha é validada antes de concluir.</p>
<a class="button secondary full" href="<?= e(
     'https://wa.me/' .
         setting('whatsapp') .
         '?text=' .
         rawurlencode(
             'Confira esta viagem: ' . $trip['nome'] . ' ' . url('viagem', ['id' => $trip['id']]),
         ),
 ) ?>" target="_blank" rel="noopener">Compartilhar viagem ↗</a>
</aside>
</div>
