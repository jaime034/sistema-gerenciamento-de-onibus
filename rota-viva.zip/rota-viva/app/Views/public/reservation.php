<section class="page-heading compact">
<span class="eyebrow">SUA PRÓXIMA EXPERIÊNCIA</span>
<h1><?= $r[
    'status'
] === 'confirmada'
    ? 'Sua viagem está confirmada.'
    : 'Acompanhe sua reserva.' ?></h1>
<p class="muted">Código <strong><?= e(
    $r['codigo'],
) ?></strong> · <?= badge($r['status']) ?></p>
</section>
<?php if ($private):
    $access =
        url('consulta') .
        '#' .
        http_build_query([
            'codigo' => $r['codigo'],
            'token' => $private,
        ]); ?><section class="alert access-alert">
<div>
<strong>Guarde seu acesso privado</strong>
<p>Este link permite consultar os dados da reserva. Compartilhe somente com o responsável pela compra.</p>
<label>Link privado<input value="<?= e(
    $access,
) ?>" readonly data-private-link>
</label>
<details>
<summary>Ver código e chave para consulta manual</summary>
<p>Código: <?= e(
    $r['codigo'],
) ?></p>
<code class="break"><?= e(
    $private,
) ?></code>
</details>
</div>
<button class="button small" data-copy="<?= e(
    $access,
) ?>" type="button">Copiar acesso</button>
</section><?php
endif; ?>
<div class="detail-grid">
<div class="stack">
<section class="card prose">
<div class="spread">
<h2><?= e(
    $r['viagem'],
) ?></h2><?= icon('bus') ?></div>
<p><?= e($r['cidade_origem']) ?> → <?= e(
     $r['destino'],
 ) ?></p>
<div class="trip-facts">
<div><?= icon('calendar') ?><span>Partida<strong><?= e(
    datebr($r['partida']),
) ?></strong>
</span>
</div>
<div><?= icon('pin') ?><span>Embarque<strong><?= nl2br(
    e($r['embarque']),
) ?></strong>
</span>
</div>
</div>
<h3>Passageiros e poltronas</h3><?php foreach (
    $passengers
    as $p
): ?><div class="passenger-ticket">
<span class="seat-number"><?= e(
    $p['numero_snapshot'],
) ?></span>
<span>
<small class="muted">Passageiro</small>
<strong><?= e(
    $p['nome'],
) ?></strong>
</span>
</div><?php endforeach; ?><h3>Regras aceitas na reserva</h3>
<p><?= nl2br(
    e($r['regras_snapshot']),
) ?></p>
</section>
</div>
<aside class="stack">
<section class="card prose">
<h2>Pagamento</h2>
<div class="summary-row">
<span>Total da reserva</span>
<strong><?= money(
    $r['total'],
) ?></strong>
</div>
<div class="summary-row">
<span>Recebimento líquido</span>
<strong><?= money(
    $r['recebido'],
) ?></strong>
</div>
<div class="summary-row total">
<span>Saldo</span>
<strong><?= money(
    max(0, (float) $r['total'] - (float) $r['recebido']),
) ?></strong>
</div><?php if (
    in_array($r['status'], ['pendente', 'parcial'], true)
): ?><p class="small">Prazo: <strong><?= e(datebr($r['prazo_pagamento'])) ?></strong>
</p><?php if (
    setting('pix_chave')
): ?><div class="pix-box">
<strong>Pix para pagamento</strong>
<label>Chave Pix<input readonly value="<?= e(
    setting('pix_chave'),
) ?>">
</label>
<button class="button secondary full" type="button" data-copy="<?= e(
    setting('pix_chave'),
) ?>">Copiar chave Pix</button>
<p class="small">Beneficiário: <?= e(
    setting('pix_beneficiario') ?: 'Confirme com o responsável antes de pagar.',
) ?></p>
</div><?php else: ?><p class="alert warning">A chave Pix ainda não foi configurada. Solicite as instruções ao responsável.</p><?php endif; ?><p><?= nl2br(
    e(setting('pix_instrucoes')),
) ?></p>
<p class="small muted">O envio do Pix não atualiza automaticamente esta página. O proprietário precisa conferir e registrar o recebimento. Atualize a página para consultar a situação.</p>
<a class="button secondary full" href="<?= e(
    url('reserva', ['codigo' => $r['codigo']]),
) ?>">Atualizar situação</a><?php elseif (
    $r['status'] === 'confirmada'
): ?><p class="alert success">Reserva confirmada. Seu comprovante está disponível.</p>
<a class="button full" href="<?= e(
    url('comprovante', ['codigo' => $r['codigo']]),
) ?>"><?= icon('download') ?> Baixar comprovante PDF</a>
<p class="small muted"><?= nl2br(
     e(setting('instrucoes_embarque')),
 ) ?></p><?php else: ?><p class="alert warning">Esta reserva está <?= e(
    statuslabel($r['status']),
) ?>. Os lugares foram liberados. Se houve pagamento, contate o responsável para a conferência dos valores.</p><?php endif; ?></section><?php if (
    setting('whatsapp')
): ?><a class="button secondary full" target="_blank" rel="noopener" href="<?= e(
    'https://wa.me/' .
        setting('whatsapp') .
        '?text=' .
        rawurlencode('Olá! Preciso de ajuda com a reserva ' . $r['codigo'] . '.'),
) ?>">Falar com o responsável ↗</a><?php endif; ?></aside>
</div>
