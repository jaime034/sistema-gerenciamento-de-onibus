<section class="page-heading">
<span class="eyebrow">PRÓXIMAS SAÍDAS</span>
<h1>Para onde vamos?</h1>
<p class="muted">Encontre a viagem que combina com o seu próximo descanso.</p>
</section>
<form class="filter-bar card" action="<?= e(
    config('app_url'),
) ?>/index.php" method="get">
<input type="hidden" name="r" value="viagens">
<label>Destino<input name="destino" placeholder="Qual é o seu destino?" value="<?= e(
    $_GET['destino'] ?? '',
) ?>" maxlength="150">
</label>
<label>Data de partida<input type="date" name="data" value="<?= e(
    $_GET['data'] ?? '',
) ?>">
</label>
<label class="check">
<input type="checkbox" name="disponiveis" value="1" <?= !empty(
    $_GET['disponiveis']
)
    ? 'checked'
    : '' ?>>Somente com lugares livres</label>
<button class="button" type="submit"><?= icon(
    'search',
) ?> Buscar</button>
<a class="text-link" href="<?= e(
     url('viagens'),
 ) ?>">Limpar</a>
</form>
<div class="spread results-heading">
<p class="muted"><?= count(
    $trips,
) ?> <?= count($trips) === 1
     ? 'viagem encontrada'
     : 'viagens encontradas' ?></p>
<span class="small muted">Disponibilidade atualizada no servidor</span>
</div><?php if (
    $trips
): ?><div class="trip-grid"><?php foreach ($trips as $t) {
    require BASE_PATH . '/app/Views/components/trip-card.php';
} ?></div><?php else: ?><div class="empty card"><?= icon(
    'calendar',
) ?><h2>Nenhuma viagem por aqui ainda.</h2>
<p>Tente outro filtro ou volte em breve para conferir as novas saídas.</p>
<a class="button secondary" href="<?= e(
    url('viagens'),
) ?>">Ver todas as viagens</a>
</div><?php endif; ?>
