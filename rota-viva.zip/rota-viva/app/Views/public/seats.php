<a class="back-link" href="<?= e(
    url('viagem', ['id' => $trip['id']]),
) ?>">← Detalhes da viagem</a>
<div class="page-heading compact">
<span class="eyebrow">SEU LUGAR NA PRÓXIMA EXPERIÊNCIA</span>
<h1>Escolha onde vai sentar.</h1>
<p class="muted"><?= e(
    $trip['nome'],
) ?> · <?= e(datebr($trip['partida'])) ?></p>
</div><?php require BASE_PATH .
    '/app/Views/components/booking-map.php'; ?>
