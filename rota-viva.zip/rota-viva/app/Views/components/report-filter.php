<form class="filter-bar card" method="get">
<input name="r" type="hidden" value="<?= e(
    $filterRoute ?? 'admin/relatorios',
) ?>"><?php if (
    ($filterRoute ?? '') !==
    'admin/financeiro'
): ?><label>Relatório<select name="tipo"><?php foreach (
    [
        'financeiro' => 'Financeiro por viagem',
        'movimentos' => 'Recebimentos por período',
        'passageiros' => 'Lista de passageiros',
        'vendidas' => 'Passagens confirmadas',
        'ocupacao' => 'Mapa de ocupação',
        'pendentes' => 'Reservas pendentes',
        'cancelamentos' => 'Cancelamentos e expirações',
    ]
    as $k => $v
): ?><option value="<?= $k ?>"<?= selected($_GET['tipo'] ?? 'financeiro', $k) ?>><?= e(
    $v,
) ?></option><?php endforeach; ?></select>
</label><?php endif; ?><label>Viagem<select name="viagem_id">
<option value="">Todas</option><?php foreach (
    $trips
    as $t
): ?><option value="<?= $t['id'] ?>"<?= selected($_GET['viagem_id'] ?? '', $t['id']) ?>><?= e(
    $t['nome'],
) ?> · <?= e(
     datebr($t['partida'], false),
 ) ?></option><?php endforeach; ?></select>
</label>
<label>De<input name="inicio" type="date" value="<?= e(
    $_GET['inicio'] ?? date('Y-m-01'),
) ?>" required>
</label>
<label>Até<input name="fim" type="date" value="<?= e(
    $_GET['fim'] ?? date('Y-m-t'),
) ?>" required>
</label>
<button class="button secondary">Consultar</button>
</form>
