<div class="table-scroll">
<table>
<thead>
<tr>
<th>Reserva / responsável</th>
<th>Viagem</th>
<th>Poltronas</th>
<th>Valor / recebido</th>
<th>Situação</th>
<th>
<span class="sr-only">Ação</span>
</th>
</tr>
</thead>
<tbody><?php
foreach ($reservations as $row): ?><tr>
<td>
<a class="text-link" href="<?= e(
    url('admin/reserva', ['id' => $row['id']]),
) ?>"><?= e($row['codigo']) ?></a>
<small><?= e($row['responsavel']) ?></small>
</td>
<td><?= e(
    $row['destino'],
) ?><small><?= e(datebr($row['partida'])) ?></small>
</td>
<td><?= e(
    $row['lugares'],
) ?></td>
<td>
<strong><?= money($row['total']) ?></strong>
<small><?= money(
    $row['recebido'],
) ?> recebidos</small>
</td>
<td><?=
 badge($row['status']) ?><?php if (
     in_array($row['status'], ['pendente', 'parcial']) &&
     $row['prazo_pagamento'] < gmdate('Y-m-d H:i:s')
 ): ?><small class="danger-text">Prazo vencido · revisar</small><?php endif;
 ?></td>
<td>
<a class="button small secondary" href="<?= e(
    url('admin/reserva', ['id' => $row['id']]),
) ?>">Abrir</a>
</td>
</tr><?php endforeach;
if (
    !$reservations
): ?><tr>
<td colspan="6" class="empty-cell">Nenhuma reserva encontrada.</td>
</tr><?php endif;
?></tbody>
</table>
</div>
