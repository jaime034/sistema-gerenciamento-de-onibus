<?php foreach ($_SESSION['flash'] ?? [] as $f): ?><div class="alert <?= e(
    $f['type'],
) ?>" role="status"><?=
icon('check') . e($f['message'])
?></div><?php endforeach;
unset($_SESSION['flash']); ?>
