<article class="trip-card card">
<a href="<?= e(
    url('viagem', ['id' => $t['id']]),
) ?>" class="trip-cover" tabindex="-1" aria-hidden="true"><?php if ($t['capa']): ?><img src="<?= e(
    url('imagem', ['arquivo' => $t['capa']]),
) ?>" alt="" loading="lazy"><?php else: ?><img src="<?= e(
    asset('destination.svg'),
) ?>" alt="" loading="lazy"><?php endif; ?><span class="cover-label"><?=
icon('pin') . e($t['destino'])
?></span><?php if (
    $t['demonstrativo']
): ?><span class="demo-tag">Viagem fictícia · demonstração</span><?php endif; ?></a>
<div class="trip-card-body">
<div class="spread">
<span class="eyebrow"><?= e(
    datebr($t['partida'], false),
) ?></span><?= badge($t['status']) ?></div>
<h3>
<a href="<?= e(
    url('viagem', ['id' => $t['id']]),
) ?>"><?= e($t['nome']) ?></a>
</h3>
<p class="icon-line"><?= icon('pin') ?>Saída: <?= e(
    $t['origem'],
) ?></p>
<p class="icon-line"><?=
icon('clock') . e(datebr($t['partida']))
?></p>
<div class="trip-card-bottom">
<div>
<small class="muted">Por pessoa</small>
<strong class="price"><?= money(
    $t['preco'],
) ?></strong>
</div>
<a class="button small" href="<?= e(
    url('viagem', ['id' => $t['id']]),
) ?>">Ver viagem <?= icon('arrow') ?></a>
</div>
<p class="remaining"><?=
icon('seat') . e($t['livres'])
?> <?= (int) $t['livres'] === 1 ? 'lugar disponível' : 'lugares disponíveis' ?></p>
</div>
</article>
