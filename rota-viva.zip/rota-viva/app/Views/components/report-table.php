<div class="table-scroll">
<table>
<thead>
<tr><?php foreach (
    $report['columns']
    as $label
): ?><th><?= e($label) ?></th><?php endforeach; ?></tr>
</thead>
<tbody><?php
foreach ($report['rows'] as $row): ?><tr><?php foreach (
    $report['columns']
    as $k => $label
): ?><td><?= e(
    App\Services\ReportService::format($k, $row[$k]),
) ?></td><?php endforeach; ?></tr><?php endforeach;
if (!$report['rows']): ?><tr>
<td colspan="<?= count(
    $report['columns'],
) ?>" class="empty-cell">Nenhum registro para este período.</td>
</tr><?php endif;
?></tbody>
</table>
</div>
