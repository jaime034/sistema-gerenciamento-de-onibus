<?php $api = $admin ? 'api/admin/' : 'api/';
$uid = 'seat-dialog';
?>
<section class="seat-workspace" data-seat-app data-trip="<?= e($trip['id']) ?>" data-api="<?= e(
    url($api . 'mapa', ['viagem_id' => $trip['id']]),
) ?>" data-hold="<?= e(url($api . 'hold')) ?>" data-admin="<?= $admin
    ? '1'
    : '0' ?>" data-inspect="<?= e(url('api/admin/poltrona')) ?>" data-block="<?= e(
    url('admin/poltrona/bloquear'),
) ?>" data-max="<?= $admin ? 160 : (int) setting('max_poltronas_reserva') ?>">
<div class="map-card card">
<div class="spread">
<div>
<h2>Mapa de poltronas</h2>
<p class="small muted">Frente do ônibus na parte superior</p>
</div>
<span class="badge badge-livre" data-map-connection>Atualizando…</span>
</div>
<div class="seat-legend">
<span>
<i class="legend-seat state-livre">✓</i>Disponível</span>
<span>
<i class="legend-seat state-selected">✓</i>Sua seleção</span>
<span>
<i class="legend-seat state-hold">◷</i>Temporária</span>
<span>
<i class="legend-seat state-pendente">!</i>Pagamento pendente</span>
<span>
<i class="legend-seat state-confirmada">✓</i>Confirmada</span>
<span>
<i class="legend-seat state-bloqueada">×</i>Bloqueada</span>
</div>
<div class="bus-map">
<div class="bus-front">
<span class="steering" role="img" aria-label="Motorista">⊕</span>
<span>FRENTE / MOTORISTA</span>
<span>PORTA →</span>
</div>
<div class="seat-grid" role="group" aria-label="Poltronas do ônibus" data-seat-grid>
<p>Carregando mapa…</p>
</div>
<div class="bus-rear">TRASEIRA DO ÔNIBUS</div>
</div>
<p class="small muted center">Janela: marca lateral • Use Tab e as setas para navegar.<br>Toque no lugar livre para selecionar ou desmarcar.</p>
<div class="alert warning" data-map-error hidden role="alert">
</div><?php if (
    $admin
): ?><p class="small muted">Toque em um lugar ocupado para ver passageiro e reserva. Em um lugar livre, use “Detalhes” para bloquear.</p>
<button class="button secondary full" type="button" data-seat-details>Detalhes da última poltrona</button><?php endif; ?></div>
<div class="booking-form-column">
<div class="card booking-summary">
<span class="eyebrow"><?= $admin
    ? 'REGISTRO MANUAL'
    : 'SUA RESERVA' ?></span>
<h2><?= e($trip['destino']) ?></h2>
<p class="small muted"><?= e(
    datebr($trip['partida']),
) ?><br><?= e(
    $trip['origem'],
) ?></p>
<div class="summary-row">
<span>Valor individual</span>
<strong><?= money(
    $trip['preco'],
) ?></strong>
</div>
<div class="summary-row">
<span>Poltronas</span>
<strong data-selected-label>Nenhuma selecionada</strong>
</div>
<div class="summary-row total">
<span>Total</span>
<strong data-total><?= money(
    0,
) ?></strong>
</div>
<p class="hold-timer" data-hold-timer aria-live="polite">Selecione seus lugares para continuar.</p>
</div>
<form method="post" action="<?= e(
    url($admin ? 'admin/reserva/criar' : 'reservar'),
) ?>" class="card stack reservation-form" data-reservation-form><?= csrf() ?><input type="hidden" name="viagem_id" value="<?= e(
    $trip['id'],
) ?>">
<h2><?= $admin
    ? 'Responsável pela reserva'
    : 'Quem vai viajar?' ?></h2>
<p class="small muted">O contato será usado para informações da reserva e do embarque.</p>
<label>Nome completo do responsável<input name="responsavel" autocomplete="name" required minlength="3" maxlength="150">
</label>
<div class="form-row">
<label>Telefone com DDD<input name="telefone" type="tel" autocomplete="tel" required minlength="10" maxlength="25" placeholder="(00) 00000-0000">
</label>
<label>E-mail <span class="optional">opcional</span>
<input name="email" type="email" autocomplete="email" maxlength="190">
</label>
</div>
<div class="passenger-fields" data-passengers>
<p class="muted">Os campos de passageiros aparecerão após a seleção.</p>
</div>
<?php if (
    $admin
): ?><div class="form-row">
<label>Desconto em R$<input name="desconto" inputmode="decimal" value="0,00" data-discount>
</label>
<label>Justificativa do desconto<input name="desconto_motivo" maxlength="250">
</label>
</div>
<label>Observações administrativas<textarea name="observacoes" maxlength="4000" rows="2">
</textarea>
</label><?php else: ?><label class="check align-start">
<input name="aceite" type="checkbox" value="1" required>
<span>Li as <a href="<?= e(
    url('privacidade'),
) ?>" target="_blank" rel="noopener">regras de reserva e cancelamento e o aviso de privacidade</a> e estou ciente do uso dos dados para esta reserva.</span>
</label><?php endif; ?><button class="button full" type="submit" data-book-submit disabled><?= $admin
    ? 'Criar reserva manual'
    : 'Reservar e ver instruções de pagamento' ?> <?= icon(
     'arrow',
 ) ?></button>
<p class="small muted">A confirmação do pagamento é feita pelo proprietário após conferir o recebimento.</p>
</form>
</div>
<?php if (
    $admin
): ?><dialog id="<?= $uid ?>" class="seat-dialog">
<div class="spread">
<h2 data-inspect-title>Poltrona</h2>
<button type="button" class="icon-button" data-close-dialog aria-label="Fechar">×</button>
</div>
<div data-inspect-body>
</div>
<form method="post" action="<?= e(
    url('admin/poltrona/bloquear'),
) ?>" class="stack" data-block-form><?= csrf() ?><input type="hidden" name="viagem_id" value="<?= e(
    $trip['id'],
) ?>">
<input type="hidden" name="poltrona_id">
<input type="hidden" name="acao">
<label data-block-reason>Motivo do bloqueio<input name="motivo" maxlength="250">
</label>
<button class="button" type="submit" data-block-button>Bloquear poltrona</button>
</form>
<h3>Histórico recente</h3>
<div data-seat-history>
</div>
</dialog><?php endif; ?></section>
