<?php $service = setting('nome_servico', 'Rota Viva');
$route = trim($_GET['r'] ?? '', '/');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta name="theme-color" content="#103d42">
<meta name="csrf-token" content="<?= e(
    App\Core\Security::csrf(),
) ?>">
<title><?= e($title ?? 'Viaje com tranquilidade') ?> · <?= e(
     $service,
 ) ?></title>
<link rel="icon" href="<?= e(
    asset('mark.svg'),
) ?>" type="image/svg+xml">
<link rel="stylesheet" href="<?= e(
    asset('app.css'),
) ?>">
<script src="<?= e(asset('app.js')) ?>" defer>
</script><?php if (
    isset($map)
): ?><script src="<?= e(asset('seats.js')) ?>" defer>
</script><?php endif; ?></head>
<body>
<a class="skip" href="#main">Pular para o conteúdo</a>
<header class="site-header">
<div class="wrap header-inner">
<a class="brand" href="<?= e(
    url(),
) ?>"><?php if (setting('logo')): ?><img src="<?= e(
    url('imagem', ['arquivo' => setting('logo')]),
) ?>" alt="" class="logo-img"><?php else: ?><span class="brand-mark"><?= icon(
    'bus',
) ?></span><?php endif; ?><span><?= e(
    $service,
) ?><small>VIAGENS & EXPERIÊNCIAS</small>
</span>
</a>
<button class="icon-button nav-toggle" type="button" data-nav aria-label="Abrir navegação" aria-expanded="false"><?= icon(
    'menu',
) ?></button>
<nav class="public-nav" aria-label="Navegação principal">
<a class="<?= $route === ''
    ? 'active'
    : '' ?>" href="<?= e(url()) ?>">Início</a>
<a class="<?= in_array($route, [
    'viagens',
    'viagem',
    'poltronas',
])
    ? 'active'
    : '' ?>" href="<?= e(
    url('viagens'),
) ?>">Próximas viagens</a>
<a class="button small secondary" href="<?= e(
    url('consulta'),
) ?>"><?= icon('ticket') ?> Minha reserva</a>
</nav>
</div>
</header>
<main id="main" class="wrap public-main"><?php
require BASE_PATH . '/app/Views/components/flash.php';
echo $content;
?></main>
<footer class="site-footer">
<div class="wrap footer-grid">
<div>
<a class="brand" href="<?= e(
    url(),
) ?>">
<span class="brand-mark"><?= icon('bus') ?></span>
<span><?= e($service) ?></span>
</a>
<p><?= e(
    setting('slogan'),
) ?></p>
</div>
<div>
<strong>Conte com a gente</strong>
<p><?= e(
    setting('telefone') ?: 'Consulte os canais de contato antes de reservar.',
) ?></p><?php if (setting('whatsapp')): ?><a href="<?= e(
    'https://wa.me/' . setting('whatsapp'),
) ?>" target="_blank" rel="noopener noreferrer">Conversar pelo WhatsApp ↗</a><?php endif; ?></div>
<div>
<strong>Informações</strong>
<a href="<?= e(
    url('privacidade'),
) ?>">Privacidade e cancelamento</a>
<a href="<?= e(
    url('consulta'),
) ?>">Consultar reserva</a>
<a href="<?= e(
    url('admin'),
) ?>">Área do proprietário</a>
</div>
</div>
<div class="wrap footer-base">
<span>© <?= date(
    'Y',
) ?> <?= e($service) ?>. <?= e(
    setting('proprietario'),
) ?></span>
<span>Reserve com atenção. Viaje com tranquilidade.</span>
</div>
</footer>
<div class="toast" role="status" aria-live="polite" hidden>
</div>
</body>
</html>
