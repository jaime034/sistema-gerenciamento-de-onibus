<?php $service = setting('nome_servico');
$route = trim($_GET['r'] ?? '', '/');
$user = App\Core\Security::user();
$nav = [
    ['admin', 'chart', 'Visão geral'],
    ['admin/viagens', 'calendar', 'Viagens'],
    ['admin/reservas', 'ticket', 'Reservas'],
    ['admin/passageiros', 'users', 'Passageiros'],
    ['admin/financeiro', 'wallet', 'Financeiro'],
    ['admin/relatorios', 'download', 'Relatórios'],
    ['admin/onibus', 'bus', 'Ônibus e poltronas'],
    ['admin/configuracoes', 'settings', 'Configurações'],
];
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="<?= e(
    App\Core\Security::csrf(),
) ?>">
<meta name="color-scheme" content="light dark">
<title><?= e($title) ?> · <?= e(
     $service,
 ) ?></title>
<link rel="icon" href="<?= e(
    asset('mark.svg'),
) ?>" type="image/svg+xml">
<link rel="stylesheet" href="<?= e(
    asset('app.css'),
) ?>">
<script src="<?= e(asset('app.js')) ?>" defer>
</script><?php
if (isset($map)): ?><script src="<?= e(asset('seats.js')) ?>" defer>
</script><?php endif;
if (isset($seats)): ?><script src="<?= e(asset('layout.js')) ?>" defer>
</script><?php endif;
?></head>
<body class="admin-body">
<a class="skip" href="#main">Pular para o conteúdo</a>
<aside class="sidebar" id="sidebar">
<a class="brand" href="<?= e(
    url('admin'),
) ?>">
<span class="brand-mark"><?= icon('bus') ?></span>
<span><?= e(
    $service,
) ?><small>PAINEL DO PROPRIETÁRIO</small>
</span>
</a>
<span class="nav-caption">SUA OPERAÇÃO</span>
<nav aria-label="Painel administrativo"><?php foreach (
    $nav
    as [$href, $ico, $label]
): ?><a class="<?= $route === $href || ($href !== 'admin' && str_starts_with($route, $href))
    ? 'active'
    : '' ?>" href="<?= e(url($href)) ?>"><?=
icon($ico) . e($label)
?></a><?php endforeach; ?></nav>
<div class="sidebar-bottom">
<a href="<?= e(
    url(),
) ?>" target="_blank" rel="noopener"><?= icon(
    'home',
) ?> Ver site público ↗</a>
<button class="plain" data-theme type="button"><?= icon(
     'sun',
 ) ?> Alterar tema</button>
<form action="<?= e(
     url('admin/logout'),
 ) ?>" method="post"><?= csrf() ?><button class="plain" type="submit"><?= icon(
    'logout',
) ?> Sair do painel</button>
</form>
</div>
</aside>
<div class="admin-shell">
<header class="admin-top">
<button class="icon-button admin-nav-toggle" data-sidebar aria-controls="sidebar" aria-expanded="false" aria-label="Abrir menu"><?= icon(
     'menu',
 ) ?></button>
<span class="breadcrumb">Painel <span>/</span> <?= e(
    $title,
) ?></span>
<div class="admin-profile">
<span class="avatar"><?= e(
    mb_strtoupper(mb_substr($user['nome'], 0, 1)),
) ?></span>
<span><?= e(
    $user['nome'],
) ?><small>Proprietário</small>
</span>
</div>
</header>
<main id="main" class="admin-main"><?php
require BASE_PATH . '/app/Views/components/flash.php';
echo $content;
?></main>
<footer class="admin-footer"><?= e($service) ?> · Gestão de viagens <span><?= date(
     'd/m/Y',
 ) ?></span>
</footer>
</div>
<div class="toast" role="status" aria-live="polite" hidden>
</div>
</body>
</html>
