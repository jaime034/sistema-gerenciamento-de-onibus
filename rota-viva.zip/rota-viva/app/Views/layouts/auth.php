<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e(
    $title,
) ?> · <?= e(setting('nome_servico')) ?></title>
<link rel="stylesheet" href="<?= e(
    asset('app.css'),
) ?>">
<script src="<?= e(
    asset('app.js'),
) ?>" defer>
</script>
</head>
<body class="auth-body">
<main class="auth-layout">
<section class="auth-art">
<a class="brand" href="<?= e(
    url(),
) ?>">
<span class="brand-mark"><?= icon('bus') ?></span><?= e(
    setting('nome_servico'),
) ?></a>
<div>
<span class="eyebrow">CADA VIAGEM, BEM CUIDADA.</span>
<h1>Mais controle.<br>Novos caminhos.</h1>
<p>Suas viagens, passageiros e recebimentos em um só lugar.</p>
<img src="<?= e(
    asset('journey.svg'),
) ?>" alt="Ilustração de uma estrada entre montanhas">
</div>
<small>Painel exclusivo do proprietário</small>
</section>
<section class="auth-form"><?php
require BASE_PATH . '/app/Views/components/flash.php';
echo $content;
?></section>
</main>
<div class="toast" role="status" hidden>
</div>
</body>
</html>
