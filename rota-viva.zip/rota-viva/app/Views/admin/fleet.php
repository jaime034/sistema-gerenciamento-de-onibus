<div class="section-heading">
<div>
<span class="eyebrow">SEU ÔNIBUS, DO SEU JEITO</span>
<h1>Cada poltrona no lugar certo.</h1>
<p class="muted">Configure a disposição real, numeração, janelas e espaços sem assento.</p>
</div>
<a class="button" href="<?= e(
    url('admin/onibus/editar'),
) ?>"><?= icon('plus') ?> Cadastrar ônibus</a>
</div>
<div class="admin-trip-grid"><?php foreach (
     $buses
     as $b
 ):
     $l = App\Core\Database::one(
         'SELECT l.*,(SELECT COUNT(*) FROM poltronas p WHERE p.layout_id=l.id) AS lugares FROM layouts_onibus l WHERE id=?',
         [$b['layout_atual']],
     ); ?><article class="card fleet-card">
<img src="<?= e(
    asset('bus.svg'),
) ?>" alt="Ônibus rodoviário">
<div class="spread">
<h2><?= e($b['identificacao']) ?></h2><?php if (
    $b['demonstrativo']
): ?><span class="badge">Demonstração</span><?php endif; ?></div>
<p class="muted"><?= e(
    $b['modelo'],
) ?></p>
<div class="trip-facts">
<div><?= icon('seat') ?><span>Poltronas<strong><?= e(
    $l['lugares'] ?? 0,
) ?></strong>
</span>
</div>
<div><?= icon('bus') ?><span>Layout atual<strong>Versão <?= e(
    $l['versao'] ?? 0,
) ?></strong>
</span>
</div>
</div>
<a class="button secondary full" href="<?= e(
    url('admin/onibus/editar', ['id' => $b['id']]),
) ?>">Editar mapa e identificação</a>
</article><?php
 endforeach; ?></div><?php if (!$buses): ?><div class="empty card"><?= icon(
    'bus',
) ?><h2>Seu primeiro ônibus começa aqui.</h2>
<p>Você decide quantas poltronas existem e como são numeradas.</p>
<a class="button" href="<?= e(
    url('admin/onibus/editar'),
) ?>">Configurar meu ônibus</a>
</div><?php endif; ?>
