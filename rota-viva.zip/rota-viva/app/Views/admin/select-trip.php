<div class="section-heading">
<div>
<span class="eyebrow">ATENDIMENTO DIRETO</span>
<h1>Escolha a viagem.</h1>
<p class="muted">Selecione uma saída para consultar o mapa ou registrar uma reserva manual.</p>
</div>
</div>
<div class="trip-grid"><?php foreach (
    $trips
    as $t
): ?><a class="card trip-select" href="<?= e(
    url('admin/mapa', ['viagem_id' => $t['id']]),
) ?>"><?= icon('bus') ?><h2><?= e($t['nome']) ?></h2>
<p><?= e(
    datebr($t['partida']),
) ?></p>
<p><?= $t[
    'livres'
] ?> lugares livres</p>
<span class="text-link">Abrir mapa →</span>
</a><?php endforeach; ?></div><?php if (
    !$trips
): ?><div class="empty card">
<h2>Nenhuma viagem com reservas abertas.</h2>
<a class="button" href="<?= e(
    url('admin/viagem'),
) ?>">Cadastrar viagem</a>
</div><?php endif; ?>
