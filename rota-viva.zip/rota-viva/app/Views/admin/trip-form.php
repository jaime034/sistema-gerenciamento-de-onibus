<div class="page-heading compact">
<a class="back-link" href="<?= e(
    url('admin/viagens'),
) ?>">← Viagens</a>
<span class="eyebrow">PLANEJAMENTO DO ROTEIRO</span>
<h1><?= e(
    $title,
) ?></h1>
<p class="muted">Prepare as informações que os passageiros precisam antes de reservar.</p>
</div><?php
if (
    $has
): ?><div class="alert warning">Há histórico de reservas. Nome, trajeto, horários, embarque e layout ficam preservados. Para um novo roteiro, duplique a viagem.</div><?php endif;
if (
    !$layouts
): ?><div class="alert warning">Cadastre um ônibus e configure suas poltronas antes de criar a viagem. <a href="<?= e(
    url('admin/onibus/editar'),
) ?>">Configurar ônibus →</a>
</div><?php endif;
?>
<form action="<?= e(
    url('admin/viagem/salvar'),
) ?>" method="post" enctype="multipart/form-data" class="stack"><?= csrf() ?><input type="hidden" name="id" value="<?= e(
    $trip['id'] ?? 0,
) ?>">
<section class="card form-section">
<h2>O próximo destino</h2>
<div class="form-grid">
<label class="span-2">Nome da viagem<input name="nome" maxlength="160" required value="<?= e(
    $trip['nome'] ?? '',
) ?>" placeholder="Ex.: Um fim de semana na serra" <?= $has
    ? 'readonly'
    : '' ?>>
</label>
<label>Origem<input name="origem" required maxlength="150" value="<?= e(
    $trip['origem'] ?? '',
) ?>" <?= $has
    ? 'readonly'
    : '' ?>>
</label>
<label>Destino<input name="destino" required maxlength="150" value="<?= e(
    $trip['destino'] ?? '',
) ?>" <?= $has
    ? 'readonly'
    : '' ?>>
</label>
<label>Data e horário da partida<input name="partida" type="datetime-local" required value="<?= e(
    inputdate($trip['partida'] ?? null),
) ?>" <?= $has
    ? 'readonly'
    : '' ?>>
</label>
<label>Previsão de retorno <span class="optional">opcional</span>
<input name="retorno" type="datetime-local" value="<?= e(
    inputdate($trip['retorno'] ?? null),
) ?>" <?= $has
    ? 'readonly'
    : '' ?>>
</label>
<label class="span-2">Pontos e orientações de embarque<textarea name="embarque" rows="3" required maxlength="4000" <?= $has
    ? 'readonly'
    : '' ?>><?= e(
    $trip['embarque'] ?? '',
) ?></textarea>
</label>
<label>Valor por passageiro (R$)<input name="preco" required inputmode="decimal" value="<?= e(
    isset($trip['preco']) ? number_format((float) $trip['preco'], 2, ',', '') : '',
) ?>" placeholder="0,00">
</label>
<label>Situação<select name="status"><?php foreach (
    ['rascunho', 'aberta', 'encerrada', 'em_andamento', 'concluida', 'cancelada']
    as $s
): ?><option value="<?= $s ?>"<?= selected($trip['status'] ?? 'rascunho', $s) ?>><?= statuslabel(
    $s,
) ?></option><?php endforeach; ?></select>
</label>
<label class="span-2">Ônibus e versão do mapa<select name="layout_id" required><?php foreach (
    $layouts
    as $l
):
    if ($has && (int) $l['id'] !== (int) $trip['layout_id']) {
        continue;
    } ?><option value="<?= $l['id'] ?>"<?= selected($trip['layout_id'] ?? '', $l['id']) ?>><?= e(
    $l['identificacao'],
) ?> · versão <?= $l['versao'] ?> · <?= $l['lugares'] ?> poltronas ativas</option><?php
endforeach; ?></select>
<small>O mapa será copiado para o inventário da viagem. Versões antigas permanecem disponíveis.</small>
</label>
</div>
</section>
<section class="card form-section">
<h2>Detalhes que fazem a diferença</h2>
<div class="stack">
<label>Descrição do passeio<textarea name="descricao" maxlength="12000" rows="6"><?= e(
    $trip['descricao'] ?? '',
) ?></textarea>
</label>
<label>Orientações aos passageiros<textarea name="orientacoes" maxlength="8000" rows="4"><?= e(
    $trip['orientacoes'] ?? '',
) ?></textarea>
</label>
<label>Capa opcional (JPG, PNG ou WebP, até 3 MB)<input name="capa" type="file" accept="image/jpeg,image/png,image/webp">
</label>
</div>
</section>
<div class="alert warning">Ao cancelar a viagem, as reservas ativas também serão canceladas e seus lugares liberados. Recebimentos e estornos permanecem no histórico financeiro.</div>
<div class="button-row">
<button class="button" type="submit" <?= !$layouts
    ? 'disabled'
    : '' ?>>Salvar viagem <?= icon('check') ?></button>
<a class="button secondary" href="<?= e(
    url('admin/viagens'),
) ?>">Voltar</a>
</div>
</form>
