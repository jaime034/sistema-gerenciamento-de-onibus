<div class="section-heading">
<div>
<span class="eyebrow">CADA DETALHE NO LUGAR</span>
<h1>Sua operação, em movimento.</h1>
<p class="muted">Acompanhe as próximas saídas e o que precisa da sua atenção.</p>
</div>
<a class="button" href="<?= e(
    url('admin/nova-reserva'),
) ?>"><?= icon(
    'plus',
) ?> Nova reserva</a>
</div>
<form class="period-filter" method="get">
<input type="hidden" name="r" value="admin">
<span>Recebimentos no período</span>
<label class="sr-only" for="inicio">Data inicial</label>
<input id="inicio" type="date" name="inicio" value="<?= e(
     $_GET['inicio'] ?? date('Y-m-01'),
 ) ?>">
<span>até</span>
<label class="sr-only" for="fim">Data final</label>
<input id="fim" type="date" name="fim" value="<?= e(
    $_GET['fim'] ?? date('Y-m-t'),
) ?>">
<button class="button small secondary">Aplicar</button>
</form>
<div class="stat-grid">
<article class="stat-card accent">
<div class="spread">
<span>Recebido líquido no período</span><?= icon(
    'wallet',
) ?></div>
<strong><?= money(
    $stats['recebido'],
) ?></strong>
<small>Recebimentos menos estornos</small>
</article>
<article class="stat-card">
<div class="spread">
<span>Total a receber</span><?= icon(
    'chart',
) ?></div>
<strong><?= money(
    $stats['a_receber'],
) ?></strong>
<small>Saldo das reservas ativas</small>
</article>
<article class="stat-card">
<div class="spread">
<span>Reservas aguardando pagamento</span><?= icon(
    'ticket',
) ?></div>
<strong><?= (int) $stats[
    'pendentes'
] ?></strong>
<small>Pendentes e parciais</small>
</article>
<article class="stat-card">
<div class="spread">
<span>Viagens abertas</span><?= icon(
    'bus',
) ?></div>
<strong><?= (int) $stats['abertas'] ?></strong>
<small><?= (int) $stats[
    'passageiros'
] ?> passagens confirmadas no histórico</small>
</article>
</div>
<div class="dashboard-grid">
<section class="card dashboard-trips">
<div class="section-heading">
<div>
<span class="eyebrow">HORA DE PLANEJAR</span>
<h2>Próximas viagens</h2>
</div>
<a class="text-link" href="<?= e(
    url('admin/viagens'),
) ?>">Ver todas →</a>
</div><?php
foreach ($trips as $t):
    $percent = (int) $t['capacidade']
        ? round((100 * $t['ocupadas']) / $t['capacidade'])
        : 0; ?><article class="upcoming-row">
<div class="date-square">
<strong><?= e(
    (new DateTimeImmutable($t['partida'], new DateTimeZone('UTC')))
        ->setTimezone(new DateTimeZone(config('timezone')))
        ->format('d'),
) ?></strong>
<span><?= e(
    (new DateTimeImmutable($t['partida'], new DateTimeZone('UTC')))
        ->setTimezone(new DateTimeZone(config('timezone')))
        ->format('m/Y'),
) ?></span>
</div>
<div>
<a href="<?= e(
    url('admin/mapa', ['viagem_id' => $t['id']]),
) ?>">
<strong><?= e($t['nome']) ?></strong>
</a>
<p class="small muted"><?= e(
    $t['origem'],
) ?> → <?= e(
     $t['destino'],
 ) ?></p>
<progress value="<?= $percent ?>" max="100" aria-label="Ocupação de <?= e(
    $t['nome'],
) ?>: <?= $percent ?>%">
</progress>
<span class="small muted"><?= $t[
    'ocupadas'
] ?> ocupadas · <?= $t[
     'livres'
 ] ?> livres · <?= $percent ?>% de ocupação</span>
</div>
<a class="icon-button" href="<?= e(
    url('admin/mapa', ['viagem_id' => $t['id']]),
) ?>" aria-label="Abrir mapa de <?= e($t['nome']) ?>"><?= icon('arrow') ?></a>
</article><?php
endforeach;
if (
    !$trips
): ?><div class="empty">
<h3>Seu próximo roteiro começa aqui.</h3>
<p>Configure o ônibus e cadastre a primeira viagem.</p>
<a class="button secondary" href="<?= e(
    url('admin/viagem'),
) ?>">Criar viagem</a>
</div><?php endif;
?></section>
<section class="card chart-card">
<span class="eyebrow">ENTRADAS E SAÍDAS</span>
<h2>Recebimentos por dia</h2><?php if (
    $revenue
):

    $max = max(1, ...array_map(fn($v) => abs((float) $v['valor']), $revenue));
    $n = count($revenue);
    ?><svg viewBox="0 0 460 230" class="revenue-chart" role="img" aria-label="Gráfico de valores líquidos por dia no período">
<path d="M20 170H450" class="chart-axis"/><?php foreach (
    $revenue
    as $i => $row
):

    $bar = 390 / $n;
    $h = (120 * abs((float) $row['valor'])) / $max;
    $x = 35 + $i * $bar;
    ?><rect x="<?= $x ?>" y="<?= (float) $row['valor'] >= 0 ? 170 - $h : 170 ?>" width="<?= max(
    2,
    $bar - 8,
) ?>" height="<?= $h ?>" rx="4" class="<?= (float) $row['valor'] >= 0
    ? 'chart-positive'
    : 'chart-negative' ?>">
<title><?= e(datebr($row['dia'] . ' 00:00:00', false)) ?>: <?= money(
    $row['valor'],
) ?></title>
</rect><?php if (
    $i % max(1, (int) ceil($n / 6)) ===
    0
): ?><text x="<?= $x ?>" y="214"><?= e(
    substr($row['dia'], 8, 2) . '/' . substr($row['dia'], 5, 2),
) ?></text><?php endif;
endforeach; ?></svg>
<details>
<summary>Ver valores do gráfico</summary><?php foreach (
    $revenue
    as $row
): ?><p><?= e(datebr($row['dia'] . ' 12:00:00', false)) ?>: <?= money(
    $row['valor'],
) ?></p><?php endforeach; ?></details><?php
else:
     ?><div class="empty">
<span class="empty-icon"><?= icon(
    'chart',
) ?></span>
<p>Os lançamentos do período aparecerão aqui.</p>
</div><?php
endif; ?><a class="text-link" href="<?= e(
    url('admin/financeiro'),
) ?>">Consultar financeiro →</a>
</section>
</div>
<section class="card section">
<div class="section-heading">
<div>
<span class="eyebrow">PRECISAM DE ATENÇÃO</span>
<h2>Últimas reservas pendentes</h2>
</div>
<a class="text-link" href="<?= e(
    url('admin/reservas', ['status' => 'pendente']),
) ?>">Ver pendências →</a>
</div><?php
$reservations = array_slice($pending, 0, 6);
require BASE_PATH . '/app/Views/components/reservations-table.php';
?></section>
