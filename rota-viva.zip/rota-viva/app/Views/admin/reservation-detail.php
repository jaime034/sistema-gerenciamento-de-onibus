<?php $active = in_array($r['status'], ['pendente', 'parcial', 'confirmada'], true);
$balance = max(0, (float) $r['total'] - (float) $r['recebido']);
?>
<a class="back-link" href="<?= e(
    url('admin/reservas'),
) ?>">← Reservas</a>
<div class="section-heading">
<div>
<span class="eyebrow"><?= e(
    $r['codigo'],
) ?> · ORIGEM <?= e(mb_strtoupper($r['origem'])) ?></span>
<h1><?= e(
    $r['responsavel'],
) ?></h1>
<p><?= badge($r['status']) ?> <span class="muted"><?= e($r['viagem']) ?> · <?= e(
     datebr($r['partida']),
 ) ?></span>
</p>
</div>
<div class="button-row">
<a class="button secondary" href="<?= e(
    url('admin/mapa', ['viagem_id' => $r['viagem_id']]),
) ?>"><?= icon('seat') ?> Mapa da viagem</a><?php if (
     $r['status'] === 'confirmada'
 ): ?><a class="button" href="<?= e(url('admin/comprovante', ['id' => $r['id']])) ?>"><?= icon(
    'download',
) ?> Comprovante PDF</a><?php endif; ?></div>
</div>
<?php if ($private):
    $access =
        url('consulta') .
        '#' .
        http_build_query([
            'codigo' => $r['codigo'],
            'token' => $private,
        ]); ?><div class="alert access-alert">
<div>
<strong>Acesso privado do cliente</strong>
<p>Envie apenas ao responsável pela reserva, após verificar sua identidade.</p>
<input class="full" value="<?= e(
    $access,
) ?>" readonly aria-label="Link de consulta privada">
</div>
<div class="button-row">
<button type="button" class="button small" data-copy="<?= e(
    $access,
) ?>">Copiar link</button><?php if (
    setting('whatsapp') &&
    $r['telefone']
): ?><a class="button small secondary" href="<?= e(
    'https://wa.me/' .
        (strlen($r['telefone']) <= 11 ? '55' : '') .
        $r['telefone'] .
        '?text=' .
        rawurlencode(
            'Olá, ' .
                $r['responsavel'] .
                '! Sua reserva ' .
                $r['codigo'] .
                ' está ' .
                mb_strtolower(statuslabel($r['status'])) .
                '. Viagem: ' .
                $r['viagem'] .
                '. Poltronas: ' .
                implode(', ', array_column($passengers, 'numero_snapshot')) .
                '. Consulte com seu acesso privado: ' .
                $access,
        ),
) ?>" target="_blank" rel="noopener noreferrer">Mensagem pelo WhatsApp ↗</a><?php endif; ?></div>
</div><?php
endif; ?>
<div class="stat-grid three">
<article class="stat-card">
<span>Valor da reserva</span>
<strong><?= money(
    $r['total'],
) ?></strong>
<small>Subtotal <?= money($r['subtotal']) ?> · desconto <?= money(
     $r['desconto'],
 ) ?></small>
</article>
<article class="stat-card accent">
<span>Recebido líquido</span>
<strong><?= money(
    $r['recebido'],
) ?></strong>
<small>Recebimentos menos estornos</small>
</article>
<article class="stat-card">
<span><?= $active
    ? 'Saldo pendente'
    : 'Saldo histórico não exigível' ?></span>
<strong><?= money(
    $balance,
) ?></strong>
<small>Prazo: <?= e(datebr($r['prazo_pagamento'])) ?></small>
</article>
</div><?php if (
    !$active &&
    (float) $r['recebido'] > 0
): ?><p class="alert warning">Esta reserva não está ativa e possui valores recebidos. Verifique as condições de cancelamento e registre o estorno quando efetivamente realizado.</p><?php endif; ?>
<div class="detail-grid">
<div class="stack">
<section class="card prose">
<h2>Passageiros e poltronas</h2><?php foreach (
    $passengers
    as $p
): ?><article class="passenger-detail">
<div class="passenger-ticket">
<span class="seat-number"><?= e(
    $p['numero_snapshot'],
) ?></span>
<div>
<strong><?= e($p['nome']) ?></strong>
<small class="muted"><?= e(
    $p['embarcou_em'] ? 'Embarcou em ' . datebr($p['embarcou_em']) : 'Embarque não registrado',
) ?></small>
</div>
</div><?php if (
    $active
): ?><details>
<summary>Transferir para outro lugar</summary>
<form action="<?= e(
    url('admin/reserva/transferir'),
) ?>" method="post" class="inline-form"><?= csrf() ?><input name="id" value="<?= $r[
    'id'
] ?>" type="hidden">
<input name="passageiro_registro" value="<?= $p[
    'id'
] ?>" type="hidden">
<label>Nova poltrona<select name="poltrona_destino" required>
<option value="">Selecione</option><?php foreach (
    $free
    as $s
): ?><option value="<?= $s['id'] ?>"><?= e(
    $s['numero'],
) ?></option><?php endforeach; ?></select>
</label>
<button class="button small secondary">Transferir</button>
</form>
</details><?php endif; ?></article><?php endforeach; ?><p class="small muted">Origem: <?= e(
    $r['cidade_origem'],
) ?> · Destino: <?= e($r['destino']) ?><br>Embarque: <?= nl2br(e($r['embarque'])) ?></p>
</section>
<section class="card form-section">
<h2>Contato e observações</h2>
<form method="post" action="<?= e(
    url('admin/reserva/editar'),
) ?>" class="stack"><?= csrf() ?><input name="id" type="hidden" value="<?= $r[
    'id'
] ?>">
<label>Responsável<input name="responsavel" required maxlength="150" value="<?= e(
    $r['responsavel'],
) ?>">
</label>
<div class="form-row">
<label>Telefone<input name="telefone" type="tel" required maxlength="25" value="<?= e(
    $r['telefone'],
) ?>">
</label>
<label>E-mail<input name="email" type="email" maxlength="190" value="<?= e(
    $r['email'],
) ?>">
</label>
</div>
<label>Observações administrativas<textarea name="observacoes" rows="3" maxlength="4000"><?= e(
    $r['observacoes'],
) ?></textarea>
</label><?php if ((float) $r['desconto'] > 0): ?><p>Justificativa do desconto: <?= e(
    $r['desconto_motivo'],
) ?></p><?php endif; ?><button class="button secondary" type="submit">Salvar dados</button>
</form>
</section>
<section class="card prose">
<div class="section-heading">
<h2>Histórico financeiro</h2>
<span class="badge"><?= count(
    $payments,
) ?> lançamentos</span>
</div><?php
 foreach ($payments as $p): ?><article class="payment-entry">
<div class="spread">
<strong><?= e(
    statuslabel($p['tipo']),
) ?> · <?= money($p['valor']) ?></strong>
<span><?= e(
    $p['metodo'],
) ?></span>
</div>
<p class="small muted"><?= e(datebr($p['pago_em'])) ?> · Registrado por <?= e(
     $p['usuario'],
 ) ?></p>
<p><?= e($p['observacoes']) ?></p>
</article><?php endforeach;
 if (
     !$payments
 ): ?><p class="muted">Nenhum recebimento registrado. Registre somente valores conferidos.</p><?php endif;
 ?></section>
<section class="card prose">
<h2>Histórico da reserva</h2>
<ol class="timeline"><?php foreach (
    $history
    as $h
): ?><li>
<strong><?= e(ucfirst(str_replace('_', ' ', $h['evento']))) ?></strong>
<small><?= e(
    datebr($h['created_at']),
) ?> · <?= e($h['usuario'] ?? 'Sistema / cliente') ?></small><?php if (
    $h['detalhes'] &&
    $h['detalhes'] !== '[]'
): ?><details>
<summary>Detalhes</summary>
<pre class="event-json"><?= e(
    json_encode(json_decode($h['detalhes']), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
) ?></pre>
</details><?php endif; ?></li><?php endforeach; ?></ol>
</section>
</div>
<aside class="stack">
<section class="card form-section">
<span class="eyebrow">CONFERÊNCIA MANUAL</span>
<h2>Registrar lançamento</h2>
<p class="small muted">Confirme o recebimento antes de registrar. Ao atingir o valor total, a reserva é confirmada automaticamente pelo sistema.</p>
<form method="post" action="<?= e(
    url('admin/pagamento'),
) ?>" class="stack" data-confirm="Confirme que o valor foi conferido e esta operação financeira foi realmente realizada."><?= csrf() ?><input name="id" type="hidden" value="<?= $r[
    'id'
] ?>">
<input name="idempotencia" type="hidden" value="<?= bin2hex(
    random_bytes(32),
) ?>">
<label>Operação<select name="tipo"><?php
if (
    $active &&
    $balance > 0
): ?><option value="recebimento">Recebimento confirmado manualmente</option><?php endif;
if ((float) $r['recebido'] > 0): ?><option value="estorno">Estorno realizado</option><?php endif;
?></select>
</label>
<label>Valor (R$)<input name="valor" required inputmode="decimal" placeholder="0,00" value="<?= e(
    $active && $balance > 0 ? number_format($balance, 2, ',', '') : '',
) ?>">
</label>
<label>Forma<select name="metodo"><?php foreach (
    explode(',', setting('metodos_pagamento'))
    as $m
): ?><option value="<?= e(trim($m)) ?>"><?= e(
    trim($m),
) ?></option><?php endforeach; ?></select>
</label>
<label>Data e horário<input name="pago_em" type="datetime-local" required value="<?= date(
    'Y-m-d\TH:i',
) ?>">
</label>
<label>Observações / motivo do estorno<textarea name="observacoes" rows="3" maxlength="500">
</textarea>
</label>
<button class="button full" <?= (!$active ||
    (float) $r['total'] <= (float) $r['recebido']) &&
(float) $r['recebido'] <= 0
    ? 'disabled'
    : '' ?>>Registrar lançamento</button>
</form>
</section>
<section class="card prose">
<h2>Acesso do cliente</h2>
<p class="small muted">A chave anterior não pode ser recuperada do banco. Gere uma nova apenas após verificar a identidade do responsável.</p>
<form method="post" action="<?= e(
    url('admin/reserva/chave'),
) ?>" data-confirm="Gerar uma nova chave privada? A chave anterior deixará de funcionar."><?= csrf() ?><input name="id" value="<?= $r[
    'id'
] ?>" type="hidden">
<button class="button secondary full">Gerar nova chave de consulta</button>
</form>
</section><?php if (
    $active
): ?><section class="card prose danger-zone">
<h2>Cancelar reserva</h2>
<p class="small muted">Libera todas as poltronas. Os lançamentos financeiros são preservados.</p>
<form method="post" action="<?= e(
    url('admin/reserva/cancelar'),
) ?>" class="stack" data-confirm="Cancelar esta reserva e liberar todas as poltronas?"><?= csrf() ?><input name="id" value="<?= $r[
    'id'
] ?>" type="hidden">
<label>Motivo<textarea name="motivo" required maxlength="500" rows="2">
</textarea>
</label>
<button class="button danger full">Cancelar reserva</button>
</form>
</section><?php endif; ?></aside>
</div>
