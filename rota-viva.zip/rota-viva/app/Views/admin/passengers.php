<div class="section-heading">
<div>
<span class="eyebrow">O MELHOR DA VIAGEM SÃO AS PESSOAS</span>
<h1>Passageiros e embarque.</h1>
<p class="muted">Encontre contatos, consulte o histórico e marque a presença.</p>
</div>
<a class="button secondary" href="<?= e(
    url('admin/relatorios', ['tipo' => 'passageiros', 'viagem_id' => $_GET['viagem_id'] ?? '']),
) ?>">Exportar lista <?= icon(
    'download',
) ?></a>
</div>
<form class="filter-bar card" method="get">
<input name="r" type="hidden" value="admin/passageiros">
<label>Pesquisar<input name="q" value="<?= e(
    $_GET['q'] ?? '',
) ?>" placeholder="Nome, telefone ou código">
</label>
<label>Viagem<select name="viagem_id">
<option value="">Todas</option><?php foreach (
    $trips
    as $t
): ?><option value="<?= $t['id'] ?>"<?= selected($_GET['viagem_id'] ?? '', $t['id']) ?>><?= e(
    $t['nome'],
) ?> · <?= e(
     datebr($t['partida'], false),
 ) ?></option><?php endforeach; ?></select>
</label>
<button class="button secondary">Filtrar</button>
</form>
<p class="small muted">Até 200 vínculos recentes entre passageiros e viagens. Cada passageiro é registrado por reserva; nomes iguais não são mesclados automaticamente.</p>
<section class="card table-card">
<div class="table-scroll">
<table>
<thead>
<tr>
<th>Passageiro</th>
<th>Viagem / reserva</th>
<th>Poltrona</th>
<th>Situação</th>
<th>Embarque</th>
</tr>
</thead>
<tbody><?php
foreach ($rows as $p): ?><tr>
<td>
<strong><?= e($p['nome']) ?></strong>
<small><?= e(
    $p['telefone'],
) ?></small>
<details>
<summary>Editar dados</summary>
<form action="<?= e(
    url('admin/passageiro/salvar'),
) ?>" method="post" class="stack table-edit"><?= csrf() ?><input type="hidden" name="passageiro_id" value="<?= $p[
    'id'
] ?>">
<label>Nome<input name="nome" required maxlength="150" value="<?= e(
    $p['nome'],
) ?>">
</label>
<label>Telefone<input name="telefone" maxlength="25" type="tel" value="<?= e(
    $p['telefone'],
) ?>">
</label>
<label>Observações<textarea name="observacoes" maxlength="4000" rows="2"><?= e(
    $p['observacoes'],
) ?></textarea>
</label>
<button class="button small">Salvar</button>
</form>
</details>
</td>
<td><?= e(
    $p['destino'],
) ?><small><?= e(datebr($p['partida'])) ?></small>
<a class="small text-link" href="<?= e(
    url('admin/reserva', ['id' => $p['reserva_id']]),
) ?>"><?= e($p['codigo']) ?></a>
</td>
<td>
<span class="seat-number small-seat"><?= e(
    $p['numero_snapshot'],
) ?></span>
</td>
<td><?= badge($p['status']) ?></td>
<td><?php if (
    $p['status'] === 'confirmada'
): ?><form method="post" action="<?= e(
    url('admin/embarque'),
) ?>"><?= csrf() ?><input type="hidden" name="registro" value="<?= $p[
    'registro'
] ?>">
<button class="button small <?= $p['embarcou_em'] ? '' : 'secondary' ?>" type="submit"><?= $p[
    'embarcou_em'
]
    ? '✓ Embarcou'
    : 'Marcar presença' ?></button><?php if ($p['embarcou_em']): ?><small><?= e(
    datebr($p['embarcou_em']),
) ?></small><?php endif; ?></form><?php else: ?><span class="small muted">Aguarda confirmação</span><?php endif; ?></td>
</tr><?php endforeach;
if (
    !$rows
): ?><tr>
<td colspan="5" class="empty-cell">Nenhum passageiro para os filtros selecionados.</td>
</tr><?php endif;
?></tbody>
</table>
</div>
</section>
