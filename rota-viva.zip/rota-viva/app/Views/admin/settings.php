<div class="page-heading compact">
<span class="eyebrow">SUA IDENTIDADE E SUAS REGRAS</span>
<h1>Do seu jeito.</h1>
<p class="muted">Personalize o serviço, os pagamentos e a comunicação com os passageiros.</p>
</div>
<form method="post" action="<?= e(
    url('admin/configuracoes/salvar'),
) ?>" enctype="multipart/form-data" class="stack"><?= csrf() ?><section class="card form-section">
<h2>Identidade e contato</h2>
<div class="form-grid"><?php foreach (
    [
        'nome_servico' => 'Nome do serviço',
        'slogan' => 'Frase de apresentação',
        'proprietario' => 'Responsável / identificação do proprietário',
        'telefone' => 'Telefone para exibição',
        'whatsapp' => 'WhatsApp (país + DDD + número, somente dígitos)',
        'email_contato' => 'E-mail de contato',
    ]
    as $k => $label
): ?><label><?= e($label) ?><input name="<?= $k ?>" value="<?= e($settings[$k]) ?>" <?= $k ===
'nome_servico'
    ? 'required'
    : '' ?> maxlength="<?= $k === 'nome_servico'
     ? 120
     : ($k === 'slogan' || $k === 'proprietario'
         ? 200
         : ($k === 'email_contato'
             ? 190
             : 30)) ?>" <?= $k === 'email_contato'
    ? 'type="email"'
    : '' ?>>
</label><?php endforeach; ?><label class="span-2">Logotipo (JPG, PNG ou WebP, até 3 MB)<input name="logo" type="file" accept="image/jpeg,image/png,image/webp">
</label>
</div>
</section>
<section class="card form-section">
<h2>Pix e controle dos prazos</h2>
<div class="form-grid">
<label>Chave Pix<input name="pix_chave" maxlength="190" value="<?= e(
    $settings['pix_chave'],
) ?>">
</label>
<label>Nome do beneficiário<input name="pix_beneficiario" maxlength="150" value="<?= e(
    $settings['pix_beneficiario'],
) ?>">
</label>
<label class="span-2">Instruções de pagamento<textarea name="pix_instrucoes" rows="3" maxlength="3000"><?= e(
    $settings['pix_instrucoes'],
) ?></textarea>
</label>
<label>Seleção temporária (1 a 30 minutos)<input name="hold_minutos" type="number" min="1" max="30" required value="<?= e(
    $settings['hold_minutos'],
) ?>">
</label>
<label>Prazo de pagamento (1 a 168 horas)<input name="pagamento_horas" type="number" min="1" max="168" required value="<?= e(
    $settings['pagamento_horas'],
) ?>">
</label>
<label>Limite público por reserva (1 a 40)<input name="max_poltronas_reserva" type="number" min="1" max="40" required value="<?= e(
    $settings['max_poltronas_reserva'],
) ?>">
</label>
<label>Métodos manuais, separados por vírgula<input name="metodos_pagamento" required maxlength="400" value="<?= e(
    $settings['metodos_pagamento'],
) ?>">
</label>
</div>
<p class="small muted">Os prazos nunca ultrapassam o horário da partida para novas reservas. Pagamentos parciais ou com histórico financeiro permanecem para análise manual.</p>
</section>
<section class="card form-section">
<h2>Regras e transparência</h2>
<div class="stack">
<label>Regras de reserva e cancelamento<textarea name="regras_cancelamento" rows="5" required maxlength="8000"><?= e(
    $settings['regras_cancelamento'],
) ?></textarea>
</label>
<label>Instruções de embarque<textarea name="instrucoes_embarque" rows="3" maxlength="3000"><?= e(
    $settings['instrucoes_embarque'],
) ?></textarea>
</label>
<label>Aviso de privacidade<textarea name="privacidade" rows="6" required maxlength="8000"><?= e(
    $settings['privacidade'],
) ?></textarea>
</label>
</div>
</section>
<button class="button" type="submit">Salvar configurações <?= icon(
    'check',
) ?></button>
</form>
<section class="card form-section section">
<h2>Alterar senha do proprietário</h2>
<p class="muted">Após alterar, todas as sessões administrativas são encerradas.</p>
<form action="<?= e(
    url('admin/senha'),
) ?>" method="post" class="stack narrow"><?= csrf() ?><label>Senha atual<input name="senha_atual" type="password" required autocomplete="current-password">
</label>
<label>Nova senha (12 a 72 caracteres)<input name="nova_senha" type="password" required minlength="12" maxlength="72" autocomplete="new-password">
</label>
<label>Confirmar nova senha<input name="confirmacao" type="password" required minlength="12" maxlength="72" autocomplete="new-password">
</label>
<button class="button secondary">Alterar senha</button>
</form>
</section>
