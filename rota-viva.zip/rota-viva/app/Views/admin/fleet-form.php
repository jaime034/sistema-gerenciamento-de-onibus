<div class="page-heading compact">
<a class="back-link" href="<?= e(
    url('admin/onibus'),
) ?>">← Ônibus</a>
<span class="eyebrow">EDITOR DA DISPOSIÇÃO FÍSICA</span>
<h1><?= e(
    $title,
) ?></h1>
<p class="muted">Duas poltronas de cada lado. Corredor central. A numeração é sua.</p>
</div>
<form action="<?= e(
    url('admin/onibus/salvar'),
) ?>" method="post" class="stack" data-layout-editor><?= csrf() ?><input type="hidden" name="id" value="<?= e(
    $bus['id'] ?? 0,
) ?>">
<section class="card form-section">
<h2>Identificação do ônibus</h2>
<div class="form-grid">
<label>Nome ou identificação<input name="identificacao" required maxlength="120" value="<?= e(
    $bus['identificacao'] ?? '',
) ?>" placeholder="Ex.: Meu ônibus de turismo">
</label>
<label>Modelo <span class="optional">opcional</span>
<input name="modelo" maxlength="150" value="<?= e(
    $bus['modelo'] ?? '',
) ?>">
</label>
<label class="span-2">Características<textarea name="caracteristicas" maxlength="4000" rows="3"><?= e(
    $bus['caracteristicas'] ?? '',
) ?></textarea>
</label>
</div>
</section>
<section class="card form-section">
<div class="section-heading">
<div>
<h2>Monte seu mapa</h2>
<p class="muted">Deixe a numeração vazia para representar uma posição inexistente.</p>
</div>
<strong data-layout-count>0 poltronas</strong>
</div>
<div class="layout-tools">
<label>Quantidade de lugares para gerar<input type="number" min="1" max="160" value="<?= count(
    $seats,
) ?:
    40 ?>" data-generate-count>
</label>
<button class="button secondary" type="button" data-generate>Gerar distribuição 2 + 2</button>
<label>Número de fileiras<input name="fileiras" type="number" min="1" max="40" required value="<?= e(
    $layout['fileiras'] ?? 10,
) ?>" data-row-count>
</label>
<button class="button secondary" type="button" data-rows>Aplicar fileiras</button>
</div>
<p class="small muted">“Gerar” substitui os números do editor. “Aplicar fileiras” preserva os lugares que couberem. Janela e disponibilidade podem ser alteradas individualmente.</p>
<div class="layout-scroll">
<div class="layout-header">
<span>ESQUERDA · JANELA</span>
<span>CORREDOR</span>
<span>DIREITA · JANELA</span>
</div>
<div data-layout-grid class="layout-grid"><?php
$lookup = [];
foreach ($seats as $s) {
    $lookup[$s['fileira']][$s['coluna']] = $s;
}
foreach (range(1, (int) ($layout['fileiras'] ?? 10)) as $row):
    foreach ([1, 2, 3, 4, 5] as $col):
        if ($col === 3): ?><span class="layout-aisle"><?= $row ?></span><?php else:$s =
                $lookup[$row][$col] ??
                null; ?><div class="layout-cell" data-row="<?= $row ?>" data-col="<?= $col ?>">
<label>F<?= $row ?> · P<?= $col ?><input name="layout[<?= $row ?>][<?= $col ?>][numero]" value="<?= e(
    $s['numero'] ?? '',
) ?>" maxlength="12" aria-label="Número da poltrona fileira <?= $row ?> posição <?= $col ?>">
</label>
<label class="check">
<input type="checkbox" name="layout[<?= $row ?>][<?= $col ?>][janela]" <?= $s
    ? ($s['janela']
        ? 'checked'
        : '')
    : (in_array($col, [1, 5])
        ? 'checked'
        : '') ?>>Janela</label>
<label class="check">
<input type="checkbox" name="layout[<?= $row ?>][<?= $col ?>][ativa]" <?= !$s ||
$s['ativa']
    ? 'checked'
    : '' ?>>Ativa</label>
</div><?php endif;
    endforeach;
endforeach;
?></div>
</div>
</section>
<div class="alert">Cada salvamento cria uma versão imutável do mapa. Viagens já cadastradas continuam com a configuração original, inclusive quando ainda são rascunhos.</div>
<div class="button-row">
<button class="button" type="submit">Salvar nova versão <?= icon(
    'check',
) ?></button>
<a class="button secondary" href="<?= e(
    url('admin/onibus'),
) ?>">Cancelar</a>
</div>
</form>
