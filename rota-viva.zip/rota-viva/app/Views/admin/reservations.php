<div class="section-heading">
<div>
<span class="eyebrow">CADA PASSAGEIRO, UMA RESERVA BEM CUIDADA</span>
<h1>Reservas.</h1>
<p class="muted">Consulte solicitações, acompanhe pagamentos e organize os lugares.</p>
</div>
<a class="button" href="<?= e(
    url('admin/nova-reserva'),
) ?>"><?= icon(
    'plus',
) ?> Nova reserva manual</a>
</div>
<form class="filter-bar card" method="get">
<input name="r" type="hidden" value="admin/reservas">
<label>Busca<input name="q" value="<?= e(
     $_GET['q'] ?? '',
 ) ?>" placeholder="Nome, telefone ou código">
</label>
<label>Viagem<select name="viagem_id">
<option value="">Todas</option><?php foreach (
    $trips
    as $t
): ?><option value="<?= $t['id'] ?>"<?= selected($_GET['viagem_id'] ?? '', $t['id']) ?>><?= e(
    $t['nome'],
) ?> · <?= e(
     datebr($t['partida'], false),
 ) ?></option><?php endforeach; ?></select>
</label>
<label>Situação<select name="status">
<option value="">Todas</option><?php foreach (
    ['pendente', 'parcial', 'confirmada', 'cancelada', 'expirada']
    as $s
): ?><option value="<?= $s ?>"<?= selected($_GET['status'] ?? '', $s) ?>><?= statuslabel(
    $s,
) ?></option><?php endforeach; ?></select>
</label>
<button class="button secondary">Filtrar</button>
</form>
<p class="small muted">Até 200 resultados recentes. Use a busca para localizar reservas no histórico.</p>
<section class="card table-card"><?php require BASE_PATH .
    '/app/Views/components/reservations-table.php'; ?></section>
