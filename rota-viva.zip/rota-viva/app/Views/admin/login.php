<div class="login-card">
<span class="eyebrow">BEM-VINDO DE VOLTA</span>
<h2>Vamos organizar<br>a próxima viagem?</h2>
<p class="muted">Entre com o acesso do proprietário.</p>
<form action="<?= e(
    url('admin/login'),
) ?>" method="post" class="stack"><?= csrf() ?><label>E-mail<input type="email" name="email" autocomplete="username" required maxlength="190" autofocus>
</label>
<label>Senha<input type="password" name="senha" autocomplete="current-password" required maxlength="72">
</label>
<button class="button full" type="submit">Entrar no painel <?= icon(
    'arrow',
) ?></button>
</form>
<p class="small muted">Esqueceu a senha? Consulte o procedimento de recuperação no guia de instalação.</p>
<a class="text-link" href="<?= e(
    url(),
) ?>">← Voltar ao site</a>
</div>
