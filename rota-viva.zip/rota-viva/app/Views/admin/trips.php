<div class="section-heading">
<div>
<span class="eyebrow">CADA SAÍDA, UMA NOVA HISTÓRIA</span>
<h1>Suas viagens.</h1>
<p class="muted">Organize roteiros, vendas e ocupação em um só lugar.</p>
</div>
<a class="button" href="<?= e(
    url('admin/viagem'),
) ?>"><?= icon(
    'plus',
) ?> Nova viagem</a>
</div>
<form class="filter-bar card" method="get">
<input type="hidden" name="r" value="admin/viagens">
<label>Destino<input name="destino" value="<?= e(
     $_GET['destino'] ?? '',
 ) ?>" placeholder="Buscar destino">
</label>
<label>Situação<select name="status">
<option value="">Todas</option><?php foreach (
    ['rascunho', 'aberta', 'encerrada', 'em_andamento', 'concluida', 'cancelada']
    as $s
): ?><option value="<?= $s ?>"<?= selected($_GET['status'] ?? '', $s) ?>><?= statuslabel(
    $s,
) ?></option><?php endforeach; ?></select>
</label>
<button class="button secondary">Filtrar</button>
<a href="<?= e(
    url('admin/viagens'),
) ?>">Limpar</a>
</form>
<p class="small muted">Até 200 viagens, ordenadas pela partida mais recente. Use os filtros para localizar saídas.</p>
<div class="admin-trip-grid"><?php foreach (
    $trips
    as $t
):
    $percent = $t['capacidade']
        ? round((100 * $t['ocupadas']) / $t['capacidade'])
        : 0; ?><article class="card admin-trip">
<div class="spread"><?=
badge($t['status']) ?><?php if ($t['demonstrativo']): ?><span class="badge">DEMONSTRAÇÃO</span><?php endif; ?><?= icon('bus')
?></div>
<h2><?= e($t['nome']) ?></h2>
<p class="muted"><?= e($t['origem']) ?> → <?= e(
     $t['destino'],
 ) ?></p>
<p class="icon-line"><?=
icon('calendar') . e(datebr($t['partida']))
?></p>
<div class="spread">
<strong><?= money($t['preco']) ?></strong>
<span><?= $t[
    'ocupadas'
] ?> / <?= $t[
     'capacidade'
 ] ?> ocupadas</span>
</div>
<progress value="<?= $percent ?>" max="100" aria-label="Ocupação <?= $percent ?>%">
</progress>
<div class="button-row">
<a class="button small" href="<?= e(
    url('admin/mapa', ['viagem_id' => $t['id']]),
) ?>"><?= icon('seat') ?> Mapa</a>
<a class="button small secondary" href="<?= e(
     url('admin/viagem', ['id' => $t['id']]),
 ) ?>">Editar</a>
<form action="<?= e(
    url('admin/viagem/duplicar'),
) ?>" method="post"><?= csrf() ?><input name="id" type="hidden" value="<?= $t[
    'id'
] ?>">
<button class="button small ghost" type="submit">Duplicar</button>
</form>
</div>
<div class="button-row small">
<a href="<?= e(
    url('admin/passageiros', ['viagem_id' => $t['id']]),
) ?>">Passageiros</a>
<a href="<?= e(
    url('admin/relatorios', ['viagem_id' => $t['id']]),
) ?>">Relatórios</a><?php if (in_array($t['status'], ['aberta', 'encerrada'])): ?><a href="<?= e(
    url('viagem', ['id' => $t['id']]),
) ?>" target="_blank" rel="noopener">Site ↗</a><?php endif; ?></div>
</article><?php
endforeach; ?></div><?php if (
    !$trips
): ?><div class="empty card">
<h2>Vamos criar a primeira viagem?</h2>
<p>Cadastre seu ônibus e prepare o próximo destino.</p>
<a class="button" href="<?= e(
    url('admin/viagem'),
) ?>">Nova viagem</a>
</div><?php endif; ?>
