<div class="page-heading compact">
<a class="back-link" href="<?= e(
    url('admin/viagens'),
) ?>">← Viagens</a>
<span class="eyebrow">MAPA E RESERVAS MANUAIS</span>
<h1><?= e(
    $trip['nome'],
) ?></h1>
<p class="muted"><?= e(datebr($trip['partida'])) ?> · <?= e(
     $trip['onibus'],
 ) ?> · <?= badge($trip['status']) ?></p>
</div><?php require BASE_PATH .
    '/app/Views/components/booking-map.php'; ?>
