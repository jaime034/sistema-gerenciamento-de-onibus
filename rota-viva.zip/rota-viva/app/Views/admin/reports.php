<div class="section-heading">
<div>
<span class="eyebrow">DADOS PARA DECIDIR MELHOR</span>
<h1>Relatórios.</h1>
<p class="muted">Consulte a operação e exporte informações reais do banco.</p>
</div>
</div><?php require BASE_PATH .
    '/app/Views/components/report-filter.php'; ?><p class="small muted">Financeiro por viagem usa a data da partida e todos os lançamentos dessas viagens. Recebimentos por período usa a data financeira. Passageiros e ocupação usam a partida; uma viagem específica inclui toda a sua lista. Pendências e cancelamentos usam a data de criação da reserva.</p>
<section class="card table-card">
<div class="section-heading table-heading">
<h2><?= e(
    $report['title'],
) ?></h2>
<div class="button-row">
<a class="button small secondary" href="<?= e(
    url('admin/relatorios', array_merge(array_diff_key($_GET, ['r' => 1]), ['formato' => 'csv'])),
) ?>"><?= icon('download') ?> CSV / Excel</a>
<a class="button small" href="<?= e(
     url('admin/relatorios', array_merge(array_diff_key($_GET, ['r' => 1]), ['formato' => 'pdf'])),
 ) ?>"><?= icon('download') ?> PDF</a>
</div>
</div><?php require BASE_PATH .
     '/app/Views/components/report-table.php'; ?></section>
