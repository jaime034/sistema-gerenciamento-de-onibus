<?php $net = 0;
foreach ($payments['rows'] as $p) {
    $net += ($p['tipo'] === 'recebimento' ? 1 : -1) * (float) $p['valor'];
}
$due = (float) $totals['a_receber'];
$review = (float) $totals['a_revisar'];
$filtered = [];
foreach ($pending as $r) {
    if (in_array($r['status'], ['pendente', 'parcial'], true)) {
        $filtered[] = $r;
    }
}
?>
<div class="section-heading">
<div>
<span class="eyebrow">CADA RECEBIMENTO, CONFERIDO</span>
<h1>Financeiro.</h1>
<p class="muted">Pagamentos manuais e parciais, saldos e estornos com histórico.</p>
</div>
<a class="button secondary" href="<?= e(
    url('admin/relatorios', ['tipo' => 'movimentos']),
) ?>">Relatório de movimentos</a>
</div><?php
$filterRoute = 'admin/financeiro';
require BASE_PATH . '/app/Views/components/report-filter.php';
?><div class="stat-grid three">
<article class="stat-card accent">
<span>Líquido no período</span>
<strong><?= money(
    $net,
) ?></strong>
<small>Recebimentos menos estornos</small>
</article>
<article class="stat-card">
<span>Saldo das reservas ativas</span>
<strong><?= money(
    $due,
) ?></strong>
<small>Todas as reservas da viagem filtrada</small>
</article>
<article class="stat-card">
<span>Recebimentos em canceladas</span>
<strong><?= money(
    $review,
) ?></strong>
<small>Exige análise de eventual devolução</small>
</article>
</div>
<section class="card table-card section">
<div class="table-heading">
<h2>Reservas para receber</h2>
<p class="small muted">Abra a reserva para registrar o valor após conferir o recebimento. Esta lista usa a viagem; o período acima filtra apenas os movimentos financeiros.</p>
</div><?php
$reservations = $filtered;
require BASE_PATH . '/app/Views/components/reservations-table.php';
?></section>
<section class="card table-card section">
<div class="table-heading">
<h2>Lançamentos no período</h2>
</div><?php
$report = $payments;
require BASE_PATH . '/app/Views/components/report-table.php';
?></section>
