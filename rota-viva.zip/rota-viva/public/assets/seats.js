'use strict';
(() => {
    const root = document.querySelector('[data-seat-app]');
    if (!root) return;
    const $ = (s) => root.querySelector(s),
        admin = root.dataset.admin === '1',
        grid = $('[data-seat-grid]'),
        form = $('[data-reservation-form]');
    const stateLabels = {
        livre: 'Disponível',
        hold: 'Temporariamente reservada',
        pendente: 'Reservada com pagamento pendente',
        confirmada: 'Confirmada',
        bloqueada: 'Bloqueada',
    };
    const symbols = {
        livre: '✓',
        hold: '◷',
        pendente: '!',
        confirmada: '✓',
        bloqueada: '×',
        selected: '✓',
    };
    let seats = [],
        selected = new Set(),
        price = 0,
        busy = false,
        expires = null,
        serverOffset = 0,
        lastSeat = null,
        formSignature = '',
        lastFocus = null;
    const savedNames = new Map();
    const money = (c) => (c / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    function message(text) {
        const el = $('[data-map-error]');
        el.textContent = text;
        el.hidden = !text;
    }
    async function request(url, options = {}) {
        const response = await fetch(url, {
            credentials: 'same-origin',
            ...options,
            headers: {
                Accept: 'application/json',
                'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content,
                ...options.headers,
            },
        });
        let data;
        try {
            data = await response.json();
        } catch {
            throw new Error('A resposta do servidor não pôde ser lida. Atualize a página.');
        }
        if (!response.ok)
            throw new Error(data.error || 'Não foi possível atualizar a disponibilidade.');
        return data;
    }
    function render() {
        lastFocus = document.activeElement?.dataset.seatId;
        grid.replaceChildren();
        const positions = new Map(seats.map((s) => [`${s.fileira}-${s.coluna}`, s]));
        const rows = Number(root.dataset.rows || 0);
        for (let r = 1; r <= rows; r++)
            for (let c = 1; c <= 5; c++) {
                if (c === 3) {
                    const aisle = document.createElement('span');
                    aisle.className = 'aisle';
                    aisle.textContent = String(r);
                    aisle.setAttribute('aria-label', `Corredor, fileira ${r}`);
                    grid.append(aisle);
                    continue;
                }
                const s = positions.get(`${r}-${c}`);
                if (!s) {
                    const empty = document.createElement('span');
                    empty.className = 'seat-space';
                    empty.setAttribute('aria-hidden', 'true');
                    grid.append(empty);
                    continue;
                }
                const mine = selected.has(Number(s.id)),
                    state = mine ? 'selected' : s.estado;
                const b = document.createElement('button');
                b.type = 'button';
                b.className = `seat state-${state}${Number(s.janela) ? ' window-seat' : ''}`;
                b.dataset.seatId = s.id;
                b.dataset.row = r;
                b.dataset.col = c;
                b.setAttribute('aria-pressed', String(mine));
                b.setAttribute(
                    'aria-label',
                    `Poltrona ${s.numero}, ${mine ? 'selecionada por você' : stateLabels[s.estado]}${Number(s.janela) ? ', janela' : ''}`,
                );
                b.title = b.getAttribute('aria-label');
                if (!admin && s.estado !== 'livre' && !mine) b.disabled = true;
                const number = document.createElement('strong');
                number.textContent = s.numero;
                const symbol = document.createElement('small');
                symbol.textContent = symbols[state];
                symbol.setAttribute('aria-hidden', 'true');
                b.append(number, symbol);
                b.addEventListener('click', () => {
                    lastSeat = Number(s.id);
                    if (s.estado === 'livre' || mine) toggle(Number(s.id));
                    else if (admin) inspect(Number(s.id));
                });
                grid.append(b);
            }
        if (lastFocus)
            grid.querySelector(`[data-seat-id="${lastFocus}"]`)?.focus({ preventScroll: true });
        updateSummary();
    }
    function updateSummary() {
        const chosen = seats.filter((s) => selected.has(Number(s.id)));
        $('[data-selected-label]').textContent = chosen.length
            ? chosen.map((s) => s.numero).join(', ')
            : 'Nenhuma selecionada';
        let discount = 0;
        const v = $('[data-discount]')?.value;
        if (v) {
            const val = Number(v.replace(/\./g, '').replace(',', '.'));
            discount = Number.isFinite(val) ? Math.round(val * 100) : 0;
        }
        $('[data-total]').textContent = money(Math.max(0, price * chosen.length - discount));
        $('[data-book-submit]').disabled = busy || !chosen.length || root.dataset.canBook !== '1';
        const signature = chosen.map((s) => s.id).join(',');
        if (signature !== formSignature) {
            form.querySelectorAll('[data-passenger-id]').forEach((input) =>
                savedNames.set(Number(input.dataset.passengerId), input.value),
            );
            const fields = $('[data-passengers]');
            fields.replaceChildren();
            const h = document.createElement('h3');
            h.textContent = chosen.length
                ? 'Nome de cada passageiro'
                : 'Selecione os lugares para continuar';
            fields.append(h);
            for (const s of chosen) {
                const hidden = document.createElement('input');
                hidden.type = 'hidden';
                hidden.name = 'seats[]';
                hidden.value = s.id;
                const label = document.createElement('label');
                label.textContent = `Passageiro da poltrona ${s.numero}`;
                const input = document.createElement('input');
                input.name = `passageiros[${s.id}]`;
                input.dataset.passengerId = s.id;
                input.required = true;
                input.minLength = 3;
                input.maxLength = 150;
                input.autocomplete = 'off';
                input.value = savedNames.get(Number(s.id)) ?? '';
                label.append(input);
                fields.append(hidden, label);
            }
            formSignature = signature;
        }
        tick();
    }
    function tick() {
        const el = $('[data-hold-timer]');
        if (!expires || !selected.size) {
            el.textContent =
                root.dataset.canBook === '0'
                    ? 'Esta viagem não está recebendo novas reservas.'
                    : 'Selecione seus lugares para continuar.';
            return;
        }
        const seconds = Math.max(
            0,
            Math.floor(
                (Date.parse(expires.replace(' ', 'T') + 'Z') - (Date.now() + serverOffset)) / 1000,
            ),
        );
        el.textContent = seconds
            ? `Seus lugares estão protegidos por ${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}.`
            : 'O prazo terminou. Atualizando disponibilidade…';
        if (!seconds) {
            $('[data-book-submit]').disabled = true;
            if (!busy) refresh();
        }
    }
    async function refresh() {
        if (busy || document.hidden) return;
        busy = true;
        try {
            const d = await request(root.dataset.api);
            serverOffset = Date.parse(d.server_time) - Date.now();
            seats = d.seats;
            price = Math.round(Number(d.price) * 100);
            root.dataset.rows = d.rows;
            root.dataset.canBook = d.can_book ? '1' : '0';
            selected = new Set(seats.filter((s) => s.mine).map((s) => Number(s.id)));
            expires = seats.find((s) => s.mine)?.expira_em ?? null;
            $('[data-map-connection]').textContent = 'Atualizado';
            message('');
            busy = false;
            render();
        } catch (e) {
            message(e.message);
            $('[data-map-connection]').textContent = 'Sem atualização';
            $('[data-book-submit]').disabled = true;
        } finally {
            busy = false;
        }
    }
    async function toggle(id) {
        if (busy) return;
        if (root.dataset.canBook !== '1')
            return message('As reservas desta viagem estão encerradas.');
        const next = new Set(selected);
        next.has(id) ? next.delete(id) : next.add(id);
        if (next.size > Number(root.dataset.max))
            return message(`Escolha até ${root.dataset.max} lugares por reserva.`);
        busy = true;
        $('[data-book-submit]').disabled = true;
        $('[data-map-connection]').textContent = 'Protegendo seleção…';
        try {
            await request(root.dataset.hold, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ viagem_id: Number(root.dataset.trip), seats: [...next] }),
            });
            message('');
        } catch (e) {
            message(e.message);
            window.rvToast(e.message);
        } finally {
            busy = false;
            await refresh();
        }
    }
    grid.addEventListener('keydown', (e) => {
        const b = e.target.closest('button[data-seat-id]');
        if (
            !b ||
            !['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End'].includes(e.key)
        )
            return;
        e.preventDefault();
        const buttons = [...grid.querySelectorAll('button:not(:disabled)')];
        let target;
        if (e.key === 'Home') target = buttons[0];
        else if (e.key === 'End') target = buttons.at(-1);
        else {
            let r = Number(b.dataset.row),
                c = Number(b.dataset.col);
            for (let n = 0; n < 45; n++) {
                if (e.key === 'ArrowLeft') c--;
                if (e.key === 'ArrowRight') c++;
                if (e.key === 'ArrowUp') r--;
                if (e.key === 'ArrowDown') r++;
                target = buttons.find(
                    (x) => Number(x.dataset.row) === r && Number(x.dataset.col) === c,
                );
                if (target || r < 1 || c < 1 || r > Number(root.dataset.rows) || c > 5) break;
            }
        }
        target?.focus();
    });
    async function inspect(id) {
        const dialog = root.querySelector('dialog');
        if (!dialog) return;
        try {
            const endpoint = new URL(root.dataset.inspect);
            endpoint.searchParams.set('id', String(id));
            const d = await request(endpoint);
            $('[data-inspect-title]').textContent = `Poltrona ${d.seat.numero}`;
            const body = $('[data-inspect-body]');
            body.replaceChildren();
            const p = document.createElement('p');
            p.textContent =
                stateLabels[d.seat.estado] + (d.seat.motivo ? `: ${d.seat.motivo}` : '');
            body.append(p);
            if (d.reservation) {
                const r = d.reservation;
                const info = document.createElement('p');
                info.textContent = `${r.passenger} · ${r.code} · Recebido ${money(Math.round(Number(r.received) * 100))} de ${money(Math.round(Number(r.total) * 100))}`;
                const a = document.createElement('a');
                a.href = r.url;
                a.className = 'button full';
                a.textContent = 'Abrir reserva e ferramentas';
                body.append(info, a);
            }
            const bf = $('[data-block-form]');
            bf.hidden = !['livre', 'bloqueada'].includes(d.seat.estado);
            bf.elements.poltrona_id.value = id;
            bf.elements.acao.value = d.seat.estado === 'bloqueada' ? 'desbloquear' : 'bloquear';
            $('[data-block-reason]').hidden = d.seat.estado === 'bloqueada';
            bf.elements.motivo.required = d.seat.estado === 'livre';
            $('[data-block-button]').textContent =
                d.seat.estado === 'bloqueada' ? 'Desbloquear poltrona' : 'Bloquear poltrona';
            const history = $('[data-seat-history]');
            history.replaceChildren();
            for (const h of d.history) {
                const p = document.createElement('p');
                p.className = 'small';
                p.textContent = `${h.date} · ${h.event}`;
                history.append(p);
            }
            if (!d.history.length) history.textContent = 'Nenhum evento recente.';
            dialog.showModal();
        } catch (e) {
            message(e.message);
        }
    }
    $('[data-seat-details]')?.addEventListener('click', () => {
        if (lastSeat) inspect(lastSeat);
        else window.rvToast('Toque primeiro na poltrona que deseja inspecionar.');
    });
    $('[data-discount]')?.addEventListener('input', updateSummary);
    form.addEventListener('submit', (e) => {
        if (busy || !selected.size || $('[data-book-submit]').disabled) {
            e.preventDefault();
            message('Selecione os lugares e aguarde a confirmação da disponibilidade.');
            return;
        }
        $('[data-book-submit]').disabled = true;
        $('[data-book-submit]').textContent = 'Registrando reserva…';
    });
    refresh();
    setInterval(() => refresh(), 8000);
    setInterval(tick, 1000);
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) refresh();
    });
})();
