'use strict';
(() => {
    const root = document.querySelector('[data-layout-editor]');
    if (!root) return;
    const grid = root.querySelector('[data-layout-grid]'),
        rowInput = root.querySelector('[data-row-count]');
    function collect() {
        const map = new Map();
        grid.querySelectorAll('.layout-cell').forEach((cell) =>
            map.set(`${cell.dataset.row}-${cell.dataset.col}`, {
                number: cell.querySelector('input:not([type])').value,
                window: cell.querySelector('input[name$="[janela]"]').checked,
                active: cell.querySelector('input[name$="[ativa]"]').checked,
            }),
        );
        return map;
    }
    function count() {
        const n = [...grid.querySelectorAll('input[name$="[numero]"]')].filter((e) =>
            e.value.trim(),
        ).length;
        root.querySelector('[data-layout-count]').textContent = `${n} poltronas configuradas`;
    }
    function cell(row, col, data) {
        const div = document.createElement('div');
        div.className = 'layout-cell';
        div.dataset.row = row;
        div.dataset.col = col;
        const label = document.createElement('label');
        label.append(`F${row} · P${col}`);
        const input = document.createElement('input');
        input.name = `layout[${row}][${col}][numero]`;
        input.value = data?.number ?? '';
        input.maxLength = 12;
        input.setAttribute('aria-label', `Número da poltrona fileira ${row} posição ${col}`);
        label.append(input);
        div.append(label);
        for (const [name, text, checked] of [
            ['janela', 'Janela', data?.window ?? [1, 5].includes(col)],
            ['ativa', 'Ativa', data?.active ?? true],
        ]) {
            const l = document.createElement('label');
            l.className = 'check';
            const c = document.createElement('input');
            c.type = 'checkbox';
            c.name = `layout[${row}][${col}][${name}]`;
            c.checked = checked;
            l.append(c, text);
            div.append(l);
        }
        return div;
    }
    function draw(rows, map) {
        grid.replaceChildren();
        for (let row = 1; row <= rows; row++)
            for (const col of [1, 2, 3, 4, 5]) {
                if (col === 3) {
                    const aisle = document.createElement('span');
                    aisle.className = 'layout-aisle';
                    aisle.textContent = row;
                    grid.append(aisle);
                } else grid.append(cell(row, col, map.get(`${row}-${col}`)));
            }
        count();
    }
    root.querySelector('[data-rows]').addEventListener('click', () => {
        const rows = Number(rowInput.value);
        if (!Number.isInteger(rows) || rows < 1 || rows > 40)
            return window.rvToast('Informe de 1 a 40 fileiras.');
        const map = collect();
        if (
            [...map.keys()].some((k) => Number(k.split('-')[0]) > rows) &&
            !confirm('As fileiras excedentes sairão do editor. Continuar?')
        )
            return;
        draw(rows, map);
    });
    root.querySelector('[data-generate]').addEventListener('click', () => {
        const total = Number(root.querySelector('[data-generate-count]').value);
        if (!Number.isInteger(total) || total < 1 || total > 160)
            return window.rvToast('Informe de 1 a 160 poltronas.');
        if (
            [...collect().values()].some((x) => x.number) &&
            !confirm(
                'Gerar nova numeração sequencial no editor? O mapa salvo anteriormente será preservado como outra versão.',
            )
        )
            return;
        const map = new Map();
        let n = 1;
        const rows = Math.ceil(total / 4);
        for (let r = 1; r <= rows; r++)
            for (const c of [1, 2, 4, 5])
                if (n <= total)
                    map.set(`${r}-${c}`, {
                        number: String(n++).padStart(2, '0'),
                        window: [1, 5].includes(c),
                        active: true,
                    });
        rowInput.value = rows;
        draw(rows, map);
    });
    grid.addEventListener('input', count);
    count();
})();
