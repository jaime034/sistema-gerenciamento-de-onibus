'use strict';
(() => {
    const $ = (s, r = document) => r.querySelector(s);
    window.rvToast = (message) => {
        const el = $('.toast');
        if (!el) return;
        el.textContent = message;
        el.hidden = false;
        clearTimeout(el._timer);
        el._timer = setTimeout(() => (el.hidden = true), 4500);
    };
    $('[data-nav]')?.addEventListener('click', (e) => {
        const b = e.currentTarget;
        const on = b.getAttribute('aria-expanded') !== 'true';
        b.setAttribute('aria-expanded', String(on));
        $('.public-nav')?.classList.toggle('open', on);
    });
    $('[data-sidebar]')?.addEventListener('click', (e) => {
        const on = e.currentTarget.getAttribute('aria-expanded') !== 'true';
        e.currentTarget.setAttribute('aria-expanded', String(on));
        $('.sidebar')?.classList.toggle('open', on);
    });
    try {
        if (localStorage.getItem('rv-theme') === 'dark')
            document.documentElement.dataset.theme = 'dark';
    } catch {}
    $('[data-theme]')?.addEventListener('click', () => {
        const theme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
        document.documentElement.dataset.theme = theme;
        try {
            localStorage.setItem('rv-theme', theme);
        } catch {}
    });
    document.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-copy]');
        if (b) {
            try {
                await navigator.clipboard.writeText(b.dataset.copy);
                window.rvToast('Copiado. Guarde esta informação em um local seguro.');
            } catch {
                const input = document.createElement('textarea');
                input.value = b.dataset.copy;
                document.body.append(input);
                input.select();
                document.execCommand('copy');
                input.remove();
                window.rvToast('Informação copiada.');
            }
        }
        if (e.target.closest('[data-back]')) history.back();
        if (e.target.closest('[data-close-dialog]')) e.target.closest('dialog')?.close();
    });
    document.querySelectorAll('form[data-confirm]').forEach((form) =>
        form.addEventListener('submit', (e) => {
            if (!confirm(form.dataset.confirm)) e.preventDefault();
        }),
    );
    const lookup = $('[data-lookup]');
    if (lookup && location.hash) {
        const params = new URLSearchParams(location.hash.slice(1));
        const code = params.get('codigo'),
            token = params.get('token');
        if (code && token) {
            lookup.elements.codigo.value = code;
            lookup.elements.token.value = token;
            history.replaceState(null, '', location.pathname + location.search);
        }
    }
})();
