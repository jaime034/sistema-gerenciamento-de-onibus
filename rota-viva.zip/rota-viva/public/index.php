<?php
declare(strict_types=1);
require __DIR__ . '/../app/bootstrap.php';
use App\Core\{HttpException, Security};
$route = trim((string) ($_GET['r'] ?? ''), '/');
$method = $_SERVER['REQUEST_METHOD'];
if ($route === 'imagem' && $method === 'GET') {
    \App\Services\UploadService::serve((string) ($_GET['arquivo'] ?? ''));
}
if (!is_file(BASE_PATH . '/config/config.php') && $route !== 'instalar') {
    redirect('instalar');
}
if (config('environment') === 'production' && $route !== 'instalar') {
    if (!str_starts_with(config('app_url'), 'https://')) {
        throw new HttpException(
            503,
            'Configure o endereço HTTPS da aplicação antes de operar em produção.',
        );
    }
    if (!Security::isHttps()) {
        if ($method !== 'GET') {
            throw new HttpException(
                403,
                'Esta operação exige uma conexão HTTPS. Abra o site pelo endereço seguro.',
            );
        }
        header('Location: ' . url($route, array_diff_key($_GET, ['r' => true])), true, 302);
        exit();
    }
}
$routes = require BASE_PATH . '/config/routes.php';
if (!isset($routes[$method][$route])) {
    throw new HttpException(
        isset($routes['GET'][$route]) ? 405 : 404,
        'Página ou operação não encontrada.',
    );
}
$admin =
    ($route === 'admin' ||
        str_starts_with($route, 'admin/') ||
        str_starts_with($route, 'api/admin/')) &&
    $route !== 'admin/login';
if ($admin) {
    Security::requireAdmin();
}
if ($method === 'POST') {
    Security::validateCsrf();
}
[$class, $action] = $routes[$method][$route];
(new $class())->$action();
