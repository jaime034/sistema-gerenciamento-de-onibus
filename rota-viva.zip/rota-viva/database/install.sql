-- Rota Viva 1.0 • MySQL 8.0.16+ / MariaDB 10.6+ • executar no banco previamente criado.
SET NAMES utf8mb4;
SET time_zone = '+00:00';
CREATE TABLE schema_migrations (version VARCHAR(80) PRIMARY KEY, applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE usuarios (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(120) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE,
 senha_hash VARCHAR(255) NOT NULL, ativo TINYINT(1) NOT NULL DEFAULT 1, session_version INT NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE configuracoes (chave VARCHAR(80) PRIMARY KEY, valor TEXT NOT NULL, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO configuracoes(chave,valor) VALUES
('nome_servico','Rota Viva'),('slogan','Seu próximo destino começa aqui.'),('telefone',''),('whatsapp',''),('proprietario',''),('email_contato',''),('logo',''),('pix_chave',''),('pix_beneficiario',''),('pix_instrucoes','Após realizar o Pix, entre em contato com o responsável e informe o código da reserva. O pagamento será conferido manualmente.'),('hold_minutos','10'),('pagamento_horas','24'),('max_poltronas_reserva','8'),('metodos_pagamento','Pix,Dinheiro,Transferência,Outros'),('regras_cancelamento','Solicite o cancelamento ao responsável pelo serviço. Prazos, condições e eventuais reembolsos devem ser informados pelo proprietário antes da compra.'),('instrucoes_embarque','Apresente o comprovante e um documento de identificação no embarque. Chegue com antecedência ao ponto informado.'),('privacidade','Utilizamos nome e contato para organizar a reserva, comunicar informações da viagem e controlar o embarque. Os dados ficam restritos ao responsável pelo serviço. Para exercer seus direitos ou esclarecer prazos de conservação, utilize o contato informado neste site.'),('tema','claro');
CREATE TABLE onibus (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, identificacao VARCHAR(120) NOT NULL, modelo VARCHAR(150) NOT NULL DEFAULT '', caracteristicas TEXT,
 ativo TINYINT(1) NOT NULL DEFAULT 1, demonstrativo TINYINT(1) NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE layouts_onibus (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, onibus_id BIGINT UNSIGNED NOT NULL, nome VARCHAR(120) NOT NULL,
 versao INT NOT NULL, fileiras SMALLINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_layout_versao(onibus_id,versao), CONSTRAINT fk_layout_onibus FOREIGN KEY(onibus_id) REFERENCES onibus(id) ON DELETE RESTRICT,
 CONSTRAINT ck_layout_fileiras CHECK(fileiras BETWEEN 1 AND 40)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE poltronas (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, layout_id BIGINT UNSIGNED NOT NULL, numero VARCHAR(12) NOT NULL,
 fileira SMALLINT UNSIGNED NOT NULL, coluna TINYINT UNSIGNED NOT NULL, janela TINYINT(1) NOT NULL DEFAULT 0, ativa TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_poltrona_numero(layout_id,numero), UNIQUE KEY uq_poltrona_posicao(layout_id,fileira,coluna),
 CONSTRAINT fk_poltrona_layout FOREIGN KEY(layout_id) REFERENCES layouts_onibus(id) ON DELETE RESTRICT,
 CONSTRAINT ck_poltrona_coluna CHECK(coluna IN(1,2,4,5)), CONSTRAINT ck_poltrona_fileira CHECK(fileira BETWEEN 1 AND 40)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE viagens (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, layout_id BIGINT UNSIGNED NOT NULL, nome VARCHAR(160) NOT NULL,
 origem VARCHAR(150) NOT NULL, destino VARCHAR(150) NOT NULL, partida DATETIME NOT NULL, retorno DATETIME NULL,
 embarque TEXT NOT NULL, preco DECIMAL(10,2) NOT NULL, descricao TEXT, orientacoes TEXT, capa VARCHAR(190) NULL,
 status ENUM('rascunho','aberta','encerrada','em_andamento','concluida','cancelada') NOT NULL DEFAULT 'rascunho',
 demonstrativo TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_viagens_publica(status,partida), CONSTRAINT fk_viagem_layout FOREIGN KEY(layout_id) REFERENCES layouts_onibus(id) ON DELETE RESTRICT,
 CONSTRAINT ck_preco CHECK(preco>=0), CONSTRAINT ck_retorno CHECK(retorno IS NULL OR retorno>=partida)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE reservas (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, viagem_id BIGINT UNSIGNED NOT NULL, codigo VARCHAR(32) NOT NULL UNIQUE, token_hash CHAR(64) NOT NULL,
 responsavel VARCHAR(150) NOT NULL, telefone VARCHAR(25) NOT NULL, email VARCHAR(190) NULL,
 status ENUM('pendente','parcial','confirmada','cancelada','expirada') NOT NULL DEFAULT 'pendente',
 subtotal DECIMAL(10,2) NOT NULL, desconto DECIMAL(10,2) NOT NULL DEFAULT 0, total DECIMAL(10,2) NOT NULL,
 desconto_motivo VARCHAR(250) NULL, observacoes TEXT, origem ENUM('publica','manual') NOT NULL DEFAULT 'publica',
 prazo_pagamento DATETIME NOT NULL, regras_snapshot TEXT NOT NULL, privacidade_snapshot TEXT NOT NULL, consent_at DATETIME NOT NULL,
 created_by BIGINT UNSIGNED NULL, demonstrativo TINYINT(1) NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_reserva_viagem(viagem_id,id), INDEX idx_reserva_status_prazo(status,prazo_pagamento), INDEX idx_reserva_telefone(telefone),
 CONSTRAINT fk_reserva_viagem FOREIGN KEY(viagem_id) REFERENCES viagens(id) ON DELETE RESTRICT,
 CONSTRAINT fk_reserva_usuario FOREIGN KEY(created_by) REFERENCES usuarios(id) ON DELETE RESTRICT,
 CONSTRAINT ck_reserva_valores CHECK(total>=0 AND desconto>=0 AND desconto<=subtotal AND total=subtotal-desconto)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE viagens_poltronas (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, viagem_id BIGINT UNSIGNED NOT NULL, poltrona_id BIGINT UNSIGNED NOT NULL,
 numero VARCHAR(12) NOT NULL, fileira SMALLINT UNSIGNED NOT NULL, coluna TINYINT UNSIGNED NOT NULL, janela TINYINT(1) NOT NULL,
 estado ENUM('livre','hold','pendente','confirmada','bloqueada') NOT NULL DEFAULT 'livre',
 reserva_id BIGINT UNSIGNED NULL, hold_hash CHAR(64) NULL, expira_em DATETIME NULL, bloqueio_motivo VARCHAR(250) NULL,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_inventario(viagem_id,poltrona_id), UNIQUE KEY uq_inventario_numero(viagem_id,numero), UNIQUE KEY uq_inventario_posicao(viagem_id,fileira,coluna), UNIQUE KEY uq_inventario_viagem_id(viagem_id,id),
 INDEX idx_inventario_expira(estado,expira_em), INDEX idx_inventario_reserva(reserva_id),
 CONSTRAINT fk_inventario_viagem FOREIGN KEY(viagem_id) REFERENCES viagens(id) ON DELETE RESTRICT,
 CONSTRAINT fk_inventario_poltrona FOREIGN KEY(poltrona_id) REFERENCES poltronas(id) ON DELETE RESTRICT,
 CONSTRAINT fk_inventario_reserva FOREIGN KEY(viagem_id,reserva_id) REFERENCES reservas(viagem_id,id) ON DELETE RESTRICT,
 CONSTRAINT ck_inventario_estado CHECK(
 (estado='livre' AND reserva_id IS NULL AND hold_hash IS NULL AND expira_em IS NULL) OR
 (estado='hold' AND reserva_id IS NULL AND hold_hash IS NOT NULL AND expira_em IS NOT NULL) OR
 (estado IN('pendente','confirmada') AND reserva_id IS NOT NULL AND hold_hash IS NULL AND expira_em IS NULL) OR
 (estado='bloqueada' AND reserva_id IS NULL AND hold_hash IS NULL AND expira_em IS NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE passageiros (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(150) NOT NULL, telefone VARCHAR(25) NULL, observacoes TEXT, demonstrativo TINYINT(1) NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_passageiro_nome(nome), INDEX idx_passageiro_telefone(telefone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE reservas_passageiros (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, viagem_id BIGINT UNSIGNED NOT NULL, reserva_id BIGINT UNSIGNED NOT NULL,
 passageiro_id BIGINT UNSIGNED NOT NULL, viagem_poltrona_id BIGINT UNSIGNED NOT NULL, numero_snapshot VARCHAR(12) NOT NULL,
 preco_unitario DECIMAL(10,2) NOT NULL, embarcou_em DATETIME NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_reserva_assento(reserva_id,viagem_poltrona_id),
 CONSTRAINT fk_rp_reserva FOREIGN KEY(viagem_id,reserva_id) REFERENCES reservas(viagem_id,id) ON DELETE RESTRICT,
 CONSTRAINT fk_rp_passageiro FOREIGN KEY(passageiro_id) REFERENCES passageiros(id) ON DELETE RESTRICT,
 CONSTRAINT fk_rp_inventario FOREIGN KEY(viagem_id,viagem_poltrona_id) REFERENCES viagens_poltronas(viagem_id,id) ON DELETE RESTRICT,
 CONSTRAINT ck_rp_preco CHECK(preco_unitario>=0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE pagamentos (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, reserva_id BIGINT UNSIGNED NOT NULL,
 tipo ENUM('recebimento','estorno') NOT NULL DEFAULT 'recebimento', valor DECIMAL(10,2) NOT NULL,
 metodo VARCHAR(60) NOT NULL, pago_em DATETIME NOT NULL, observacoes VARCHAR(500) NULL, registrado_por BIGINT UNSIGNED NOT NULL,
 idempotencia CHAR(64) NOT NULL UNIQUE, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_pagamentos_periodo(pago_em), CONSTRAINT fk_pagamento_reserva FOREIGN KEY(reserva_id) REFERENCES reservas(id) ON DELETE RESTRICT,
 CONSTRAINT fk_pagamento_usuario FOREIGN KEY(registrado_por) REFERENCES usuarios(id) ON DELETE RESTRICT,
 CONSTRAINT ck_pagamento_valor CHECK(valor>0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE auditoria (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, usuario_id BIGINT UNSIGNED NULL, viagem_id BIGINT UNSIGNED NULL, reserva_id BIGINT UNSIGNED NULL,
 evento VARCHAR(80) NOT NULL, detalhes JSON NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_auditoria_reserva(reserva_id,created_at), INDEX idx_auditoria_viagem(viagem_id,created_at),
 CONSTRAINT fk_auditoria_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT,
 CONSTRAINT fk_auditoria_viagem FOREIGN KEY(viagem_id) REFERENCES viagens(id) ON DELETE RESTRICT,
 CONSTRAINT fk_auditoria_reserva FOREIGN KEY(reserva_id) REFERENCES reservas(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE limites_requisicoes (
 chave CHAR(64) PRIMARY KEY, tentativas INT UNSIGNED NOT NULL DEFAULT 1, janela_inicio DATETIME NOT NULL, INDEX idx_limites_janela(janela_inicio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO schema_migrations(version) VALUES ('001_initial');
