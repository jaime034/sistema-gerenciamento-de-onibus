-- Remove SOMENTE entidades marcadas como demonstrativas e suas dependências.
-- Inclui reservas feitas nas viagens de demonstração. Faça backup antes de executar.
SET NAMES utf8mb4;
START TRANSACTION;
DELETE a FROM auditoria a LEFT JOIN reservas r ON r.id=a.reserva_id LEFT JOIN viagens v ON v.id=a.viagem_id WHERE r.demonstrativo=1 OR v.demonstrativo=1;
DELETE p FROM pagamentos p JOIN reservas r ON r.id=p.reserva_id WHERE r.demonstrativo=1;
UPDATE viagens_poltronas s JOIN reservas r ON r.id=s.reserva_id SET s.estado='livre',s.reserva_id=NULL,s.hold_hash=NULL,s.expira_em=NULL WHERE r.demonstrativo=1;
DELETE rp FROM reservas_passageiros rp JOIN reservas r ON r.id=rp.reserva_id WHERE r.demonstrativo=1;
DELETE FROM reservas WHERE demonstrativo=1;
DELETE s FROM viagens_poltronas s JOIN viagens v ON v.id=s.viagem_id WHERE v.demonstrativo=1;
DELETE FROM viagens WHERE demonstrativo=1;
DELETE p FROM poltronas p JOIN layouts_onibus l ON l.id=p.layout_id JOIN onibus o ON o.id=l.onibus_id WHERE o.demonstrativo=1;
DELETE l FROM layouts_onibus l JOIN onibus o ON o.id=l.onibus_id WHERE o.demonstrativo=1;
DELETE FROM onibus WHERE demonstrativo=1;
DELETE p FROM passageiros p WHERE p.demonstrativo=1 AND NOT EXISTS(SELECT 1 FROM reservas_passageiros rp WHERE rp.passageiro_id=p.id);
COMMIT;
