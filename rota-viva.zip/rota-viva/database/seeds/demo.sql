-- DADOS INTEIRAMENTE FICTÍCIOS. Importar uma única vez após a instalação, em ambiente de testes.
-- Não cria usuários nem define senhas. Remova com remove_demo.sql antes de operar de verdade.
SET NAMES utf8mb4;
SET time_zone = '+00:00';
START TRANSACTION;
INSERT INTO onibus(identificacao,modelo,caracteristicas,demonstrativo) VALUES('[DEMO] Ônibus de passeio','Modelo fictício','Ar-condicionado, poltronas reclináveis e espaço para bagagens. Informações fictícias de demonstração.',1);
SET @demo_bus=LAST_INSERT_ID();
INSERT INTO layouts_onibus(onibus_id,nome,versao,fileiras) VALUES(@demo_bus,'Demonstração: 26 lugares',1,7);
SET @demo_layout=LAST_INSERT_ID();
INSERT INTO poltronas(layout_id,numero,fileira,coluna,janela,ativa) VALUES
(@demo_layout,'01',1,1,1,1),
(@demo_layout,'02',1,2,0,1),
(@demo_layout,'03',1,4,0,1),
(@demo_layout,'04',1,5,1,1),
(@demo_layout,'05',2,1,1,1),
(@demo_layout,'06',2,2,0,1),
(@demo_layout,'07',2,4,0,1),
(@demo_layout,'08',2,5,1,1),
(@demo_layout,'09',3,1,1,1),
(@demo_layout,'10',3,2,0,1),
(@demo_layout,'11',3,4,0,1),
(@demo_layout,'12',3,5,1,1),
(@demo_layout,'13',4,1,1,1),
(@demo_layout,'14',4,2,0,1),
(@demo_layout,'15',4,4,0,1),
(@demo_layout,'16',4,5,1,1),
(@demo_layout,'17',5,1,1,1),
(@demo_layout,'18',5,2,0,1),
(@demo_layout,'19',5,4,0,1),
(@demo_layout,'20',5,5,1,1),
(@demo_layout,'21',6,1,1,1),
(@demo_layout,'22',6,2,0,1),
(@demo_layout,'23',6,4,0,1),
(@demo_layout,'24',6,5,1,1),
(@demo_layout,'25',7,1,1,1),
(@demo_layout,'26',7,2,0,0);
INSERT INTO viagens(layout_id,nome,origem,destino,partida,retorno,embarque,preco,descricao,orientacoes,status,demonstrativo) VALUES
(@demo_layout,'[DEMO] Um dia nas montanhas','São Paulo, SP','Campos do Jordão, SP',DATE_ADD(UTC_TIMESTAMP(),INTERVAL 10 DAY),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 11 DAY),'[DEMO] Praça de embarque fictícia, 100. Comparecer 30 minutos antes.',180.00,'Exemplo fictício de um roteiro de passeio. Nenhuma saída real é oferecida por estes dados.','Dados demonstrativos. Configure o roteiro e as condições reais antes de publicar uma viagem.','aberta',1),
(@demo_layout,'[DEMO] Caminhos do litoral','São Paulo, SP','Ubatuba, SP',DATE_ADD(UTC_TIMESTAMP(),INTERVAL 20 DAY),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 22 DAY),'[DEMO] Terminal fictício, plataforma 2.',250.00,'Exemplo fictício de um passeio pelo litoral. Não corresponde a uma oferta real.','Demonstração para testar reservas e ocupação.','aberta',1);
SET @demo_trip=(SELECT MIN(id) FROM viagens WHERE layout_id=@demo_layout);
INSERT INTO viagens_poltronas(viagem_id,poltrona_id,numero,fileira,coluna,janela,estado,bloqueio_motivo)
SELECT v.id,p.id,p.numero,p.fileira,p.coluna,p.janela,IF(p.ativa=1,'livre','bloqueada'),IF(p.ativa=1,NULL,'[DEMO] Poltrona desativada') FROM viagens v JOIN poltronas p ON p.layout_id=v.layout_id WHERE v.layout_id=@demo_layout;
INSERT INTO reservas(viagem_id,codigo,token_hash,responsavel,telefone,status,subtotal,desconto,total,origem,prazo_pagamento,regras_snapshot,privacidade_snapshot,consent_at,demonstrativo)
VALUES(@demo_trip,CONCAT('RV-',UPPER(LEFT(REPLACE(UUID(),'-',''),20))),SHA2(CONCAT(UUID(),UUID()),256),'[DEMO] Amanda Exemplo','11999990001','pendente',360.00,0,360.00,'manual',DATE_ADD(UTC_TIMESTAMP(),INTERVAL 24 HOUR),'[DEMO] Condições fictícias para teste.','[DEMO] Pessoas e contatos fictícios.',UTC_TIMESTAMP(),1);
SET @demo_reserva=LAST_INSERT_ID();
INSERT INTO passageiros(nome,telefone,demonstrativo) VALUES('[DEMO] Amanda Exemplo','11999990001',1);
SET @demo_p1=LAST_INSERT_ID();
INSERT INTO passageiros(nome,telefone,demonstrativo) VALUES('[DEMO] Lucas Exemplo','11999990002',1);
SET @demo_p2=LAST_INSERT_ID();
INSERT INTO reservas_passageiros(viagem_id,reserva_id,passageiro_id,viagem_poltrona_id,numero_snapshot,preco_unitario)
SELECT @demo_trip,@demo_reserva,IF(numero='01',@demo_p1,@demo_p2),id,numero,180.00 FROM viagens_poltronas WHERE viagem_id=@demo_trip AND numero IN('01','02');
UPDATE viagens_poltronas SET estado='pendente',reserva_id=@demo_reserva WHERE viagem_id=@demo_trip AND numero IN('01','02');
INSERT INTO auditoria(viagem_id,reserva_id,evento,detalhes) VALUES(@demo_trip,@demo_reserva,'dados_demonstrativos_criados',JSON_OBJECT('aviso','Todos os nomes e contatos são fictícios. Nenhum recebimento foi lançado.'));
COMMIT;
