# Rota Viva — gestão de viagens e reservas de poltronas

Aplicação web em PHP e MySQL para o proprietário de ônibus administrar viagens, passageiros, reservas e pagamentos, com seleção pública de poltronas sem conta de cliente. A identidade “Rota Viva” é inicial e pode ser alterada no painel.

## O que está implementado

- Site público com apresentação, catálogo filtrável, detalhes, mapa interativo, reserva com vários passageiros, instruções Pix e consulta privada.
- Painel com autenticação, dashboard real, viagens, duplicação, passageiros, presença no embarque, reservas manuais, descontos justificados, bloqueios e transferências de lugar.
- Editor de ônibus 2+2 com quantidade variável, números personalizados, fileiras incompletas, espaços inexistentes, janelas, poltronas desativadas e versões imutáveis de layout.
- Inventário por viagem com transações InnoDB, bloqueio transacional, constraints de unicidade e confirmação atômica de grupos.
- Seleções temporárias, reservas pendentes, expiração oportunista sem depender de cron e pagamentos parciais preservados para revisão.
- Recebimentos manuais Pix/dinheiro/transferência/outros, estornos com histórico e proteção contra reenvio duplicado de lançamento.
- Comprovantes PDF reais, relatórios PDF e CSV compatível com Excel, gráficos com dados reais e tema opcional no navegador.
- CSRF, PDO preparado, escape HTML, sessões seguras, limitação de tentativas, auditoria, uploads privados validados e chaves de consulta armazenadas como HMAC.
- Assistente web para o primeiro administrador, sem senha padrão; scripts CLI opcionais de migração, expiração e recuperação de acesso.

Não há processamento bancário automático. O proprietário confere o recebimento e registra a operação. O sistema não envia mensagens automaticamente; botões de WhatsApp preparam o texto para revisão e envio no aplicativo do usuário.

## Requisitos

PHP **8.2+ de 64 bits** com PDO/pdo_mysql, mbstring, fileinfo, session, ctype e JSON; **MySQL 8.0.16+ ou MariaDB 10.6+**, InnoDB e UTF8MB4; HTTPS em produção. O teste real usou PHP 8.3.6 e MariaDB 10.11.14. Compatibilidade com MySQL 8 foi considerada no SQL, mas esse servidor não foi executado no ambiente de entrega.

Não usa Bootstrap, React, Angular, CDN, Composer obrigatório ou Node em produção. HTML/CSS/JavaScript são locais. Não precisa de Docker, SSH, servidor de filas ou processo permanente na hospedagem.

## Instalação rápida

1. Crie um banco vazio e um usuário exclusivo no painel da hospedagem.
2. Envie o projeto e configure **`public/` como a única raiz pública**. `app`, `config`, `database` e `storage` devem ficar privados.
3. Copie `config/config.example.php` para `config/config.php`. Preencha banco, URL HTTPS, ambiente e dois segredos aleatórios distintos: `app_key` e `setup_token` (recomendados 64 caracteres cada).
4. Dê ao PHP permissão de escrita em `storage/logs`, `storage/uploads` e `storage/sessions`.
5. Importe **`database/install.sql`** no phpMyAdmin **ou** deixe o assistente criar o esquema no banco vazio. Não importe também `001_initial.sql`: os dois contêm o mesmo esquema inicial.
6. Acesse `index.php?r=instalar`, informe a chave de instalação e crie seu administrador com senha própria de 12 a 72 caracteres.
7. Remova `setup_token` da configuração, entre em `index.php?r=admin` e configure serviço, Pix, regras, ônibus e primeira viagem.

Para servidores com `public_html` fixo, subpasta, proxy, permissões, HTTPS, recuperação de senha sem SSH e demais detalhes, siga [INSTALACAO.md](docs/INSTALACAO.md).

**Nunca use os dados de configuração do ambiente de testes em produção.** O pacote não contém credenciais de banco, sessão, administrador ou Pix reais.

## Primeira viagem

Em **Ônibus e poltronas**, gere a disposição desejada e ajuste cada número. Em **Viagens**, escolha a versão do layout e salve o roteiro como rascunho. Confira o mapa, depois abra as reservas. O cliente escolhe lugares, preenche os dados e guarda o acesso privado. No painel, registre o recebimento após conferência; quando integral, a reserva fica confirmada e o PDF é habilitado.

Mudanças em layouts criam versões novas. Viagens com histórico de reservas preservam seu nome, roteiro, horários, embarque e mapa. Preços de novas reservas podem mudar sem alterar valores antigos. Cancelamentos liberam lugares e conservam os lançamentos financeiros.

## Banco, migrations e demonstração

| Arquivo | Uso |
| --- | --- |
| `database/install.sql` | Instalação completa em banco vazio |
| `database/migrations/001_initial.sql` | Mesmo esquema inicial, para versionamento; não importar junto ao arquivo anterior |
| `database/seeds/demo.sql` | Carga opcional fictícia: importar uma única vez em ambiente de testes |
| `database/seeds/remove_demo.sql` | Remove entidades demonstrativas e dependências; fazer backup antes |

Demonstrações não criam senha padrão nem registram recebimentos fictícios. Novas reservas feitas em viagens demonstrativas também são marcadas como demonstração. Não transforme uma dessas viagens em oferta real; remova a demonstração e cadastre a operação definitiva.

## Organização do código

`public/index.php` carrega o bootstrap, verifica método, CSRF e autorização e despacha as rotas de `config/routes.php`. Controllers coordenam HTTP, services aplicam regras transacionais e repositories centralizam consultas. Views e componentes reutilizáveis renderizam HTML escapado. As datas são UTC no banco e brasileiras na interface; valores críticos são calculados em centavos e persistidos em DECIMAL.

Leia a estrutura, o modelo relacional, os estados e a estratégia de concorrência em [ARQUITETURA.md](docs/ARQUITETURA.md).

## Documentação

- [Instalação e hospedagem](docs/INSTALACAO.md)
- [Arquitetura e modelo de dados](docs/ARQUITETURA.md)
- [Guia do proprietário](docs/GUIA_DO_PROPRIETARIO.md)
- [Guia do cliente](docs/GUIA_DO_CLIENTE.md)
- [Backup, restauração e atualização](docs/BACKUP_E_ATUALIZACAO.md)
- [Segurança e privacidade](docs/SEGURANCA_E_PRIVACIDADE.md)
- [Verificações operacionais e jurídicas](docs/VERIFICACOES_OPERACIONAIS_E_JURIDICAS.md)
- [Resultados e reprodução dos testes](docs/RESULTADOS_DOS_TESTES.md)

## Limites desta versão

- Pix e demais métodos têm conferência manual. Não há gateway, webhook bancário, emissão fiscal ou integração regulatória.
- Não há conta de cliente, disparo automático de e-mail/WhatsApp ou QR de validação. O código e a chave privada permitem consulta sem cadastro.
- Layout de um único piso, 2+2 com corredor central, até 40 fileiras/160 posições. Outros pisos e disposição 2+1 exigem evolução do modelo/editor.
- Transferências ocorrem dentro da mesma viagem. Remarcação para outra viagem exige um novo procedimento de reserva.
- Pontos de embarque são descritos em texto; não há cálculo de tarifa por trecho ou horário estruturado por ponto.
- Listas de viagens/reservas/passageiros mostram até 200 resultados filtráveis. Relatórios e totais financeiros não usam esse limite, mas exportações muito grandes devem ser avaliadas conforme a memória da hospedagem.
- PDF usa fonte padrão com caracteres ocidentais/portugueses e paginação A4. Escritas que exigem fontes Unicode adicionais precisam de extensão do gerador. Não há QR ou selo de documento fiscal.
- Não há perfis de funcionários, MFA, anonimização automática ou backup automático; os procedimentos de operação e proteção estão documentados.
- Não houve inspeção visual real em navegador/celular nem implantação em hospedagem externa. Verificações HTTP e DOM não substituem essa validação.

A interface de reserva não autoriza a comercialização de passagens em uma modalidade de transporte. O enquadramento concreto deve ser verificado conforme o documento operacional/jurídico incluído. Os comprovantes não afirmam ser documentos fiscais ou licenças de viagem.

## Recursos visuais

Ícones e ilustrações SVG geométricas foram criados para este projeto. Não há fotografias externas nem bibliotecas de ícones carregadas por CDN. A tipografia usa fontes do dispositivo. O proprietário pode enviar logotipo e capas próprios, observando os direitos sobre essas imagens.
