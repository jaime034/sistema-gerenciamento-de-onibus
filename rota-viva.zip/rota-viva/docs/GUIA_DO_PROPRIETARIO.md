# Guia do proprietário

## Preparar o serviço

1. Entre em `index.php?r=admin` com o e-mail e a senha criados na instalação.
2. Abra **Configurações**. Troque o nome, informe responsável, telefone, WhatsApp com país e DDD, e-mail, logotipo e informações de Pix. Confira a chave e o nome do beneficiário em um aplicativo bancário antes de divulgar.
3. Defina os prazos de seleção e pagamento, o limite por reserva pública, os métodos manuais, as regras de cancelamento e o aviso de privacidade.
4. Abra **Ônibus e poltronas → Cadastrar ônibus**. Informe a identificação e a quantidade de lugares para gerar uma disposição inicial 2+2. Revise cada número, janela, posição e disponibilidade. Deixe o número vazio onde não existir assento. Ajuste as fileiras e salve.
5. Se o ônibus tiver uma numeração diferente da sequência, altere os campos individualmente. A quantidade de lugares é a contagem de posições numeradas, não uma constante do sistema. Poltronas desativadas continuam visíveis como bloqueadas no inventário inicial.

Salvar o editor cria uma versão. Uma viagem existente não troca seu mapa automaticamente.

## Cadastrar e abrir uma viagem

Em **Viagens → Nova viagem**, informe roteiro, datas, embarque, valor por pessoa e a versão correta do mapa. O campo de embarque aceita vários pontos e instruções em linhas separadas. Nesta versão, cada ponto não possui horário próprio estruturado.

Salve como **Rascunho** enquanto prepara os detalhes. Selecione **Reservas abertas** para aparecer no catálogo e permitir reservas. A partida precisa estar no futuro. Use **Reservas encerradas** para suspender novas solicitações. Há também **Em andamento**, **Concluída** e **Cancelada**.

Use o mapa para consultar ocupação, **Passageiros** para a lista nominal e **Relatórios** para exportar. Ao duplicar uma viagem, a cópia fica em rascunho, com novas datas sugeridas e inventário independente. Revise tudo antes de abrir.

## Reservas públicas e manuais

Solicitações do site aparecem em **Reservas**. Filtre por viagem, situação, nome, telefone ou código. A lista mostra até 200 registros recentes; a busca alcança todo o banco. Abra a reserva para conferir passageiros, contato, valores e histórico.

Para vender diretamente, escolha **Nova reserva manual**, abra a viagem, selecione os lugares e preencha responsável e passageiros. Desconto administrativo precisa de motivo. A reserva manual usa o mesmo bloqueio de disponibilidade do site público. Criá-la não declara um pagamento inexistente: registre o recebimento depois de conferir.

No mapa administrativo, toque em uma poltrona ocupada para abrir os detalhes e o acesso à reserva. Um assento livre pode ser inspecionado por **Detalhes da última poltrona**. Se o toque o selecionar para venda, desmarque-o e abra os detalhes para poder bloqueá-lo. O bloqueio exige motivo. Não é possível bloquear um assento ocupado ou retido por outra sessão.

Para transferir, abra a reserva, expanda **Transferir para outro lugar** sob o passageiro e escolha um lugar livre da mesma viagem. Se alguém ocupar esse lugar antes da confirmação, o servidor recusa a troca sem perder o lugar atual. Transferir para outra viagem requer cancelar e criar outra reserva; não existe remarcação entre viagens nesta versão.

## Conferir e registrar pagamentos

1. Verifique o recebimento no banco, em dinheiro ou no meio informado.
2. Abra a reserva e **Registrar lançamento**.
3. Escolha **Recebimento**, informe valor, método, data e observações.
4. Registre. Se ainda houver saldo, a reserva ficará **Pagamento parcial**. Ao atingir o total, ficará **Confirmada** e o comprovante estará disponível.

O sistema não acessa sua conta bancária e não informa automaticamente se um Pix chegou. Ele também não envia cobranças ou confirmações por e-mail/WhatsApp. Os botões de WhatsApp abrem uma mensagem preparada para você revisar e enviar no seu aparelho.

Reservas sem recebimento podem expirar. Se você receber um Pix após a expiração, confira o caso, crie uma nova reserva se os lugares ainda estiverem disponíveis e só então registre o recebimento. Não há reativação automática de um lugar possivelmente vendido a outra pessoa.

Pagamentos parciais e reservas com histórico financeiro exigem análise manual quando o prazo vence. Veja a indicação **Prazo vencido · revisar**. A lista financeira inclui recebimentos em reservas canceladas para ajudar na conferência de devoluções.

## Cancelar e estornar

Cancelar libera os lugares e preserva os pagamentos. Explique o motivo no formulário. Se houver devolução, registre **Estorno** com valor, data, método e justificativa depois de fazê-la. O estorno não executa uma transferência bancária.

Cancelar uma viagem pela edição cancela todas as reservas ativas dessa viagem. É uma operação financeira e operacional relevante; verifique o histórico e os valores a devolver. Uma viagem cancelada não pode ser reaberta; duplique para um novo roteiro.

## Comprovante e contato com o cliente

Uma reserva confirmada permite baixar PDF no painel e na consulta do cliente. O documento contém serviço, código, passageiros, poltronas, trajeto, data, embarque e situação. Não é documento fiscal nem licença de viagem.

A chave privada de consulta é exibida quando a reserva é criada. Se o cliente perder o acesso, verifique sua identidade, abra a reserva e gere uma nova chave. A anterior deixa de funcionar, inclusive em sessões de consulta já abertas. O banco não guarda a chave em texto recuperável. Copie o novo link ou use a mensagem preparada de WhatsApp; o envio é sua decisão.

## Passageiros, embarque e relatórios

**Passageiros e embarque** permite buscar pessoas e editar nome, telefone e observações administrativas. Cada pessoa é registrada por reserva; o sistema não une automaticamente nomes iguais. A lista exibe os vínculos com viagens, poltronas e código, preservando o histórico.

Selecione a viagem para montar a lista de embarque. **Marcar presença** só funciona para reservas confirmadas. Clique novamente para desfazer uma marcação feita por engano. A ação é auditada.

Em **Relatórios**, escolha financeiro por viagem, movimentos por período, passageiros, confirmadas, ocupação, pendências ou cancelamentos. Exporte em PDF ou CSV com separador `;`, BOM UTF-8 e acentos compatíveis com Excel. O CSV neutraliza campos que poderiam ser interpretados como fórmulas.

Financeiro por viagem usa a data da partida, mostra todas as entradas/estornos vinculados e calcula a receber apenas sobre reservas ativas. Movimentos por período considera a data do pagamento/estorno. Pendências e cancelamentos consideram a criação da reserva. Os filtros explicam essas diferenças na tela.

## Rotina recomendada

Antes de cada saída, confira pendências, revise a lista, verifique os canais de contato e gere os relatórios necessários. Faça backup regular. No celular, abra o menu pelo botão superior para acessar o painel. O tema pode ser alterado no menu lateral; a preferência fica salva no navegador, sem afetar outros dispositivos.

Após períodos de inatividade, entre novamente. Para alterar a senha, use Configurações; a troca invalida todas as sessões administrativas.
