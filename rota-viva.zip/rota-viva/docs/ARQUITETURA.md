# Arquitetura e regras de consistência

## Objetivo e fluxo

A aplicação atende um proprietário e seus clientes. A área pública não exige conta. O proprietário autentica-se para gerir viagens, passageiros, ocupação e recebimentos. Ambas usam a mesma conexão MySQL/PDO e os mesmos serviços transacionais.

O cliente abre uma viagem, escolhe lugares, recebe uma retenção temporária, informa os passageiros, cria uma reserva pendente e recebe uma chave privada. O Pix é exibido como instrução; somente um lançamento administrativo após conferência financeira confirma o recebimento. O valor integral confirma a reserva e habilita o comprovante PDF.

## Organização

| Diretório | Responsabilidade |
| --- | --- |
| `public/` | Única raiz exposta à web: front controller e recursos locais |
| `app/Core/` | PDO, transações, segurança, validação, erros, valores e renderização |
| `app/Controllers/` | Entrada HTTP, autenticação, painel, público e instalação |
| `app/Services/` | Reservas, inventário, pagamentos, viagens, versões de layout, auditoria, PDF e relatórios |
| `app/Repositories/` | Consultas reutilizáveis de viagens, reservas e configurações |
| `app/Views/` | Templates PHP com escape de saída; componentes e layouts comuns |
| `config/` | Credenciais privadas, parâmetros da aplicação e rotas explícitas por método HTTP |
| `database/` | SQL de instalação, migrations versionadas e demonstração removível |
| `storage/` | Sessões, logs e imagens privadas servidas por controlador |
| `bin/` | Rotinas CLI opcionais; a hospedagem não depende delas |
| `tests/` | Suítes reproduzíveis de integração, HTTP e concorrência |
| `docs/` | Operação, instalação, arquitetura, segurança e resultados |

É um MVC simplificado com serviços de domínio. Não há ORM, compilação de front-end, Composer obrigatório, CDN, Node em produção ou processo permanente. O JavaScript é Vanilla JS com Fetch e o CSS é próprio. A aplicação funciona com URLs `index.php?r=...`, sem depender de mod_rewrite.

## Modelo relacional

| Tabela | Conteúdo e relação principal |
| --- | --- |
| `schema_migrations` | Versões aplicadas do esquema |
| `usuarios` | Proprietários autenticados, hash de senha e versão de sessão |
| `configuracoes` | Identidade, contatos, Pix, limites e textos operacionais |
| `onibus` | Cadastro do veículo; permite mais de um no futuro |
| `layouts_onibus` | Versões imutáveis da configuração física de cada ônibus |
| `poltronas` | Número real, fileira, coluna, janela e disponibilidade física por versão |
| `viagens` | Roteiro, horários UTC, preço, status e versão do layout |
| `viagens_poltronas` | Inventário exclusivo da viagem com cópia da posição e número |
| `reservas` | Código aleatório, HMAC da chave, contato, valor congelado, prazos e aceite |
| `passageiros` | Cadastro mínimo separado por pessoa/reserva, sem mesclar homônimos |
| `reservas_passageiros` | Passageiro, viagem, reserva, poltrona atual, preço original e embarque |
| `pagamentos` | Recebimentos e estornos imutáveis, autor e chave de idempotência |
| `auditoria` | Ações administrativas e mudanças de estado, sem chaves privadas |
| `limites_requisicoes` | Janelas de limitação de operações sensíveis |

Os SQLs são a especificação completa dos tipos, índices, chaves estrangeiras e CHECKs. UTF8MB4 e InnoDB são usados em todas as tabelas. Dinheiro é armazenado em DECIMAL(10,2); cálculos críticos usam centavos inteiros em PHP. Datas são persistidas em UTC e convertidas para America/Sao_Paulo na interface.

## Uma única ocupação ativa

Cada lugar da viagem tem exatamente uma linha de inventário. Há UNIQUE em `(viagem_id, poltrona_id)`, `(viagem_id, numero)` e `(viagem_id, fileira, coluna)`. A linha aponta para uma única reserva ativa ou para uma retenção temporária, nunca ambos. CHECKs validam os campos permitidos em cada estado. FKs compostas impedem vincular inventário e reserva de viagens diferentes.

O histórico de passageiros é preservado em `reservas_passageiros`, mesmo após cancelamento. Ele não é a fonte de disponibilidade. A fonte exclusiva é `viagens_poltronas`. Uma nova reserva pode ocupar a poltrona liberada e o histórico anterior continua consultável.

Todas as operações concorrentes travam primeiro a viagem com `SELECT ... FOR UPDATE`. Dentro da transação, expiram retenções/reservas elegíveis, conferem o inventário, bloqueiam os registros necessários e só então alteram o grupo. O banco confirma todas as poltronas de uma vez ou faz rollback de tudo. O mesmo procedimento vale para reservas públicas, manuais, pagamentos, bloqueios e transferências.

Essa trava serializa as mutações **da mesma viagem**. Viagens diferentes podem ser processadas simultaneamente. É uma decisão simples e segura para ônibus de até 160 posições físicas. Deadlocks e timeouts transacionais recebem até duas novas tentativas com intervalo curto; outros erros retornam sem expor dados internos.

## Estados e prazos

| Estado | Ocupação / regra |
| --- | --- |
| Disponível | Pode entrar numa seleção |
| Retenção temporária (`hold`) | Pertence a um segredo da sessão; duração configurável de 1 a 30 minutos |
| Reserva pendente | Ocupa seus lugares até o prazo; sem registro financeiro, expira automaticamente |
| Pagamento parcial | Ocupa lugares e exige análise manual; não expira automaticamente |
| Confirmada | Ocupa lugares e habilita comprovante |
| Cancelada | Libera lugares e conserva histórico financeiro |
| Expirada | Libera lugares; não recebe novos pagamentos; exige nova reserva |
| Bloqueada | Não é vendida; proprietário pode desbloquear se não houver ocupação |

Uma seleção inicial define o prazo do grupo. Adicionar ou remover lugares não renova indefinidamente esse prazo. Consultar o mapa também não o renova. Uma seleção expirada precisa ser feita novamente.

Novos prazos de seleção e pagamento são limitados pela partida. A expiração ocorre ao consultar mapas, catálogo, painel e reservas, além da rotina CLI opcional. A linha pode permanecer fisicamente marcada no banco enquanto ninguém acessa o sistema, mas a próxima operação a expira dentro da transação antes de verificar disponibilidade. O funcionamento não depende exclusivamente de cron.

Reservas que já tiveram registro financeiro são conservadas para revisão manual, inclusive se o líquido voltar a zero após estorno. Isso evita liberar inadvertidamente um lugar em uma operação de devolução. O painel indica prazos vencidos. Cancelar explicitamente é a forma de liberar esses lugares.

## Valores e pagamentos

O preço enviado pelo navegador é ignorado. O serviço lê o preço da viagem, multiplica pelos lugares e guarda subtotal, desconto, justificativa e total. Cada vínculo de passageiro conserva o preço individual. Alterar o preço padrão da viagem afeta somente novas reservas.

Descontos existem apenas no fluxo administrativo e precisam de justificativa quando maiores que zero. Desconto de 100% ou viagem gratuita gera reserva confirmada com total zero; não há recebimento fictício.

Recebimentos parciais e integrais são lançados por um administrador. O líquido é a soma de recebimentos menos estornos. Receber acima do saldo ou estornar acima do recebido é rejeitado. A mesma chave de lançamento não gera duas entradas em um reenvio. Pagamentos não são apagados ou sobrescritos: uma correção financeira é um novo estorno documentado. Um estorno parcial pode levar a reserva confirmada ao estado parcial novamente. Se a reserva já estiver cancelada, um estorno não a reativa.

A confirmação é uma consequência de recebimentos registrados ou de valor devido zero; não há botão público que declare o Pix pago. Não há integração bancária, comprovante de transferência aceito automaticamente nem webhook fictício.

### Extensão futura para gateway

`PaymentService` concentra a alteração financeira e do inventário. Uma integração futura deve adicionar um adaptador do provedor e uma tabela de eventos/transações externas, validar assinatura e origem do webhook, conferir moeda/valor/identidade da cobrança e deduplicar pelo ID externo. Só depois poderá chamar uma variante apropriada do serviço financeiro, identificando um ator técnico próprio. Não passe IDs arbitrários de usuário para contornar a autoria atual. A interface pública não deve tratar redirecionamento do banco como confirmação.

## Preservação do histórico

Salvar um mapa sempre cria uma nova versão; os layouts anteriores não são editados. Uma viagem usa a versão escolhida e copia suas posições para o inventário. Se existir qualquer reserva histórica, nome, origem, destino, horários, embarque e layout da viagem ficam bloqueados para edição. Para mudar o roteiro, duplique a viagem e revise a cópia em rascunho. Descrição, orientações, capa, preço para novas reservas e situação continuam editáveis.

Cancelar uma viagem cancela atomicamente suas reservas ativas e remove retenções temporárias. Os lançamentos financeiros continuam disponíveis para revisão e eventuais estornos. Não há exclusão destrutiva de viagens, reservas ou pagamentos pela interface.

## Interface e atualização

A identidade inicial “Rota Viva” é configurável. Azul profundo, verdes e tons naturais formam a paleta; ilustrações SVG originais acompanham o serviço sem fotografias de terceiros. Fontes do sistema e ícones SVG locais eliminam dependências externas.

O mapa é HTML/CSS gerado de registros reais. Aceita de 1 a 40 fileiras e até quatro posições de assento por fileira: colunas 1, 2, 4 e 5; a coluna 3 é o corredor. Posições sem número não existem. Fileiras incompletas, numeração alfanumérica, assentos desativados e janelas são configuráveis. Não representa ônibus de dois andares ou uma disposição 2+1 nesta versão.

O JavaScript consulta o servidor a cada 8 segundos enquanto a página está visível. Cada clique de seleção envia o grupo completo e só habilita o envio após a confirmação do servidor. Rótulos acessíveis, símbolos, `aria-pressed`, foco e navegação por setas complementam as cores. O backend sempre repete a validação na conclusão.
