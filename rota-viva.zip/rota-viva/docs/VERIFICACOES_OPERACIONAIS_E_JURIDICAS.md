# Verificações operacionais e jurídicas antes de oferecer viagens reais

Este documento é separado das funcionalidades técnicas. O sistema de reserva não concede autorização para operar transporte, emitir bilhetes regulados, realizar fretamento ou vender lugares avulsos. A implementação foi desenvolvida sem pressupor que a venda individual seja permitida na atividade concreta do proprietário.

## Enquadramento da operação

Identifique se cada serviço é municipal, intermunicipal, interestadual ou internacional e qual órgão possui competência para autorizá-lo. Diferencie fretamento turístico/eventual, transporte regular e outros enquadramentos efetivamente aplicáveis. Consulte o órgão competente e um profissional jurídico com os dados da empresa, veículo, localidade e modalidade antes de divulgar vendas.

A orientação pública da ANTT para fretamento interestadual/internacional descreve grupos previamente definidos, contrato e circuito fechado. A página de passageiros também informa restrições à comercialização individual de lugares nessa modalidade. Portanto, possuir um ônibus ou uma autorização de fretamento não deve ser tratado automaticamente como autorização de venda de passagens avulsas.

Fontes primárias consultadas em 16/10/2026:

- [ANTT — transporte de passageiros, distinção entre modalidades](https://www.gov.br/antt/pt-br/assuntos/passageiros).
- [ANTT — fretamento: informações e guias para empresas](https://www.gov.br/antt/pt-br/assuntos/passageiros/transportefretamento).

As informações acima resumem a orientação oficial consultada; não determinam o enquadramento de uma empresa específica. Normas locais, autorizações, decisões ou mudanças posteriores devem ser verificadas no contexto concreto.

## Itens para verificar com os responsáveis competentes

- Habilitação da empresa e modalidade de operação; documentação e cadastro do veículo.
- Autorizações, contratos, licenças por viagem e relação de passageiros quando exigidos.
- Condições de circuito fechado, composição do grupo e restrições de embarque/desembarque que se apliquem.
- Vistorias, seguros, documentação do motorista e demais requisitos operacionais pertinentes.
- Regras aplicáveis a crianças, adolescentes, acessibilidade, bagagens, cancelamentos e devoluções.
- Documentos fiscais, obrigações contábeis e informação ao consumidor segundo o enquadramento efetivo.
- Dados obrigatórios para listas regulatórias que não são coletados nesta versão, mediante finalidade justificada.

Essa lista é um roteiro de verificação, não uma afirmação de que cada item tenha a mesma exigência para todo tipo de viagem.

## Limite dos documentos gerados

O PDF emitido pelo sistema comprova o registro de reserva e sua situação no sistema. Não é nota fiscal, BP-e, autorização da ANTT, licença de viagem ou documento regulatório equivalente. O sistema não está integrado aos órgãos reguladores ou a serviços fiscais.

O proprietário deve configurar os textos de reserva/cancelamento e privacidade de acordo com a atividade autorizada, deixando claros roteiro, preço, prazo, condições de embarque e canais de atendimento. Dados de demonstração devem ser removidos e não divulgados como oferta real.
