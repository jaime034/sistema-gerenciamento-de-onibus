# Instalação e hospedagem

## Requisitos

- PHP 8.2 ou superior, 64 bits; PHP 8.3 foi usado nos testes.
- Extensões PDO, pdo_mysql, mbstring, fileinfo, session, ctype e JSON. `random_bytes`, `password_hash`, OpenSSL/HTTPS e UTF-8 devem funcionar normalmente. As extensões usuais do PHP de hospedagens atendem a esses requisitos; não é necessário GD.
- MySQL 8.0.16 ou superior, ou MariaDB 10.6 ou superior, com InnoDB, suporte real a CHECKs, FKs, JSON e transações. A execução foi validada em MariaDB 10.11.14. MySQL 8 foi o alvo de compatibilidade do SQL, mas não foi executado neste ambiente.
- Apache 2.4 ou servidor equivalente com configuração explícita da pasta pública. Nginx requer configurar DocumentRoot e bloquear diretórios no painel/servidor, pois não lê `.htaccess`.
- HTTPS e um domínio/subdomínio na hospedagem. Para desenvolvimento local, `environment=local` aceita HTTP.
- Diretórios de sessões, logs e uploads graváveis pelo processo PHP.

Não são necessários Node.js, Composer, Docker, SSH, WebSocket ou processos permanentes no servidor. O gerador PDF está no próprio projeto e não busca conteúdo externo.

## 1. Criar o banco

No painel da hospedagem, crie um banco UTF8MB4 e um usuário próprio. Use uma senha forte e dê ao usuário as permissões necessárias nesse banco. A instalação precisa criar tabelas/índices e aplicar constraints; o uso diário precisa SELECT, INSERT, UPDATE e DELETE. Permissões de DDL podem ser retiradas depois da instalação e devolvidas durante atualizações.

Anote nome, usuário, senha, host e porta reais fornecidos pelo painel. Não presuma que o host é `localhost` ou que o nome não recebe um prefixo da conta.

Pelo phpMyAdmin, você pode importar **somente `database/install.sql`**. O arquivo é completo e não contém senha ou administrador padrão. Outra opção é deixar o banco vazio e usar o assistente web para criar as tabelas.

`database/migrations/001_initial.sql` tem o mesmo esquema de instalação. Não importe os dois. A primeira migration existe para o versionamento e o comando opcional de migração. Os arquivos de demonstração são separados e opcionais.

## 2. Configurar o projeto

Copie `config/config.example.php` para `config/config.php`. Este último nunca vai na pasta pública nem em repositórios públicos.

| Campo | Preenchimento |
| --- | --- |
| `app_url` | URL absoluta do diretório público, sem barra final, por exemplo `https://viagens.seudominio.com.br` |
| `environment` | `production` no servidor; `local` apenas no computador de desenvolvimento |
| `timezone` | `America/Sao_Paulo`, salvo necessidade diferente |
| `app_key` | Segredo aleatório exclusivo, recomendado 64 caracteres hexadecimais |
| `setup_token` | Outro segredo aleatório, 32+ caracteres; use 64 e remova após criar o administrador |
| `trusted_proxies` | Lista de IPs exatos de proxies confiáveis, somente se a hospedagem termina HTTPS antes do PHP |
| `db` | Host, porta, nome, usuário e senha do banco |

Gere **dois segredos diferentes** com um gerenciador de senhas confiável, usando pelo menos 32 bytes aleatórios, ou com PHP local:

```bash
php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
```

Não use nome, telefone, senha pessoal ou as próprias credenciais do banco nesses campos. Guarde `app_key` no backup privado. Trocá-la invalida todas as chaves de consulta e retenções existentes; não faça isso como uma edição de rotina. Ao mudar a URL base, mantenha o diretório e o protocolo corretos.

Se houver subpasta, inclua-a: `https://seudominio.com.br/viagens`. As URLs dos recursos e cookies respeitam esse caminho. Não termine `app_url` em `/index.php`.

## 3. Enviar por FTP ou gerenciador de arquivos

### Opção recomendada: domínio aponta para `public/`

Envie a pasta do projeto para um diretório privado, por exemplo `/home/conta/rota-viva`. Configure o domínio/subdomínio para servir **`/home/conta/rota-viva/public`**. Somente `index.php`, `.htaccess` e `assets/` precisam ser acessíveis na web.

Credenciais, SQL, documentos, testes, sessões e logs permanecem fora do DocumentRoot.

### Quando a hospedagem impõe `public_html`

1. Envie `app`, `config`, `database` e `storage` para `/home/conta/rota-viva`, fora de `public_html`.
2. Envie o **conteúdo** de `public/` para `/home/conta/public_html`.
3. No `public_html/index.php`, ajuste apenas a linha que carrega o bootstrap para o caminho real. Exemplo:

```php
require __DIR__.'/../rota-viva/app/bootstrap.php';
```

4. Mantenha `assets/` e o `.htaccess` público junto do `index.php`.
5. Configure `app_url` para o endereço dessa pasta pública.

O `BASE_PATH` será calculado a partir de `app/bootstrap.php`, portanto os demais caminhos privados continuam corretos. Não envie uma segunda cópia de `config.php` para dentro de `public_html`.

Se a hospedagem proibir diretórios privados ou ignorar regras de proteção, peça uma opção de DocumentRoot adequado ao provedor. Não exponha todo o projeto e dependa apenas de nomes de pastas difíceis de adivinhar.

## 4. Permissões

Garanta leitura dos códigos pelo PHP e escrita em:

- `storage/sessions`
- `storage/logs`
- `storage/uploads`

Em muitas hospedagens, pastas `755` e arquivos `644` funcionam. Quando o PHP usa outro grupo, o provedor pode recomendar `750/770` para diretórios privados e `640/660` para arquivos. Use a orientação da hospedagem e o menor acesso necessário. Não defina `777` indiscriminadamente. `config/config.php` não precisa ser gravável pela aplicação.

As imagens são salvas com nome aleatório no diretório privado, validadas por MIME/conteúdo e servidas por uma rota que nunca executa PHP. Um logotipo ou uma capa com até 3 MB exige que `upload_max_filesize` e `post_max_size` permitam esse volume; `post_max_size` deve comportar o restante do formulário, por exemplo 5 MB ou mais.

## 5. Ativar HTTPS

Ative o certificado no painel e confira o domínio antes do primeiro acesso administrativo. Defina `environment=production` e `app_url=https://...`.

Em produção, GETs HTTP são enviados ao endereço HTTPS configurado e escritas HTTP são recusadas. Cookies administrativos são Secure, HttpOnly e SameSite=Lax. O sistema usa HSTS. Se o provedor usa um proxy reverso, configure apenas seus IPs exatos em `trusted_proxies`; somente assim o cabeçalho `X-Forwarded-Proto: https` é aceito. Não confie em cabeçalhos de qualquer origem.

## 6. Criar o primeiro administrador

Acesse:

```text
https://seu-endereco/index.php?r=instalar
```

Digite a chave `setup_token`, nome, e-mail e uma senha própria com 12 a 72 caracteres. O assistente cria as tabelas se estiverem ausentes e cria o primeiro administrador usando `password_hash`. O cadastro é serializado e não permite um novo primeiro usuário se já existir qualquer administrador.

Depois:

1. Remova o valor de `setup_token` em `config/config.php`, deixando `''`.
2. Entre em `index.php?r=admin/login`.
3. Configure identidade, ônibus, Pix, regras e primeira viagem.

Não há senha padrão ou conta demonstrativa no ZIP. O banco recém-instalado não contém viagens ou passageiros reais.

Se o assistente encontrar instalação parcial, use um banco vazio e importe o SQL completo. Não tente continuar sobre tabelas de outro projeto. Se a importação falhar por versão, verifique InnoDB, CHECKs e suporte a JSON antes de remover constraints.

Com terminal **opcional**, `php bin/admin.php` permite criar um administrador ou redefinir a senha de um e-mail existente. A senha é lida pelo stdin, nunca como argumento de comando. O projeto funciona sem esse recurso.

## 7. Demonstração opcional

Em um ambiente de testes, importe `database/seeds/demo.sql` **uma única vez**. Ele cria:

- Um ônibus explicitamente identificado como demonstração, com 26 lugares e última fileira incompleta.
- Uma poltrona desativada/bloqueada.
- Duas viagens fictícias, com datas relativas à importação.
- Dois passageiros fictícios e uma reserva pendente de exemplo.

O script não cria administrador, senha, integração ou recebimento falso. Para consultar publicamente a reserva de exemplo, abra-a no painel e gere uma chave privada. Para testar o fluxo financeiro, registre recebimentos apenas no ambiente de testes.

Remova a demonstração com `database/seeds/remove_demo.sql`, após backup. Todas as reservas novas feitas em viagens marcadas como demonstração também são consideradas demonstrativas e removidas. Dados reais de viagens não marcadas não são o alvo do script. Não reutilize uma viagem demonstrativa como viagem real.

## 8. Expiração e tarefas opcionais

A expiração é feita nas próprias transações de leitura/compra. O sistema funciona sem agendamento. Se o painel da hospedagem tiver cron, execute a cada minuto:

```bash
php /home/conta/rota-viva/bin/expire.php
```

Use a versão correta do executável PHP fornecido pelo provedor. A rotina também remove janelas antigas de limitação de requisições. Não exponha esse script como URL pública; ele aceita somente CLI.

## 9. Verificação depois de instalar

Configure um ônibus, publique uma viagem fictícia e faça uma reserva pelo celular. Confira o painel, registre um recebimento fictício no ambiente de testes, consulte a reserva e baixe o PDF. Exporte a lista e cancele a reserva de teste. Teste o acesso a uma reserva sem chave: deve ser recusado.

Verifique que URLs como `/config/config.php`, `/database/install.sql` ou `/storage/logs/php.log` não existem publicamente. Quando o DocumentRoot é correto, esses caminhos ficam fora do site. Depois dos testes, remova a demonstração e revise as condições reais antes de divulgar.

A inspeção em dispositivos, servidor, domínio e conta bancária reais não foi feita na entrega. Veja `RESULTADOS_DOS_TESTES.md` para os testes executados no ambiente de desenvolvimento.

## Recuperar acesso sem SSH

Se esquecer a senha e não tiver terminal, entre no phpMyAdmin usando o acesso da hospedagem. Gere um novo hash com `password_hash` em uma instalação PHP local confiável, sem enviar a senha a sites de terceiros. Atualize `usuarios.senha_hash` do e-mail correto e incremente `session_version` em 1 para invalidar sessões. Não grave a senha em texto no banco e não reabra o instalador apagando usuários. Faça backup e use a conta correta; se necessário, peça ao suporte da hospedagem para executar a redefinição com você.
