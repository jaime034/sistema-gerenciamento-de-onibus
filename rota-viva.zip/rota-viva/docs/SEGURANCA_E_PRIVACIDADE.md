# Segurança e privacidade

## Controles implementados

- PDO com consultas preparadas nativas; nomes de tabelas/colunas e rotas não vêm de SQL enviado pelo navegador.
- Escape de conteúdo na saída HTML. O JavaScript utiliza `textContent`/elementos DOM para conteúdo vindo do servidor.
- Tokens CSRF por sessão em todas as escritas, inclusive login, consulta privada e retenção de assentos.
- `password_hash`/`password_verify`; nenhuma conta administrativa ou senha padrão no pacote.
- Regeneração de ID no login/logout; modo estrito de sessão, cookies HttpOnly, SameSite e Secure em produção.
- Inatividade administrativa de uma hora e invalidação de todas as sessões pela versão de sessão ao alterar senha.
- Limites por IP e por e-mail na autenticação, por IP na consulta privada, retenções e criação pública de reservas. Chaves de limitação usam HMAC; o endereço não é persistido em texto nessa tabela.
- Chave privada aleatória de 32 bytes para consulta; somente seu HMAC é armazenado no banco. Código público aleatório independente. Rotação invalida acessos anteriores.
- Retenções associadas a segredos gerados na sessão, não a um ID de proprietário fornecido livremente pelo navegador.
- Rotas administrativas protegidas no front controller, incluindo as APIs e exportações. Não há informação nominal no mapa público.
- Transações, constraints e bloqueios no banco para disponibilidade e finanças; preço calculado no servidor; recebimentos idempotentes.
- Imagens privadas com nome aleatório, limite de tamanho, MIME/conteúdo e dimensões conferidos. PHP/SVG/HTML não são formatos aceitos em uploads.
- Cabeçalhos CSP sem scripts inline, `nosniff`, recusa de frames, `Referrer-Policy: no-referrer` e HSTS em produção.
- Erros públicos sem stack trace, SQL ou credenciais; logs em pasta privada.
- Registro de ações e lançamentos financeiros; cancelamento conserva histórico.
- CSV protegido contra interpretação como fórmula em planilhas.

HTTPS é exigido nas operações em produção. Essa proteção depende de `environment=production`, URL correta e configuração correta do provedor. IPs de proxies só devem ser declarados se forem confiáveis e controlados pelo serviço de hospedagem.

## Privacidade no fluxo

A reserva coleta nome, contato do responsável e nome de cada passageiro. E-mail é opcional; não são solicitados CPF, RG, data de nascimento, endereço ou dados bancários do cliente. Caso uma obrigação concreta de transporte exija dados adicionais, avalie a finalidade e amplie o modelo especificamente, com acesso restrito e aviso atualizado.

Os textos de regras e privacidade aceitos são copiados para a reserva, com horário do aceite. O checkbox registra ciência dessas condições; ele não determina, por si só, a base legal de todos os tratamentos. O proprietário precisa definir e informar finalidade, base legal, prazo de conservação, contato do responsável, atendimento de direitos e obrigações que justifiquem preservar registros.

O link de consulta contém a chave no fragmento (`#`), evitando seu envio direto na URL HTTP e em logs de acesso. Ao abrir a consulta, o JavaScript preenche os campos e retira o fragmento do histórico daquela página. A chave é enviada por POST, protegida por HTTPS em produção. Ela também pode ser digitada manualmente. O link continua sensível: quem o receber poderá acessar a reserva. Confirme a identidade antes de renovar ou enviar uma chave.

O banco conserva somente HMAC de chaves, mas arquivos de sessão podem conter temporariamente a chave recém-gerada para permitir ao usuário salvá-la. Proteja `storage/sessions`, backups e o acesso da hospedagem. Não coloque chaves em logs, analytics, capturas públicas ou repositórios.

## Responsabilidades operacionais

Defina uma política de retenção que respeite finalidades e obrigações aplicáveis. A versão entregue não possui exclusão automática de dados pessoais nem portal automatizado para solicitações LGPD. O proprietário deve atender solicitações por seu canal de contato, verificar a identidade, avaliar o que deve ser mantido e registrar o atendimento. Uma anonimização futura deve abranger `reservas`, `passageiros`, observações e backups, preservando a integridade e as obrigações financeiras que efetivamente se apliquem.

Mantenha PHP, banco e hospedagem atualizados. Restrinja as pessoas com acesso ao painel, phpMyAdmin, FTP e backups. Não compartilhe a conta do proprietário indiscriminadamente. A aplicação não possui perfis de funcionários ou MFA nesta versão.

Não há auditoria externa de segurança, teste de penetração ou certificação de conformidade. Os testes executados e seus limites estão documentados em `RESULTADOS_DOS_TESTES.md`.

Referência operacional consultada em 16/10/2026: [ANPD — guia e checklist de segurança da informação para agentes de tratamento de pequeno porte](https://www.gov.br/anpd/pt-br/centrais-de-conteudo/materiais-educativos-e-publicacoes/guia-orientativo-sobre-seguranca-da-informacao-para-agentes-de-tratamento-de-pequeno-porte). O guia oferece medidas práticas para proteção de dados; a adequação concreta precisa considerar a operação do proprietário.
