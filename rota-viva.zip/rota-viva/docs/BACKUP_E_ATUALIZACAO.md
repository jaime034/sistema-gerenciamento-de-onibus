# Backup, restauração e atualização

## O que preservar

Faça backup do banco inteiro, de `storage/uploads` e de `config/config.php` em um local privado. Preserve a chave `app_key`: sem ela, chaves antigas de consulta não poderão ser verificadas. O código pode ser restaurado pelo ZIP da versão usada, mas versões diferentes precisam corresponder ao esquema do banco.

Backups contêm dados pessoais e financeiros. Restrinja o acesso, proteja o arquivo e estabeleça prazo de retenção. Não os salve dentro de `public/`. Não envie por links públicos de compartilhamento. Os arquivos de sessão não são necessários para restauração; é preferível encerrar sessões durante uma recuperação.

## Sem terminal: painel e phpMyAdmin

1. Escolha um horário tranquilo e, quando necessário, coloque o site em manutenção pelo painel da hospedagem para interromper escritas.
2. No phpMyAdmin, selecione o banco correto e use **Exportar → Personalizado → SQL**, incluindo estrutura e dados de todas as tabelas, com UTF8MB4 e opção de transação/consistência se oferecida.
3. Baixe a exportação e copie `storage/uploads` e a configuração privada pelo gerenciador de arquivos ou FTP seguro.
4. Registre data, versão do código e banco incluídos.
5. Teste a restauração em outro banco e domínio privado. Só a existência de um arquivo não comprova que o backup pode ser restaurado.

## Com terminal opcional

Use a ferramenta equivalente do provedor. Informe a senha pelo prompt `-p`, não na linha de comando:

```bash
mysqldump --single-transaction --default-character-set=utf8mb4 -h HOST -u USUARIO -p NOME_DO_BANCO > backup.sql
```

Em MariaDB, o nome do programa pode ser `mariadb-dump`. Para grandes volumes ou réplica, peça ao provedor uma rotina consistente com o ambiente. Não crie/destrua tabelas durante um backup transacional.

## Restaurar

1. Interrompa escritas e preserve uma cópia do estado atual, inclusive se estiver com falha.
2. Crie um banco vazio ou use um banco separado. Importe o SQL do backup e confira a versão em `schema_migrations`.
3. Restaure o código correspondente, uploads e configuração. Se o banco/host mudar, ajuste somente os dados necessários da conexão e URL.
4. Esvazie os arquivos de `storage/sessions` durante a manutenção, mantendo a pasta protegida.
5. Verifique login, próxima viagem, ocupação, reserva e relatórios no ambiente restaurado antes de liberar acessos.
6. Confira recebimentos realizados durante a indisponibilidade com o extrato real. O banco restaurado pode não conter operações posteriores ao backup.

A restauração em hospedagem externa não foi executada nesta entrega; os testes de esquema e fluxo utilizaram apenas banco local isolado.

## Atualizações do sistema

A versão inicial usa `001_initial`. Migrations futuras devem ter nomes ordenados, como `002_nova_funcionalidade.sql`, sem editar a primeira versão já aplicada.

Antes de atualizar, faça backup, leia as mudanças, coloque o site em manutenção e aplique as novas migrations na ordem. Com terminal opcional:

```bash
php bin/migrate.php
```

O comando consulta `schema_migrations` e ignora versões registradas. No phpMyAdmin, importe apenas as migrations ainda não aplicadas e confirme o registro de versão indicado no script. Não reimporte `install.sql` sobre uma instalação existente.

DDL no MySQL/MariaDB pode fazer commit implícito, portanto falhas de migração podem deixar mudanças parciais. Não presuma rollback completo de uma atualização de esquema. Se falhar, mantenha a manutenção, preserve o diagnóstico e restaure o conjunto código/banco do backup testado antes de retomar. Não apague constraints para forçar a execução.
