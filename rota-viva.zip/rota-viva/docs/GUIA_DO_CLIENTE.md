# Guia do cliente

1. Abra **Próximas viagens** e filtre por destino, data e disponibilidade.
2. Consulte o roteiro, a saída, o local de embarque, preço e regras.
3. Escolha **Escolher minha poltrona**. A frente do ônibus e o motorista ficam na parte superior. Os números correspondem ao cadastro real do veículo.
4. Toque em lugares disponíveis. Toque novamente para desmarcar. A legenda distingue disponíveis, sua seleção, temporários, pendentes, confirmados e bloqueados com símbolos e cores. Pelo teclado, use Tab, Enter/Espaço e as setas no mapa.
5. Observe o contador. Seus lugares ficam protegidos por um prazo limitado enquanto preenche os dados. Adicionar lugares não reinicia o prazo. Caso termine, selecione novamente.
6. Informe seu nome, telefone com DDD, e-mail se desejar e o nome de cada passageiro. Leia as regras e o aviso de privacidade, confirme a ciência e envie.
7. Guarde o **link privado** ou o código e a chave de acesso. Não publique esse link: ele permite consultar os dados da reserva.
8. Confira o valor, a chave Pix e o beneficiário. Siga as instruções do responsável e respeite o prazo mostrado. Se não houver chave configurada, solicite os dados ao responsável antes de pagar.
9. O proprietário precisa conferir e registrar o recebimento. O sistema não confirma Pix automaticamente. Use **Atualizar situação** ou volte à consulta para acompanhar.
10. Após a confirmação integral, baixe seu comprovante PDF e confira as orientações de embarque.

Para voltar depois, abra **Minha reserva** e informe código e chave privada, ou utilize o link guardado. Não é necessário criar conta.

Se perder a chave, peça ao responsável um novo acesso. Ele deverá verificar sua identidade. Se a reserva expirar, seus lugares poderão ser liberados. Pagamento feito depois do prazo não garante a manutenção dos mesmos lugares; contate o proprietário.

Cancelamentos e devoluções são solicitados diretamente ao responsável conforme as regras apresentadas na compra. O comprovante do sistema é uma confirmação de reserva/embarque, não documento fiscal ou licença de transporte.
