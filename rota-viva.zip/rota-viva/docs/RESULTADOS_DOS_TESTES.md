# Resultados dos testes

Data: **16/10/2026**. Todos os nomes, contatos, valores e viagens utilizados nos testes são fictícios.

## Ambiente e resultado

- PHP CLI **8.3.6**, extensão PDO MySQL, mbstring, fileinfo e demais extensões indicadas no guia.
- MariaDB **10.11.14**, InnoDB/UTF8MB4, banco isolado com nome terminado em `_test`.
- Servidor PHP local para testes HTTP; nenhum servidor externo ou conta bancária foi acessado.
- Python 3, biblioteca padrão, para requisições e cookies reais.
- Node.js e LinkeDOM apenas no ambiente de desenvolvimento, para executar o JavaScript real contra um DOM de teste. Não são dependências de produção.
- `pdfinfo` e `pdftotext` para verificar a estrutura e o texto dos PDFs produzidos.

**124 verificações automatizadas aprovadas** na versão final: 40 de serviços/banco, 59 HTTP, 3 de demonstração, 2 do instalador e 20 DOM. A sintaxe dos arquivos PHP e JavaScript também foi verificada. Os registros textuais sanitizados estão em `docs/evidencias/`.

## Cobertura do fluxo solicitado

| Item | Resultado e evidência |
| --- | --- |
| Instalação do banco | Executada em banco local vazio, inclusive pelo assistente HTTP; 14 tabelas e migration inicial |
| Primeiro administrador | Criado via assistente; nova tentativa de instalação recusada após existir administrador |
| Login/logout | Executados por HTTP com sessões e CSRF reais; acesso protegido recusado após logout |
| Senha e sessões | Hash conferido; troca de senha invalida sessão atual e outra sessão já aberta; novo login funciona |
| Ônibus | Criado por serviço real com persistência no banco |
| Layout personalizado | Sete lugares com números alfanuméricos, fileira incompleta e posições vazias; nova versão preserva a antiga |
| Viagem | Cadastrada e publicada com preço e roteiro persistidos; duplicação cria rascunho independente |
| Exibição pública | Inicial, catálogo filtrado e detalhes retornam dados da viagem pelo servidor |
| Seleção livre | API recebe grupo e registra retenção; JavaScript real desenha a seleção após confirmação |
| Indisponibilidade | Ocupados/bloqueados recusados no servidor; botões públicos indisponíveis e conflito testados no DOM |
| Vários passageiros | Reserva de dois lugares e total calculado com preço do banco; preço falso enviado no POST é ignorado |
| Reserva manual | Executada pelo painel HTTP, com desconto justificado e mesmo inventário |
| Concorrência | Dois processos PHP independentes, conexões PDO distintas e barreira de início disputam o mesmo grupo de duas poltronas |
| Atomicidade | Uma disputa vence; a outra recebe 409; há uma única reserva ativa do grupo. Um grupo com assento conflitante não retém parcialmente outro lugar |
| Expiração temporária | Prazo vencido preparado no banco; leitura transacional libera retenção sem cron |
| Expiração pendente | Reserva sem recebimentos vence e libera os lugares; parcial não expira automaticamente |
| Pagamento parcial/integral | Registro HTTP e serviço; líquido parcial mantém estado parcial e integral confirma inventário/reserva |
| Reenvio financeiro | Chave repetida não duplica recebimento; reutilização com outro valor é recusada |
| Cancelamento e estorno | Cancelamento libera lugares e mantém valores; estorno registrado depois não reativa reserva |
| Transferência | Serviço e painel transferem para lugar livre; anterior liberado na mesma transação |
| Bloqueio administrativo | Bloquear/desbloquear livre funciona; bloquear ocupado é recusado |
| Embarque | Marcação de presença por HTTP para passageiro confirmado |
| Comprovante | Cliente pendente não emite; confirmado recebe PDF real. Arquivo A4 e texto extraído validados |
| Relatórios | Passageiros excluem reservas canceladas/expiradas; PDF e CSV gerados pelo painel |
| CSV seguro | Acentos UTF-8/BOM e conteúdo iniciado com fórmula neutralizado |
| Consulta privada | Código isolado e chave errada recusados; chave correta autoriza; rotação invalida consulta anterior |
| Autorização | API administrativa sem sessão devolve 401; formulários sem CSRF devolvem 419 |
| Validação | Upload falso JPG, JSON malformado, dinheiro negativo, datas impossíveis/relativas e excesso de pagamento recusados |
| Escape HTML | Nome contendo marcação aparece escapado na página; não vira elemento/script |
| Limitação de login | Excesso de tentativas recebe 429 |
| Constraints | Unicidade de inventário e CHECK de estado inconsistente testados diretamente no banco |
| Dados demonstrativos | SQL cria 1 ônibus, 2 viagens, 1 reserva e 2 passageiros; remoção respeita FKs e preserva viagens não demonstrativas |
| Interações DOM | 20 verificações: mapa variável, vazios, janelas, totais, seleção/desmarcação, nomes preservados, limite, setas, conflito e editor |
| Responsividade visual | **Não executada em navegador real**; CSS mobile-first e breakpoints implementados, sem comprovação visual neste ambiente |

## Concorrência: o que o teste prova

A suíte cria duas conexões em processos separados, espera ambos estarem prontos e libera uma barreira comum. Os dois tentam reter e concluir as mesmas duas poltronas. O resultado executado teve exatamente um sucesso e uma recusa de conflito, com uma reserva ativa no inventário. Isso verifica exclusão mútua e conclusão atômica desse cenário.

Não é um teste de carga de centenas de clientes, nem garante capacidade de uma hospedagem específica. A trava por viagem foi escolhida para privilegiar integridade em uma operação de ônibus com poucos assentos. Testes de carga e latência devem ser feitos no ambiente de hospedagem antes de ampliar significativamente a operação.

## Verificação de PDF

Os comprovantes e relatórios baixados por HTTP foram reconhecidos como PDF 1.4, **A4 de 595 × 842 pontos**, sem JavaScript embutido. `pdftotext` recuperou serviço, código, situação, trajeto, partida, embarque, passageiros, números dos assentos, valor e orientações com acentos em português.

Não houve inspeção visual das páginas PDF em navegador ou análise de impressão física. A checagem executada foi estrutural e textual. O gerador suporta caracteres ocidentais e paginação; fontes Unicode abrangentes não estão incluídas.

## Limites de validação

Não foram executados:

- Inspeção visual em Chrome, Firefox, Safari, Android ou iPhone; teste real de toque e leitor de tela.
- Medição de contraste automatizada, auditoria WCAG integral ou revisão por pessoa com deficiência.
- MySQL 8 em execução; o banco efetivamente usado foi MariaDB 10.11.14.
- Instalação em Apache/Nginx ou hospedagem compartilhada externa; permissões e `.htaccess` dependem do provedor.
- Certificado HTTPS real, proxy de hospedagem, HSTS e cookies Secure em um domínio público. Os testes HTTP usaram ambiente local.
- Recebimento bancário real, integração financeira, gateway, WhatsApp/e-mail enviados ou autorização regulatória.
- Teste de carga, auditoria externa de segurança, recuperação de backup em servidor externo ou validação jurídica da empresa.

Esses limites não são apresentados como testes aprovados. A entrega não foi publicada em produção.

## Como reproduzir

Use uma **cópia local exclusiva** do projeto, nunca a configuração de produção. Crie um banco vazio chamado, por exemplo, `rota_viva_test` e configure essa cópia com `environment=local`, URL local e chaves aleatórias. A suíte insere dados e exige nome terminado em `_test`. O banco de testes não acompanha o ZIP.

Com PHP e banco já disponíveis:

```bash
RV_TEST_FIXTURE=/tmp/rota-viva-fixture.json php tests/run.php
php tests/seed_test.php
```

O primeiro comando instala o esquema caso ausente, cria fixtures isoladas com identificadores próprios e executa os serviços/conexões concorrentes. Requer `proc_open` no ambiente de desenvolvimento. Hospedagens que o bloqueiam ainda podem executar a aplicação; a restrição afeta esse teste local de processos.

O teste de seeds requer que não exista outra demonstração no banco. Ele carrega e remove somente os registros demonstrativos.

Em um terminal separado, mantenha o servidor local apontando para a pasta pública:

```bash
php -S 127.0.0.1:8089 -t public
```

Na configuração dessa cópia, `app_url` deve ser `http://127.0.0.1:8089`. Depois:

```bash
RV_TEST_FIXTURE=/tmp/rota-viva-fixture.json python3 tests/http_test.py http://127.0.0.1:8089
```

O arquivo temporário contém credenciais **fictícias de teste** necessárias para o login; mantenha-o privado e apague depois. A suíte HTTP altera a senha daquele administrador fictício. Para repetir o fluxo inteiro, gere novas fixtures; para evitar interferência dos limites de requisições de rodadas anteriores, prefira um banco de testes novo.

Para testar o assistente, crie **outro banco vazio** com nome terminado em `_test`, mantenha um `setup_token` na configuração local e execute:

```bash
RV_SETUP_DB=rota_viva_instalacao_test python3 tests/setup_http_test.py http://127.0.0.1:8089
```

Esse teste faz uma troca temporária no `config/config.php` da cópia local e restaura seu conteúdo ao terminar. Não execute com outros usuários acessando a cópia. Ele recusa ambiente de produção, endereço não local e nomes de banco inadequados. O banco indicado deve existir e estar vazio.

Para os testes DOM opcionais, instale a dependência somente fora do projeto de produção:

```bash
npm install --prefix /tmp/rv-ui linkedom
NODE_PATH=/tmp/rv-ui/node_modules node tests/ui-dom.test.cjs
```

Eles executam os arquivos JavaScript entregues, com respostas de rede controladas. Não substituem um teste visual ou as transações reais já verificadas nas outras suítes.
