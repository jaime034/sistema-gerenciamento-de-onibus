<?php

header('Location: /rota-viva/public/', true, 302);
exit;